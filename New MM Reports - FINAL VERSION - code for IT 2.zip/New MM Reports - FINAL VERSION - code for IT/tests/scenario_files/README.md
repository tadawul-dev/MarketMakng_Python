# Business scenario test files (BRD v.13 and its Additional Business Scenarios)

One folder per BRD business scenario. Each folder has an order file in the X-Stream TSORDR format
(`TSORDR-20260930.txt`, all 45 columns) and the MM config file it is run with (`mm_config.json`).
The session is the real one: 09:30:00-15:30:00 (21,600 s), required presence 17,280 s.
Test market makers: `MA0000001` (MM A) and `MB0000001` (MM B); test contracts: `TSTF6V` (SSF, symbol TESTFUT),
`IDXF6V` (Index Futures, symbol MT30FUT); `..F6U` contracts are the rollover contracts.

Run one scenario the same way production does:

```bash
.venv/bin/python brd_daily.py --no-email --config tests/scenario_files/<folder>/mm_config.json tests/scenario_files/<folder>/TSORDR-20260930.txt
```

Check every scenario automatically: `.venv/bin/python tests/test_brd_scenarios.py` (all must pass).
Re-create these files: `.venv/bin/python tests/test_brd_scenarios.py --export tests/scenario_files`.
The monthly compliance scenario (BRD 37) has 20 days of daily results in `61_monthly_compliance_rate/results/`: copy them to
`<output_dir>/results/` and run `.venv/bin/python brd_monthly.py 202609 --no-email`.
Additional A22 (monthly part) is checked by the automated test `test_64_monthly_skips_suspended_days`.

Prices and times inside a file can differ from the example wording in the BRD (for example 09:30:10
instead of 10:10:00); the outcome (seconds met / not met, lots, Eligibility Flag, reasons) is the one the BRD
expects, and the automated test checks it.

Folder numbers are the test numbers. The table gives the scenario number in the BRD v.13 (1-37), or in the document
"Derivatives Market Making – Additional Business Scenarios" (A1-A27: scenarios that do not occur in, or cannot be identified in, the order files received so far).

| Folder | Scenario | Expected result |
|---|---|---|
| `01_full_order_book` | BRD 1 – Full order book | spread met and order book met. |
| `02_additional_order_in_front` | BRD 2 – Additional order in front of the order book | spread met and order book met; the 3-lot order is additional liquidity. |
| `03_two_orders_same_price_newer_deleted` | BRD 3 – Two orders at the same price | 5 lots remain at 62.40 and the older order is still counted. |
| `04_top_up_at_same_price` | BRD 4 – Top-up at the same price | the Best Bid has 5 lots and the order book is met. |
| `05_partial_fill_then_top_up` | BRD 5 – Partial fill | the order remains with 2 lots and the order book is not met until the level is topped up to 5 lots. |
| `06_best_bid_below_required_size` | BRD 6 – Best Bid below the required size | order book not met. |
| `07_small_orders_at_tight_spread` | BRD 7 – Small orders at a tight spread | spread met; order book not met, as the qualifying order books are 4 ticks apart. |
| `08_wide_spread` | BRD 8 – Wide spread | spread not met (3 ticks) and order book not met. |
| `09_missing_price_level` | BRD 9 – Missing price level | order book not met. |
| `10_41_42_suspended_and_resumed` | Additional A1 – Suspended and resumed order | the order is not counted while suspended and is counted again after it is resumed. |
| `10_41_42_suspended_and_resumed` | Additional A10 – Order deactivated (Suspended) | from 10:00:00 the order is not counted; the order book and spread are checked without it (not met if no other buy order meets level 1). The audit log shows: Buy order at 62.20 suspended. |
| `10_41_42_suspended_and_resumed` | Additional A11 – Order activated again (Resumed) | the order is counted again from 10:00:10; 10 seconds not met (10:00:00 to 10:00:10). |
| `11_52_market_order_partly_matched_rest_converted` | BRD 10 – Market order converted to a limit order | the order is counted at 44.90 from the price adjustment onwards. |
| `11_52_market_order_partly_matched_rest_converted` | BRD 32 – Market order partly matched, remaining lots converted to a limit order | the order is counted in the order book at 44.90 with 5 lots from 15:00:01 to 15:00:09; the traded volume of market maker A is 8 lots (3 + 5). |
| `12_29_negotiated_deals_not_counted` | Additional A2 – Negotiated deal | disregarded for the order book and the traded volume. |
| `12_29_negotiated_deals_not_counted` | Additional A7 – Negotiated deals not included | the 5 lots are not included in the traded volume. |
| `13_spread_at_the_maximum` | BRD 11 – Spread exactly at the maximum | spread met and order book met. |
| `14_only_one_side` | BRD 12 – Only one side quoted | spread not met and order book not met (No sell orders). |
| `15_change_and_top_up_same_second` | BRD 13 – Change and top-up in the same second | 10:10:00 is counted as met (end of second rule). |
| `16_late_top_up` | Additional A3 – Late top-up | 5 seconds not met (10:10:00 to 10:10:05), reason: level 4 has 8 lots; 12 required. |
| `17_order_added_and_removed_same_second` | BRD 14 – Order added and removed in the same second | the order is not counted for 10:15:00. |
| `18_price_level_more_than_one_tick_away` | BRD 15 – Price level more than 1 tick away | order book not met, reason: Sell level 3 should be at 62.70 but the next sell order is at 62.80 (2 ticks away). |
| `19_middle_level_below_required_size` | BRD 16 – Level in the middle below the required size | order book not met, reason: Buy level 3 has 8 lots; 10 required. |
| `20_configured_tick_variance_of_two_ticks` | Additional A4 – Configured tick variance of 2 ticks | order book met. The same quote with levels 1 tick apart is not met. |
| `20_configured_tick_variance_of_two_ticks_case2` | Additional A4 – Configured tick variance of 2 ticks | order book met. The same quote with levels 1 tick apart is not met. |
| `21_index_futures_tick_size` | BRD 17 – Index Futures tick size | spread met and order book met. |
| `22_other_market_makers_not_counted` | BRD 18 – Other market makers at the same prices | those orders are not counted; each market maker is measured only on its own orders. |
| `23_24_62_orders_before_open_and_overnight_orders` | BRD 19 – Orders entered during pre open | presence is counted from 09:30:00 (market open), not before. |
| `23_24_62_orders_before_open_and_overnight_orders` | Additional A23 – Overnight order | the order is counted from market open in the same way as any other order. |
| `23_24_62_orders_before_open_and_overnight_orders` | Additional A27 – Order amended on a previous day | the order is counted as 8 lots at 62.60 from market open. The events of the previous day are not needed; the same applies to any other order action on the previous day (for example Price Adjusted 0788 or Resumed 0790). |
| `25_cancel_on_disconnect` | Additional A5 – Cancel on disconnect | the orders are removed at that second; the audit trail shows the failure and what changed. |
| `26_kill_switch` | Additional A6 – Kill Switch | all orders are removed at that second; spread and order book not met until new orders are entered. |
| `27_partial_fills_use_filled_volume` | BRD 20 – Traded volume from partial fills | traded volume is 5 lots (FILLED_VOLUME 3 + 2), not 8. |
| `28_self_trade_excluded` | BRD 21 – Self-trade | the 10 lots are excluded from traded volume. |
| `30_presence_met_volume_not_met` | BRD 22 – Presence met but volume not met | Eligibility Flag NO. |
| `31_at_the_requirements` | Additional A24 – Exactly at the requirements | Eligibility Flag YES. |
| `32_33_rollover_lots_added` | BRD 23 – Rollover lots added | Total Volume Traded 45, Rollover Lots Added 25, volume requirement of 40 met. |
| `32_33_rollover_lots_added` | BRD 24 – Rollover contract not traded | Rollover Lots Added 0; only the main contract lots are counted. |
| `32_33_rollover_lots_added_case2` | BRD 23 – Rollover lots added | Total Volume Traded 45, Rollover Lots Added 25, volume requirement of 40 met. |
| `32_33_rollover_lots_added_case2` | BRD 24 – Rollover contract not traded | Rollover Lots Added 0; only the main contract lots are counted. |
| `34_36_not_traded_contract_and_unconfigured_trader` | Additional A25 – Configured contract not traded | the row is shown with 0 seconds and Eligibility Flag NO, and it is recorded in the log. |
| `34_36_not_traded_contract_and_unconfigured_trader` | BRD 25 – Trader not configured | the orders are not reported and the trader ID is recorded in the log. |
| `35_market_maker_with_no_orders` | Additional A8 – Market maker with no orders | all its rows show 0 seconds and Eligibility Flag NO. |
| `37_older_order_partly_filled_plus_new_order` | BRD 26 – Older order partly filled, then a new order at the same price | the level has 5 lots (2 + 3) and both orders are counted. |
| `38_39_report_distribution_and_regeneration` | BRD 27 – Report distribution | A receives only its own report; B’s report is not sent and this is logged; STG receives the consolidated report covering A and B. At the end of the month, the internal email list receives the monthly report of all market makers, and A receives only its own monthly report. |
| `38_39_report_distribution_and_regeneration` | BRD 28 – Obligations updated during the day | the reports can be regenerated for that day with the updated obligations. |
| `40_order_file_not_in_time_order` | Additional A9 – Order file not in time order | the system records it in the log and alerts the Saudi Exchange Operations team before the reports are used. |
| `43_suspended_and_resumed_same_second` | Additional A12 – Deactivated and activated in the same second | 10:20:00 is counted as met (end of second rule); no failure is recorded. |
| `44_resumed_with_different_price` | Additional A13 – Activated with a different price or lots | the order is counted with the price and remaining lots on the resume (0790) row. |
| `45_suspend_on_disconnect` | Additional A14 – Orders deactivated on disconnect | the orders are not counted from the suspend until the resume. |
| `46_suspended_then_cancelled` | Additional A15 – Deactivated order cancelled without being activated | the order is not counted again; the market maker must enter a new order to meet the requirements. |
| `47_better_price_small_then_level1_deleted` | BRD 29 – Better price entered, then the Level 1 order deleted (small order) | spread met (62.50 - 62.40 = 1 tick); order book not met, because 62.40 has 3 lots (5 required) and 62.30 has no order, so there are no five consecutive levels. The same applies to the ask side. |
| `48_better_price_gap_then_level1_deleted` | BRD 30 – Better price entered, then the Level 1 order deleted (gap) | spread met; order book not met, because the next level after 62.40 is 62.20 (2 ticks away) and the price 62.30 has no order. |
| `49_better_price_book_still_complete` | BRD 31 – Better price entered, then the Level 1 order deleted (order book still complete) | spread met and order book met, because 62.40 (5), 62.30 (8), 62.20 (10), 62.10 (12) and 62.00 (15) are five consecutive levels with the required lots, and the bid and ask order books are 1 tick apart (within 2 ticks). |
| `50_market_order_matched_at_uncross` | Additional A16 – Market order entered during pre open and matched at the uncross | the market order is never counted in any order book, as it has no price. Market maker A: from 09:30:00 to 09:30:04 (4 seconds) the spread is not met (62.50 - 62.20 = 3 ticks) and the order book is not met (62.30 has no order); from 09:30:04 both are met again, so the presence time is 21,596 seconds if nothing else changes. Traded volume: 5 lots for market maker A and 5 lots for market maker B (the uncross trade is included in the traded volume of both, as it is not a self-trade). |
| `51_market_order_with_nothing_on_the_other_side` | Additional A17 – Market order with no orders on the other side | the market order is removed immediately; it is not counted in the order book and adds no traded volume; the presence time of market maker A is not affected. |
| `53_market_order_matched_with_own_order` | BRD 33 – Market order matched with the market maker’s own order | the 3 lots traded with the other trader are included in the traded volume of market maker A; the 5 lots traded with itself are excluded (self-trade). Market maker A’s sell order at 45.60 is removed from its order book, so the spread and/or order book obligation is not met from that second until market maker A amends its order book. If the orders of other traders fill the whole market order, no self-trade takes place. |
| `54_eligible_on_index_futures` | BRD 34 – Eligible on Index Futures | Eligibility Flag YES. |
| `55_rollover_on_index_futures_and_ssf` | Additional A18 – Rollover on Index Futures and Single Stock Futures | MT30 Total Volume Traded 110 (Rollover Lots Added 60), Eligibility Flag YES; STC Total Volume Traded 45 (Rollover Lots Added 25), Eligibility Flag YES. The market maker is eligible on both. |
| `56_eligible_on_ssf_not_on_index_futures` | BRD 35 – Eligible on Single Stock Futures but not on Index Futures | STC Eligibility Flag YES; MT30 Eligibility Flag NO. Each contract has its own Eligibility Flag. |
| `57_presence_not_met` | BRD 36 – Presence time not met because of the order book | Total presence time 16,400 seconds, below 17,280; Eligibility Flag NO. |
| `58_spread_and_traded_volume_not_met` | Additional A26 – Spread and traded volume not met | presence time and traded volume are both not met; Eligibility Flag NO. |
| `59_not_all_five_ssfs_covered` | Additional A19 – Not all five Single Stock Futures covered | Maaden and SNB show 0 seconds and Eligibility Flag NO. The market maker does not meet the Single Stock Futures obligation, as it must cover each of the 5 SSFs. In the monthly report, this day is not counted as an eligible day for Single Stock Futures. |
| `60_obligations_changed_between_two_days` | Additional A20 – Obligations changed between two trading days | day 1 Eligibility Flag YES (45 of 40); day 2 Eligibility Flag NO (45 of 50). Each day is measured against the obligations configured for that day, and the day 1 report does not change. |
| `60_obligations_changed_between_two_days_case2` | Additional A20 – Obligations changed between two trading days | day 1 Eligibility Flag YES (45 of 40); day 2 Eligibility Flag NO (45 of 50). Each day is measured against the obligations configured for that day, and the day 1 report does not change. |
| `61_monthly_compliance_rate` | BRD 37 – Monthly compliance rate | in the Derivatives Market Maker Monthly Eligibility Status, the compliance rate is 90% for A on MT30, 95% for B on Single Stock Futures, and 100% for C on both MT30 and Single Stock Futures. The month runs from the first to the last trading day set by the Saudi Exchange Operations team in the MM config file, and the monthly report is produced automatically when the last trading day is processed. |
| `63_contract_suspended_for_one_hour` | Additional A21 – Contract suspended for one hour | the 3,600 suspended seconds are not counted. The Audit Trail shows a Suspended line from 11:00:00 to 12:00:00 (3,600 seconds) and a failure from 12:00:00 to 12:00:05 (5 seconds). The Required Total Presence Time is 14,400 seconds (80% of 18,000), the total presence time is 17,995 seconds, and the Eligibility Flag is YES. |
| `63_required_presence_is_80_percent_of_the_rest` | Additional A21 – Contract suspended for one hour | the 3,600 suspended seconds are not counted. The Audit Trail shows a Suspended line from 11:00:00 to 12:00:00 (3,600 seconds) and a failure from 12:00:00 to 12:00:05 (5 seconds). The Required Total Presence Time is 14,400 seconds (80% of 18,000), the total presence time is 17,995 seconds, and the Eligibility Flag is YES. |
| `64_contract_suspended_for_the_whole_day` | Additional A22 – Contract suspended for the whole day | STC shows 0 seconds, a Required Total Presence Time of 0 and the Eligibility Flag SUSPENDED; the market maker’s other contracts are not affected. In the monthly report this day is not counted for STC; for Single Stock Futures, the market maker only needs to be eligible on its other SSFs that day. |
| `unlisted_order_action_disregarded_and_logged` | Order actions not listed in the BRD | Disregarded and recorded in the log |
