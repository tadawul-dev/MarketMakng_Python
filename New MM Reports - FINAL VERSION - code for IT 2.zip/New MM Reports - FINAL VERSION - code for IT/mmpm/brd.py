"""BRD reports (Derivatives Market Making BRD v.11, REQ 55359).

Derivatives Daily Summary Report = one workbook with three sheets:
  Daily Summary : one row per market maker and contract, in MM config file order
  Streaks       : every continuous period in which an obligation was met
                  (Start = first second met; End = the second it stopped being met, or market close)
  Audit Trail   : one line per period in which an obligation was not met, with every reason
                  and what changed (From = first second not met; To = the second it was met
                  again, or market close; e.g. 10:23:01 to 10:23:02 = 1 second)
The consolidated report covers all market makers; a segregated report holds
only one market maker's rows. File names start with the tool name, New MM Reports.
"""
import datetime as dt
import re
from typing import List, Optional

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .book import BUY, SELL, Book
from .config import Config, Contract
from .engine import METRICS, Result
from .parser import ACTIONS, sec_to_hhmmss
from .daily import DAILY_COLS, as_date, daily_rows

TOOL = "New MM Reports"
TITLE = "Derivatives Daily Summary Report"
DAILY_SHEET, STREAK_SHEET, AUDIT_SHEET = "Daily Summary", "Streaks", "Audit Trail"
BRD_DAILY_COLS = DAILY_COLS + ["Rollover Lots Added"]
STREAK_COLS = ["Date", "MM", "Contract", "Symbol", "Metric", "Start", "End", "Duration (seconds)"]
AUDIT_COLS = ["Date", "MM", "Contract", "Obligation", "From", "To", "Seconds not met", "Reason"]
METRIC_NAME = {"spread": "Spread", "depth": "Depth", "combined": "Fully eligible"}
OBLIGATION = {"spread": "Spread", "depth": "Order book"}

FONT = "Calibri"
HEAD_FILL = PatternFill("solid", fgColor="1F3864")


# ---------------------------------------------------------------- Daily Summary

def summary_rows(summ: pd.DataFrame, vol: pd.DataFrame, cfg: Config, trade_date: str) -> List[dict]:
    """Daily Summary rows (BRD column names), including Rollover Lots Added."""
    v = vol.set_index(["MM", "Contract"])
    rows = daily_rows(summ, vol, cfg, trade_date)
    for r in rows:
        added = v.loc[(r["MMID"], r["_contract"]), "Added lots (rollover)"]
        r["Rollover Lots Added"] = int(added) if pd.notna(added) else 0
    return rows


# ---------------------------------------------------------------- Streaks

def streak_rows(res: Result, cfg: Config, trade_date: str) -> List[dict]:
    """Streaks: End = the second at which the obligation stopped being met (or market close)."""
    order = {c.id: i for i, c in enumerate(cfg.contracts)}
    mm_order = {u: i for i, (_, u) in enumerate(cfg.market_makers)}
    date = as_date(trade_date)
    st = sorted(res.streaks, key=lambda s: (mm_order[s["MM"]], order[s["Contract"]],
                                            METRICS.index(s["Metric"]), s["Start"]))
    return [{"Date": date, "MM": s["MM"], "Contract": s["Symbol"], "Symbol": s["Contract Name"],
             "Metric": METRIC_NAME[s["Metric"]], "Start": sec_to_hhmmss(s["Start"]),
             "End": sec_to_hhmmss(s["End"]), "Duration (seconds)": s["Duration"],
             "_contract": s["Contract"]} for s in st]


# ---------------------------------------------------------------- Audit Trail

def _px(ticks: int, tick: float) -> str:
    return f"{ticks * tick:.2f}"


def _ticks(n: int) -> str:
    return f"{n} tick" if n == 1 else f"{n} ticks"


def spread_reason(book: Book, tick: float, spread_ticks: int) -> Optional[str]:
    """None when the spread obligation is met, else the reason in plain words."""
    b, s = book.best(BUY), book.best(SELL)
    if b is None and s is None:
        return "No buy and no sell orders"
    if b is None:
        return "No buy orders"
    if s is None:
        return "No sell orders"
    gap = s[0] - b[0]
    if gap > spread_ticks:
        return f"Spread of {gap} ticks ({_px(s[0], tick)} - {_px(b[0], tick)}); maximum {spread_ticks} ticks"
    return None


def _side_reason(book: Book, side: str, tick: float) -> str:
    """Why a side has no qualifying order book, level by level from its best price."""
    name = "Buy" if side == BUY else "Sell"
    p = book.prices(side)
    if not p:
        return f"No {name.lower()} orders"
    step = (-1 if side == BUY else 1) * book.level_step
    l1 = max(p) if side == BUY else min(p)
    parts = []
    for k in range(5):
        px = l1 + k * step
        vol, req = p.get(px, 0), book.min_lots[k]
        if vol >= req:
            continue
        if vol > 0:
            part = f"{name} level {k + 1} ({_px(px, tick)}) has {vol} lots; {req} required"
            if k == 0:
                part += "; no complete order book behind it"
            parts.append(part)
            continue
        beyond = [q for q in p if (q < px if side == BUY else q > px)]
        if not beyond:  # nothing further away: the side has only k price levels
            parts.append(f"{name} side has {k} price level{'' if k == 1 else 's'}; 5 required")
            break
        nxt = max(beyond) if side == BUY else min(beyond)
        prev = px - step
        parts.append(f"{name} level {k + 1} should be at {_px(px, tick)} ({_ticks(book.level_step)} from "
                     f"level {k}) but the next {name.lower()} order is at {_px(nxt, tick)} "
                     f"({_ticks(abs(nxt - prev))} away)")
        break
    return "; ".join(parts)


def book_reason(book: Book, tick: float, spread_ticks: int) -> Optional[str]:
    """None when the order book obligation is met, else every reason (both sides)."""
    lb, ls = book.ladder_start(BUY), book.ladder_start(SELL)
    if lb is not None and ls is not None:
        gap = ls - lb
        if gap <= spread_ticks:
            return None
        return (f"Buy order book starts at {_px(lb, tick)} and sell order book at {_px(ls, tick)}; "
                f"{gap} ticks apart; maximum {spread_ticks} ticks")
    if not book.prices(BUY) and not book.prices(SELL):
        return "No buy and no sell orders"
    return "; ".join(_side_reason(book, side, tick) for side, start in ((BUY, lb), (SELL, ls))
                     if start is None)


def _change(r, prev: Optional[tuple], tick: float) -> Optional[str]:
    """One order event in plain words (None for events that do not touch the order book)."""
    side = "buy" if r.side == BUY else "sell"
    price = r.price_ticks if r.price > 0 else (prev[0] if prev else None)
    at = f" at {_px(price, tick)}" if price is not None else ""
    a = r.ORDER_ACTION
    if a == "0772":
        return f"new {side} order{at}, {r.vol} lots (0772)" if r.live else None
    if a == "0775":
        if prev and prev[0] != r.price_ticks:
            return f"{side} order moved from {_px(prev[0], tick)} to {_px(r.price_ticks, tick)} (0775)"
        if prev and prev[1] != r.vol:
            return f"{side} order{at} changed from {prev[1]} to {r.vol} lots (0775)"
        return f"{side} order{at} changed (0775)"
    if a == "0779":
        if r.price <= 0 and not (prev and prev[2]):
            return None  # the market maker's own market order: never in the order book
        return (f"{side} order{at} partially filled (0779); {r.vol} lots left" if r.live
                else f"{side} order{at} fully filled (0779)")
    text = {"0776": "cancelled by the market maker", "0778": "expired", "0788": "price adjusted",
            "0790": "resumed", "0789": "suspended", "0794": "suspended",
            "0793": "cancelled on disconnect"}.get(a)
    if a == "0788":
        return f"{side} order price adjusted to {_px(r.price_ticks, tick)} (0788)"
    return f"{side} order{at} {text} ({a})" if text else f"{side} order{at} {ACTIONS[a][0].lower()} ({a})"


def _what_changed(batch, chains: dict, tick: float, best_before: dict, best_after: dict) -> dict:
    """The order events of one second in plain words, per obligation:
    "depth" (order book) lists every change; "spread" lists only the changes to orders at the
    best bid or best ask (the order was at the best price before, or is at the best price after)."""
    out, spread, kill = [], [], False
    for r in batch:
        prev = chains.get(r.chain)
        if r.ORDER_ACTION == "0795":
            kill = True
        else:
            c = _change(r, prev, tick)
            if c:
                out.append(c)
                was_best = prev is not None and prev[2] and prev[0] == best_before.get(r.side)
                is_best = r.live and r.price > 0 and r.price_ticks == best_after.get(r.side)
                if was_best or is_best:
                    spread.append(c)
        chains[r.chain] = (r.price_ticks if r.price > 0 else (prev or (None,))[0], r.vol, r.live)
    if kill:
        out.insert(0, "all orders cancelled through the Kill Switch (0795)")
        spread.insert(0, "all orders cancelled through the Kill Switch (0795)")
    return {"depth": "; ".join(out), "spread": "; ".join(spread)}


SUSPENDED_REASON = "Trading in this contract was suspended; these seconds are not counted"


def contract_failures(df: pd.DataFrame, mm: str, c: Contract, cfg: Config, date: str = None) -> List[dict]:
    """Audit Trail lines for one market maker and contract: one line per period in which the
    spread or the order book obligation was not met with the same reasons (end of second),
    and one line per suspension of the contract (its seconds are not counted)."""
    sub = df[(df.THIS_REAL_TRADER_ID == mm) & (df.SYMBOL_CODE == c.symbol) & (df.INSTRUMENT_TYPE == c.itype)]
    tick = c.tick
    if len(sub) and abs(sub.tick.iloc[0] - tick) > 1e-12:
        sub = sub.assign(price_ticks=(sub.price / tick).round().astype(int))
    book = Book(min_lots=c.min_lots, level_step=c.level_step)
    chains: dict = {}

    def state():
        return {"spread": spread_reason(book, tick, c.spread_ticks),
                "depth": book_reason(book, tick, c.spread_ticks)}

    points = []  # (second, reasons, what changed) at each second the order book changes
    cur, rows = state(), list(sub.itertuples(index=False))
    i = 0
    def best():
        return {side: (b[0] if b else None) for side, b in ((BUY, book.best(BUY)), (SELL, book.best(SELL)))}

    while i < len(rows):
        t, batch = rows[i].t, []
        before = best()
        while i < len(rows) and rows[i].t == t:
            book.apply(rows[i])
            batch.append(rows[i])
            i += 1
        changed = _what_changed(batch, chains, tick, before, best())
        if t >= cfg.end:
            break
        new = state()
        if t >= cfg.start:
            if not points and t > cfg.start:
                points.append((cfg.start, cur, {}))
            points.append((t, new, changed))
        cur = new
    if not points or points[0][0] > cfg.start:
        points.insert(0, (cfg.start, cur, {}))

    spans = cfg.suspended(c.symbol, date) if date else []
    if spans:  # suspended seconds: no failure lines; the state after a suspension is the book as it stands
        changes = {t: (r, ch) for t, r, ch in points}
        times = sorted(set(changes) | {x for span in spans for x in span if x < cfg.end})
        last, new_points = points[0][1], []
        for t in times:
            if t in changes:
                last = changes[t][0]
            if any(a <= t < b for a, b in spans):
                new_points.append((t, {"spread": None, "depth": None}, {}))
            else:
                new_points.append((t, last, changes[t][1] if t in changes else {}))
        points = new_points

    out = [{"MM": mm, "Contract": c.symbol, "_contract": c.id, "Obligation": "Suspended", "_from": a, "_to": b,
            "_reason": SUSPENDED_REASON, "_changed": ""} for a, b in spans]
    for metric in ("spread", "depth"):
        open_line = None
        for k, (t, reasons, changed) in enumerate(points):
            end = points[k + 1][0] if k + 1 < len(points) else cfg.end
            reason = reasons[metric]
            if open_line and open_line["_reason"] != reason:
                out.append(open_line)
                open_line = None
            if reason and open_line is None:
                open_line = {"MM": mm, "Contract": c.symbol, "_contract": c.id,
                             "Obligation": OBLIGATION[metric], "_from": t, "_reason": reason,
                             "_changed": changed.get(metric, "")}
            if open_line is not None:
                open_line["_to"] = end
        if open_line:
            out.append(open_line)
    for line in out:
        line["From"], line["To"] = sec_to_hhmmss(line["_from"]), sec_to_hhmmss(line["_to"])
        line["Seconds not met"] = line["_to"] - line["_from"]
        line["Reason"] = line["_reason"] + "." + (f" What changed: {line['_changed']}." if line["_changed"] else "")
    return out


def audit_rows(df: pd.DataFrame, cfg: Config, trade_date: str) -> List[dict]:
    date = as_date(trade_date)
    out = []
    for _, mm in cfg.market_makers:
        for c in cfg.presence_contracts:
            lines = contract_failures(df, mm, c, cfg, trade_date)
            lines.sort(key=lambda x: (x["_from"], x["Obligation"] != "Spread"))
            out += [{"Date": date, **x} for x in lines]
    return out


# ---------------------------------------------------------------- workbook

def _sheet(ws, cols: List[str], rows: List[dict], widths: List[int]):
    for i, (col, w) in enumerate(zip(cols, widths), 1):
        cell = ws.cell(row=1, column=i, value=col)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF")
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[1].height = 45
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}1"
    for r, row in enumerate(rows, 2):
        for i, col in enumerate(cols, 1):
            cell = ws.cell(row=r, column=i, value=row[col])
            cell.font = Font(name=FONT)
            if col == "Date":
                cell.number_format = "yyyy-mm-dd"
            elif col == "Total presence time in Percentage":
                cell.number_format = "0.00"
            elif isinstance(row[col], int):
                cell.number_format = "#,##0"
            if col == "Reason":
                cell.alignment = Alignment(wrap_text=True, vertical="top")


def write(path: str, daily: List[dict], streaks: List[dict], audit: List[dict]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = DAILY_SHEET
    _sheet(ws, BRD_DAILY_COLS, daily, [11, 11, 30, 11, 11, 6, 14, 14, 14, 14, 13, 12, 12, 11, 12])
    _sheet(wb.create_sheet(STREAK_SHEET), STREAK_COLS, streaks, [11, 11, 11, 11, 14, 10, 10, 12])
    _sheet(wb.create_sheet(AUDIT_SHEET), AUDIT_COLS, audit, [11, 11, 11, 12, 10, 10, 10, 90])
    wb.save(path)


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9 ._-]+", "", name).strip() or "MM"


def file_name(trade_date: str, mm_name: Optional[str] = None) -> str:
    d = f"{trade_date[:4]}-{trade_date[4:6]}-{trade_date[6:]}"
    return f"{TOOL} - Daily Summary_{d}" + (f"_{safe_name(mm_name)}" if mm_name else "") + ".xlsx"


def only(rows: List[dict], key: str, mm: str) -> List[dict]:
    return [r for r in rows if r[key] == mm]


def trading_date_text(trade_date: str) -> str:
    """e.g. 28th of Sep, 2026 (the BRD's email wording)."""
    d = as_date(trade_date)
    suffix = "th" if 11 <= d.day <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(d.day % 10, "th")
    return f"{d.day}{suffix} of {d.strftime('%b')}, {d.year}"


def as_dt(trade_date: str) -> dt.date:
    return as_date(trade_date)
