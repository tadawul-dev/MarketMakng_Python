/** 
 * #---------------------------------------------------------------------------------------------
 * #   This source is part of the Tadawul Web Listener, Saudi Stock Exchange
 * #   Copyright (c) 2009 Saudi Stock Exchange
 * #
 * #
 * #   All rights reserved.  No part of this source or any copyrights subsisting or arising out of these materials may be reproduced, distributed, amended, modified, adapted, stored in a
 * #   retrieval system, adopted or transmitted in any form or by any means,
 * #   electronic, mechanical, photographic, graphic, optic recording or otherwise,
 * #   translated in any language or computer language, without the prior written
 * #   permission of Saudi Stock Exchange
 * #
 * # ---------------------------------------------------------------------------------------------
 * ---------------------------------------------------------------------------------------------
 * FileName : IndexSummary.java
 *
 * Created Date : 19 April 2018
 *
 * Version             Date                     Author                  Change Description
 *----------------------------------------------------------------------------------------------
 * 1.0                 19 April 2018           Mohanram                  Initial Version
 *----------------------------------------------------------------------------------------------
*/

package sa.com.tadawul.website.tip.messages;

import sa.com.tadawul.website.tip.shared.TipConstants;

/**
 * This Enum is used in the switch statement to identify message type.
 * It is used to identify message type. It will take string 
 * argument and return corresponding number.  
 */

public enum IndexSummary {
	
	IDCODE (1,"i"),
	SOURCEID (2,"Si"),
	DATE (3,"Dt"),
	TIME_EXEC (4,"Tx"),
	CURRENTADJUSTEDVALUE (5,"CAv"),
	INITIALVALUE(6,"Vi"),
	HIGHVALUE(7,"Vh"),
	LOWVALUE(8,"Vl"),
	DIFFDAYPER(9,"Dd"),
	DIFFNETCHANGE(10,"DDn"),
	SEQUENCENO(11,"n");
	
	private int value;
	private String messageTypeStr;

	private IndexSummary(int value, String messageTypeStr) {
		this.value = value;
		this.messageTypeStr = messageTypeStr;
	}

	private static final java.util.Map<String, Integer> LOOKUP = buildLookup();

	private static java.util.Map<String, Integer> buildLookup() {
		java.util.HashMap<String, Integer> m = new java.util.HashMap<>();
		for (IndexSummary e : values()) {
			m.putIfAbsent(e.messageTypeStr, e.value); // first declaration wins, as with the old linear scan
		}
		return java.util.Map.copyOf(m);
	}

	/** O(1), allocation-free and thread-safe (the old version cloned values() and wrote shared statics on every call). */
	public static int getMessageValue(String message) {
		if (message == null) {
			return TipConstants.NODATAFOUND;
		}
		Integer v = LOOKUP.get(message);
		return v != null ? v : TipConstants.NODATAFOUND;
	}
	
}
