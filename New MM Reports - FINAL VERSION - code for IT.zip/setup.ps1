# New MM Reports - one-command setup (Windows PowerShell): installs, then checks every BRD scenario.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$py = if ($env:PYTHON) { $env:PYTHON } else { "python" }
& $py -c "import sys; assert sys.version_info >= (3, 9), 'Python 3.9 or newer is needed'"
& $py -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --quiet --upgrade pip
& .\.venv\Scripts\python.exe -m pip install --quiet -r requirements.txt
Write-Host "Installed. Checking all BRD business scenarios..."
& .\.venv\Scripts\python.exe tests\test_brd_scenarios.py *> setup_check.log
if ($LASTEXITCODE -eq 0) {
  Get-Content setup_check.log -Tail 1
  Write-Host "Ready. Next: fill in the settings (DEPLOYMENT.md section 2) and run the smoke test (section 7)."
} else {
  Get-Content setup_check.log -Tail 20
  Write-Error "NOT ready: some checks failed (full output in setup_check.log)."
}
