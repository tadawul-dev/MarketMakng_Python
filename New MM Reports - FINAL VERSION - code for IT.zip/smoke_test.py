"""Smoke test on a real trading day: run the daily job on a real TSORDR file and compare the
Daily Summary with the expected results in tests/expected/<YYYYMMDD>.json (the business's
results for that day). Prints MATCHES, or every difference.

Usage:  .venv/bin/python smoke_test.py /path/TSORDR-20260921.txt
        (expected results are included for 20260921 and 20261001)
"""
import json
import os
import sys
import tempfile

from mmpm import brd_run, techconfig
from mmpm.config import from_json
from mmpm.parser import load

COLS = ["Total Spread presence time in Seconds", "Total OrderBook presence time in Seconds",
        "Total presence time in Seconds", "Required Total Presence Time (s)", "Total Volume Traded",
        "Required Traded Lots", "Eligibility Flag", "Rollover Lots Added"]


def main(path: str) -> int:
    day = load(path).attrs["action_dates"][0]
    exp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests", "expected", f"{day}.json")
    if not os.path.exists(exp_path):
        sys.exit(f"No expected results for {day}; available: "
                 + ", ".join(sorted(f[:8] for f in os.listdir(os.path.dirname(exp_path)))))
    exp = json.load(open(exp_path))
    tech = techconfig.load()
    tech["output_dir"] = tempfile.mkdtemp(prefix="smoke_")
    brd_run.daily(path, from_json(exp["mm_config"]), tech, send=False)
    got = json.load(open(os.path.join(tech["output_dir"], "results", f"{day}.json")))["daily_summary"]
    key = lambda r: (r["MMID"], r["Contract"])
    g, e = {key(r): r for r in got}, {key(r): r for r in exp["daily_summary"]}
    diffs = [f"{k}: missing" for k in e if k not in g] + [f"{k}: not expected" for k in g if k not in e]
    for k in e:
        if k in g:
            diffs += [f"{k[0]} {k[1]} {c}: expected {e[k][c]}, got {g[k][c]}" for c in COLS if e[k][c] != g[k][c]]
    if diffs:
        print(f"DIFFERENCES for {day} ({len(diffs)}):")
        print("\n".join(diffs))
        return 1
    print(f"MATCHES: {day}, {len(e)} rows, every column identical to the expected results")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    sys.exit(main(sys.argv[1]))
