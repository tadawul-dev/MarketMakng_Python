"""New MM Reports - end-of-month job (BRD): Derivatives Market Maker Monthly Eligibility Status.

Usage:
  .venv/bin/python brd_monthly.py YYYYMM [--no-email]
"""
import sys

from mmpm import brd_run

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--no-email"]
    if len(args) != 1 or len(args[0]) != 6 or not args[0].isdigit():
        sys.exit(__doc__)
    print(brd_run.monthly(args[0], send="--no-email" not in sys.argv))
