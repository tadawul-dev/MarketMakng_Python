# New MM Reports – deployment guide

New MM Reports is the Market Makers Monitor System of the **Derivatives Market Making BRD v.13 (REQ 55359)**. Python 3.9+, no database.

**Deployment in 5 steps**
1. Unzip, then run `./setup.sh` (Linux/macOS) or `.\setup.ps1` (Windows), or build the container (section 1). It must end with **Ready**.
2. Fill in the settings checklist (section 2).
3. Run the smoke test on a real day (section 7). It must print **MATCHES**.
4. Schedule the daily and monthly jobs (section 3).
5. Operations run the email sending test (section 6).

## 1. Install

**Linux / macOS:** `./setup.sh` · **Windows (PowerShell):** `.\setup.ps1`

Both create `.venv`, install the packages in `requirements.txt` and run every BRD business scenario test.
They end with **Ready**, or **NOT ready** with the failing checks (also in `setup_check.log`).
Needs Python 3.9 or newer and access to a Python package index (or an internal mirror).

**Container (optional):** `docker build -t new-mm-reports .` builds an image (Python 3.11) and runs every scenario test
while building, so a broken build fails. The `Dockerfile` shows how to mount the order files, the output folder and the
two configuration files. The image has not been built on the business's machine (no Docker there); IT builds it the first time.

## 2. Configuration files

| File | BRD name | Maintained by | Holds |
|---|---|---|---|
| `mmpm/config.json` | MM config file | Saudi Exchange Operations | Contracts (contract code, symbol, type, tick size, tick variance, SpreadInTicks, lots L1–L5, required traded lots), market makers (ID, name, email list), market open/close time, required presence time, trading suspensions (contract, date, from/to time) |
| `mmpm/technical_config.json` | Technical configuration file | IT | Presence time rule (`end_of_second`), email delivery (`outbox`: the back end sends, see section 6), output folder, holidays |

A rollover contract is a contract row with SpreadInTicks 0 and lots L1–L5 all 0, with the same symbol as the main contract.
SMTP user and password are read from the environment variables named in `technical_config.json` (never stored in files).

**Settings checklist (the only things IT fills in):**

| Setting | Where | Example |
|---|---|---|
| Folder where the TSORDR files arrive from X-Stream | the scheduled command (section 3) | `/data/tsordr/TSORDR-YYYYMMDD.txt` |
| Output folder for reports, results and logs | `technical_config.json` → `output_dir` | `/data/new_mm_reports` |
| Email mode | `technical_config.json` → `email.mode` | `outbox` (the back end sends, section 6) |
| Internal (STG) email list | website Configuration page, section F (stored in `technical_config.json` → `stg_email_list`) | `["stg@saudiexchange.sa"]` |
| Operations email list (alerts) | `technical_config.json` → `operations_email_list` | `["ops@saudiexchange.sa"]` |
| Holidays | `technical_config.json` → `holidays` | `["2026-09-23"]` |
| Contracts, market makers, email lists, market times, monthly periods | `config.json` (Operations' MM config file) | already filled in; Operations add each month's first and last trading day |

## 3. Jobs to schedule

| When | Command | Result |
|---|---|---|
| End of each trading day, after the TSORDR file is fetched from the X-Stream SFTP server | `.venv/bin/python brd_daily.py /path/TSORDR-YYYYMMDD.txt` | Consolidated + segregated Derivatives Daily Summary Reports and log; the back end then emails them (section 6) |
| Last trading day of the month | Nothing extra: when `brd_daily.py` processes the last trading day set by Operations (MM config file, `monthly_periods`), it produces the monthly report automatically | Monthly report for all market makers + one per market maker |
| By hand, if needed | `.venv/bin/python brd_monthly.py YYYYMM` | The same monthly reports for that month |
| Obligations changed for a day | Update the MM config file, then run `brd_daily.py` again for that day | That day is regenerated (`--config <file>` uses a specific MM config file) |

`brd_daily.py` skips Friday, Saturday and the configured holidays. Fetching the file from SFTP is not part of this code (IT scheduler/transfer job). `--no-email` generates the reports without emails.
Both jobs return exit code 0 when everything worked and 1 when a file failed, so the scheduler can raise an alert.

**Linux (cron), Riyadh time:**

```cron
# Sunday-Thursday 17:00, after the day's TSORDR file has arrived
0 17 * * 0-4  cd /opt/new_mm_reports && .venv/bin/python brd_daily.py /data/tsordr/TSORDR-$(date +\%Y\%m\%d).txt >> /data/new_mm_reports/cron.log 2>&1
```
The monthly report needs no job of its own: it is produced with the last trading day of the month.

**Windows (Task Scheduler):** create a daily task (Sunday-Thursday, 17:00) that runs
`C:\new_mm_reports\.venv\Scripts\python.exe brd_daily.py D:\tsordr\TSORDR-<today>.txt` with "Start in" = `C:\new_mm_reports`,
(the monthly report is produced automatically with the last trading day of the month).

## 4. Output (`output_dir` in the technical configuration file)

```
daily/<YYYYMMDD>/New MM Reports - Daily Summary_<YYYY-MM-DD>.xlsx             consolidated (STG)
daily/<YYYYMMDD>/segregated/New MM Reports - Daily Summary_<date>_<MM>.xlsx    one per market maker
results/<YYYYMMDD>.json      Daily Summary rows + MM config file used (input of the monthly report)
monthly/New MM Reports - Monthly Eligibility Status_<YYYY-MM>.xlsx
logs/<YYYYMMDD>.log          everything that happened on each run (keep for one year)
outbox/<run>/*.eml           emails, when email mode is "outbox"
```

## 5. BRD requirement → code

| BRD requirement | Code |
|---|---|
| Arrange orders by ACTION_TIME, then file order | `parser.load` |
| Order file not in sequential order: arrange, log every row, alert Operations | `parser.out_of_order_rows`, `brd_run.daily` |
| Follow each order by ENTRY_ORDER_NUMBER; price = DISCLOSED_PRICE; lots = VOLUME_REMAINING | `parser.load`, `book.Book` |
| Order actions: entry 0772/0775/0788/0790, filled 0779, exit 0776/0778/0793/0795, suspended 0789/0794 | `parser.ACTIONS` |
| Negotiated deals 0802/0805/0806/0807/0809: identified by order action only, no presence, no traded volume | `parser.load` (rows dropped and logged) |
| Any other order action: disregarded and logged | `parser.load`, `brd_run.daily` |
| Market order (no price) not in the order book; counted after Price Adjusted (0788) | `parser.load` (`live` needs a price) |
| Overnight orders arrive again as Queued (0772); every order must start with 0772 | `parser.validate_chains` (file refused otherwise, Operations alerted) |
| Orders of the same market maker at the same price are added together | `book.Book.prices` |
| End of second rule; presence counted only between market open and close | `engine.segments` |
| Spread: Best Bid/Ask within SpreadInTicks; one side missing = not met | `engine.evaluate` |
| Qualifying order book: first price from which 5 levels, one tick variance apart, meet the lots; smaller orders in front are additional liquidity; the two order books within SpreadInTicks | `book.Book.ladder_start`, `engine.evaluate` |
| Tick size and tick variance per contract (defaults 0.1 SSF, 0.5 IF, 1 tick) | `config.Contract` |
| Presence time = seconds where spread and order book are both met | `engine.summary` |
| Trading suspensions: suspended seconds not counted; required presence = 80% of the time not suspended; whole session = SUSPENDED | `config.Config.suspended`, `engine.split_suspended`, `daily.daily_rows`, `brd.contract_failures`, `brd_run.monthly_rows` |
| Traded volume: whole day, FILLED_VOLUME of 0779 rows, self-trades (same MM ID on both sides of a TICKET_NUMBER) excluded | `trades.traded_volume` |
| Rollover lots added to the main contract | `trades.traded_volume`, `brd.summary_rows` |
| Eligibility Flag | `report.daily_rows` |
| Daily Summary, Streaks, Audit Trail sheets (BRD columns and wording) | `brd.py` |
| Consolidated report + one segregated report per market maker (only that market maker's rows) | `brd_run.daily`, `brd.py` |
| Email distribution | **IT back end, see section 6** |
| Monthly Eligibility Status (Index Futures and SSF tables, compliance rate) | `brd_run.monthly` |
| Log | `brd_run.Log` → `logs/<date>.log` |

## 6. Email distribution – to be added by IT in the back end

The job generates the reports; **IT's back end sends them**, using the email lists maintained in the back end.
Set `email.mode` to `outbox` in `technical_config.json` so this code sends nothing itself.

| Report file | Send to | Rule |
|---|---|---|
| `daily/<date>/New MM Reports - Daily Summary_<date>.xlsx` (all market makers) | STG email list | Every trading day, once the reports are generated |
| `daily/<date>/segregated/New MM Reports - Daily Summary_<date>_<MM name>.xlsx` | That market maker's email list (one or more addresses) | Only its own report; a market maker must never receive another market maker's report or data |
| `monthly/New MM Reports - Monthly Eligibility Status_<YYYY-MM>.xlsx` (all market makers) | Internal (STG) email list | When the last trading day of the month is processed |
| `monthly/segregated/New MM Reports - Monthly Eligibility Status_<YYYY-MM>_<MM name>.xlsx` | That market maker's email list | Same time; only its own rows |

**Internal email list (daily and monthly):**
- Daily: subject `Futures Market Makers Performance for the day [Trading Date]`, body `Attached is the Futures Market Makers Performance for the day [Trading Date].`
- Monthly: subject `Futures Market Makers Performance for the month [Month]`, body `Attached is the Futures Market Makers Performance for the month [Month].`
- `[Trading Date]` is written like `30th of Sep, 2026`; `[Month]` like `September 2026`.

- No email list for a market maker: its segregated report is not sent, and this is recorded in the log. The consolidated report is still sent to STG.
- Regenerated day (obligations updated): send the regenerated reports.

**Segregated report email (BRD wording):**

- Subject: `Saudi Exchange Market Making Performance - [Market Maker Name]`
  (example: `Saudi Exchange Market Making Performance - MET TRADERS`)
- Body:

```
Hello All,

Please find attached [Market Maker Name] Market Making performance report for both Single Stock Futures and Index Futures, on the [Trading Date].

Let us know if you have any questions or require further clarification.

Regards
```

- `[Market Maker Name]` = the name as configured by the Saudi Exchange Operations team in the MM config file (same spelling).
- `[Trading Date]` = the trading date of the report, written like `28th of Sep, 2026`.

For reference, the job also writes each of these emails, ready to send, as a `.eml` file in `outbox/`.

**Sending test by the Saudi Exchange Operations team (before go-live)**

Operations must test the sending end to end in the test environment, with test email addresses, and sign off:

- [ ] STG receives the consolidated report, with every market maker.
- [ ] Each market maker's email list receives only its own segregated report (open it: only that market maker's rows on all three sheets).
- [ ] A market maker with two or more addresses: every address receives it.
- [ ] A market maker with no email list: nothing is sent to it, the log records it, and STG still receives the consolidated report (BRD scenario 38).
- [ ] Subject and body as written above, with the market maker name as configured and the right trading date.
- [ ] The attachment opens and is the right day.
- [ ] A regenerated day (MM config file updated) sends the regenerated reports.

## 7. Tests

```bash
.venv/bin/python tests/test_brd_scenarios.py    # all 37 BRD scenarios + 27 additional scenarios (60 tests), must all pass
.venv/bin/python smoke_test.py /path/TSORDR-20260921.txt   # real day: must print MATCHES (also 20261001)
```

`tests/independent_check.py <TSORDR files or folder>` rebuilds every order book from the raw files with the BRD rules only
(no tool code) and compares every second, the traded volume and the Eligibility Flag with the system; on the 23 real days of
26 Aug - 1 Oct 2026 it found 0 differences (about 15 million seconds).

The smoke test runs the daily job on a real order file and compares every Daily Summary value with the business's
results for that day (`tests/expected/`). Use the TSORDR file of 21 Sep 2026 or 1 Oct 2026 from X-Stream.

`tests/scenario_files/` has one folder per business scenario (the BRD v.13 and the document "Additional Business Scenarios"): an order file in the TSORDR format (all 45 columns,
real session 09:30-15:30) and its MM config file, ready to run with `brd_daily.py` in any environment. Its
README lists each folder with the BRD scenario and the expected result. No new test files need to be created.

```bash
.venv/bin/python brd_daily.py --no-email --config tests/scenario_files/<folder>/mm_config.json tests/scenario_files/<folder>/TSORDR-20260930.txt
```

## 8. Decisions not written in the BRD (confirm with the business)

- Consolidated (STG) and monthly email wording: the BRD only defines the market maker email.
- Market open/close time and required presence time are in the MM config file (`time_window`).
- Monthly "actual trading days" = number of days with processed order files in that month.
