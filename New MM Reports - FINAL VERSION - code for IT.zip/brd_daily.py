"""New MM Reports - end-of-day job (BRD): TSORDR file(s) -> Derivatives Daily Summary Report (consolidated and
segregated), emails and log. See mmpm/brd_run.py and DEPLOYMENT.md.

Usage:
  .venv/bin/python brd_daily.py <TSORDR file or folder> [...] [--no-email] [--config mm_config.json]

Weekends (Friday, Saturday) and the holidays in the technical configuration file are skipped.
Running a day again regenerates its reports (e.g. after the MM config file was updated).
"""
import glob
import os
import sys

from mmpm import brd_run, techconfig
from mmpm import config as config_mod
from mmpm.config import ConfigError
from mmpm.daily import as_date


def files_of(args):
    out = []
    for a in args:
        out += sorted(glob.glob(os.path.join(a, "TSORDR-*.txt"))) if os.path.isdir(a) else [a]
    return out


def main(argv):
    send = "--no-email" not in argv
    argv = [a for a in argv if a != "--no-email"]
    cfg_path = None
    if "--config" in argv:
        i = argv.index("--config")
        cfg_path, argv = argv[i + 1], argv[:i] + argv[i + 2:]
    files = files_of(argv)
    if not files:
        sys.exit(__doc__)
    try:
        cfg = config_mod.load(cfg_path) if cfg_path else config_mod.load()
        tech = techconfig.load()
    except ConfigError as e:
        sys.exit(f"Configuration problem: {e}")
    failed = 0
    for p in files:
        name = os.path.basename(p)
        day = name.replace("TSORDR-", "").split(".")[0]
        if day.isdigit() and len(day) == 8 and (as_date(day).weekday() in techconfig.WEEKEND
                                                 or day in tech["holidays"]):
            print(f"{name}: weekend or holiday, skipped")
            continue
        try:
            r = brd_run.daily(p, cfg, tech, send)
            print(f"{name}: {r.consolidated} (+{len(r.segregated)} segregated); "
                  f"{len(r.emails)} emails; log {r.log_path}")
        except Exception as e:
            failed += 1
            print(f"{name}: FAILED: {type(e).__name__}: {e}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
