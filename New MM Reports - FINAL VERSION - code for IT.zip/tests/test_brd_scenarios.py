"""New MM Reports - business scenarios of the BRD (Derivatives Market Making v.11) as automated tests.

Each test builds a small order file (TSORDR format), runs the real code and checks the
expected result written in the BRD. The presence window is the real session, 09:30:00-15:30:00
(21,600 seconds; 17,280 required), so the results are the ones written in the BRD.

Run:  .venv/bin/python tests/test_brd_scenarios.py      (or: pytest tests/)
Save every scenario's order file and MM config file (for testing in any environment):
      .venv/bin/python tests/test_brd_scenarios.py --export tests/scenario_files
"""
import inspect
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mmpm import brd, brd_run  # noqa: E402
from mmpm.config import from_json  # noqa: E402
from mmpm.engine import run, summary  # noqa: E402
from mmpm.parser import load, out_of_order_rows  # noqa: E402
from mmpm.checks import config_warnings  # noqa: E402
from mmpm.trades import traded_volume  # noqa: E402

HEADER = ("ORDER_ACTION|SYMBOL_CODE|MARKET_CODE|ACTION_DATE|ACTION_TIME|THIS_REAL_TRADER_ID|ORDER_NUMBER|"
          "INITIATING_ORDER_NUMBER|ORIGINAL_VOLUME|VOLUME_REMAINING|ORDER_TRANSACTION|VOLUME_TRADED|TICKET_NUMBER|"
          "TRADE_PRICE|FILLED_VOLUME|DISCLOSED_PRICE|INSTRUMENT_TYPE|ENTRY_ORDER_NUMBER|DELETE_REASON|ACTION_TIME_US")
A, B = "MA0000001", "MB0000001"  # market makers A and B
SSF, IF = ("TSTF6V", "TESTFUT", "SSF"), ("IDXF6V", "MT30FUT", "INF")
LOTS = (5, 8, 10, 12, 15)
WINDOW = 21600
FULL_HEADER = "ORDER_ACTION|SYMBOL_CODE|MARKET_CODE|ACTION_DATE|ACTION_TIME|THIS_REAL_TRADER_ID|THIS_REAL_HOUSE_ID|THIS_USER_ORDER_NUMBER|THIS_MEMBER_ACCOUNT_NUMBER|TIF_DATE|TIF_TIME|ORDER_NUMBER|INITIATING_ORDER_NUMBER|ORIGINAL_VOLUME|VOLUME_REMAINING|ORDER_TRANSACTION|ORDER_EXTENDED_VALUE|VOLUME_TRADED|TICKET_NUMBER|TRADE_PRICE|FILLED_VOLUME|NIN_CODE|TRADE_EXTENDED_VALUE|TIF_FLAGS|FILL_FLAGS|THIS_EFFECTIVE_TRADER_ID|DISCLOSED_PRICE|THIS_BROKER_ROLE|PRICE_MODE_CODE|DISCLOSED_VOLUME|NUM_TRADES|INSTRUMENT_TYPE|ENTRY_ORDER_NUMBER|TRIGGER_PRICE|TRIGGER_DIRECTION|TRIGGER_TYPE|INVENTORY_VALIDATED|MARKET_MAKER|POSITION_TYPE|YIELD|CSD_NUMBER|SHORT_SELL|ACTION_ON_LOGOFF|DELETE_REASON|ACTION_TIME_US"


def at(t: int) -> int:
    """Test times are written around 10:00:00; map them onto the real session:
    10:00:SS -> 09:30:SS (market open), earlier times -> one hour earlier (pre open)."""
    if 100000 <= t < 100100:
        return 93000 + (t - 100000)
    if t < 100000:
        return t - 10000
    return t


class Orders:
    """Writes TSORDR rows; keeps ORDER_NUMBER / INITIATING_ORDER_NUMBER consistent like X-Stream."""

    def __init__(self):
        self.rows, self.n, self.cur, self.ticket = [], 0, {}, 0

    def _num(self):
        self.n += 1
        return f"20260930{self.n:012d}"

    def _row(self, action, t, mm, side, px, orig, rem, entry, order_no, init_no, contract=SSF,
             ticket="", trade_px="", filled="", reason=""):
        code, _, itype = contract
        self.rows.append("|".join(map(str, [
            action, code, "SADF", "20260930", at(t), mm, order_no, init_no, orig, rem if rem else "",
            "2" if side == "B" else "1", "", ticket, trade_px, filled, f"{px:.8f}", itype, entry, reason,
            len(self.rows)])))

    def new(self, t, mm, side, px, lots, contract=SSF):
        e = self._num()
        self.cur[e] = [e, mm, side, px, lots, contract]
        self._row("0772", t, mm, side, px, lots, lots, e, e, e, contract)
        return e

    def modify(self, t, e, px=None, lots=None):
        o = self.cur[e]
        new_no = self._num()
        o[3] = o[3] if px is None else px
        o[4] = o[4] if lots is None else lots
        self._row("0775", t, o[1], o[2], o[3], o[4], o[4], e, new_no, o[0], o[5])
        o[0] = new_no

    def action(self, code, t, e, px=None, lots=None):
        """Any other order action on an existing order (cancel, expire, suspend, resume, ...)."""
        o = self.cur[e]
        o[3] = o[3] if px is None else px
        o[4] = o[4] if lots is None else lots
        self._row(code, t, o[1], o[2], o[3], o[4], o[4], e, o[0], o[0], o[5])

    def fill(self, t, e, lots, ticket=None, price=None):
        o = self.cur[e]
        o[4] -= lots
        ticket = ticket or self._ticket()
        self._row("0779", t, o[1], o[2], o[3], o[4] + lots, o[4], e, o[0], o[0], o[5], ticket,
                  f"{price if price is not None else o[3]:.8f}", lots)
        return ticket

    def _ticket(self):
        self.ticket += 1
        return f"2026093000000{self.ticket:07d}"

    def trade(self, t, buyer, seller, lots, px=70.0, contract=SSF):
        """A trade between two traders (fresh orders far from the monitored prices)."""
        tk = self._ticket()
        for mm, side in ((buyer, "B"), (seller, "S")):
            e = self.new(t, mm, side, px, lots, contract)
            self.fill(t, e, lots, tk)
        return tk

    def book(self, t, mm, bid=62.30, ask=62.50, lots=LOTS, step=0.1, sides="BS", contract=SSF):
        ids = {}
        for s, l1, sign in (("B", bid, -1), ("S", ask, 1)):
            if s in sides:
                for k, n in enumerate(lots):
                    ids[(s, k + 1)] = self.new(t, mm, s, round(l1 + sign * k * step, 4), n, contract)
        return ids

    def raw(self, line):
        self.rows.append(line)


def cfg_json(contracts=(SSF,), extra=(), required_presence=17280, required_lots=40, level_step=1, tick=None,
             suspensions=()):
    cs = []
    for code, sym, itype in contracts:
        c = {"contract_code": code, "symbol": sym, "instrument_type": itype, "level_step": level_step,
             "required_lots": required_lots if itype == "SSF" else 100}
        if tick:
            c["tick_size"] = tick
        cs.append(c)
    return {"contracts": cs + list(extra),
            "market_makers": [{"name": "MM A", "user_id": A}, {"name": "MM B", "user_id": B}],
            "time_window": {"start": "09:30:00", "end": "15:30:00"},
            "required_presence_seconds": required_presence, "suspensions": list(suspensions)}


EXPORT_DIR = None  # set by --export: every order file used by a test is also saved there
_exported = {}


def export(o: Orders, cfg: dict, name: str = None):
    """Save the order file (TSORDR format) and the MM config file of the calling test."""
    if not EXPORT_DIR:
        return
    name = name or next(f.function for f in inspect.stack() if f.function.startswith("test_"))
    n = _exported[name] = _exported.get(name, 0) + 1
    folder = os.path.join(EXPORT_DIR, name[5:] + (f"_case{n}" if n > 1 else ""))
    os.makedirs(folder, exist_ok=True)
    cols, full = HEADER.split("|"), FULL_HEADER.split("|")
    with open(os.path.join(folder, "TSORDR-20260930.txt"), "w") as f:
        f.write(FULL_HEADER + "\n")
        for row in o.rows:
            v = dict(zip(cols, row.split("|")))
            f.write("|".join(v.get(c, "") for c in full) + "\n")
    with open(os.path.join(folder, "mm_config.json"), "w") as f:
        json.dump(cfg, f, indent=2)


def run_case(o: Orders, **cfg_kw):
    cfg_dict = cfg_json(**cfg_kw)
    export(o, cfg_dict)
    cfg = from_json(cfg_dict)
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        f.write(HEADER + "\n" + "\n".join(o.rows) + "\n")
    df = load(f.name)
    res = run(df, "new", cfg)
    rows = brd.summary_rows(summary(df, res, cfg), traded_volume(df, cfg), cfg, "20260930")
    audit = brd.audit_rows(df, cfg, "20260930")
    os.unlink(f.name)
    out = {}
    for r in rows:
        out[(r["MMID"], r["Contract"])] = {
            "spread": r["Total Spread presence time in Seconds"], "book": r["Total OrderBook presence time in Seconds"],
            "total": r["Total presence time in Seconds"], "lots": r["Total Volume Traded"],
            "flag": r["Eligibility Flag"], "rollover": r["Rollover Lots Added"],
            "audit": [a for a in audit if a["MM"] == r["MMID"] and a["Contract"] == r["Contract"]]}
    out["warnings"] = config_warnings(df, cfg)
    out["df"] = df
    return out


def a_(r, contract=SSF):
    return r[(A, contract[0])]


# ---------------------------------------------------------------- order book and spread

def test_01_full_order_book():
    o = Orders(); o.book(95000, A)
    r = a_(run_case(o))
    assert (r["spread"], r["book"], r["total"]) == (WINDOW, WINDOW, WINDOW)


def test_02_additional_order_in_front():
    o = Orders(); o.book(95000, A); o.new(95000, A, "S", 62.40, 3)
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (WINDOW, WINDOW)


def test_03_two_orders_same_price_newer_deleted():
    o = Orders(); o.book(95000, A); e = o.new(95000, A, "S", 62.50, 5); o.action("0776", 100005, e)
    assert a_(run_case(o))["book"] == WINDOW


def test_04_top_up_at_same_price():
    o = Orders(); ids = o.book(95000, A, lots=(3, 8, 10, 12, 15), sides="B"); o.book(95000, A, sides="S")
    o.new(95000, A, "B", 62.30, 2)
    assert a_(run_case(o))["book"] == WINDOW


def test_05_partial_fill_then_top_up():
    o = Orders(); ids = o.book(95000, A); o.fill(100005, ids[("B", 1)], 3); o.new(100010, A, "B", 62.30, 3)
    r = a_(run_case(o))
    assert r["book"] == WINDOW - 5 and r["spread"] == WINDOW


def test_06_best_bid_below_required_size():
    o = Orders(); o.book(95000, A, sides="S")
    for px, n in ((62.30, 3), (62.20, 8), (62.10, 10), (62.00, 12), (61.90, 15)):
        o.new(95000, A, "B", px, n)
    r = a_(run_case(o))
    assert r["book"] == 0
    assert "Buy level 1 (62.30) has 3 lots; 5 required; no complete order book behind it" in r["audit"][-1]["Reason"]


def test_07_small_orders_at_tight_spread():
    o = Orders(); o.book(95000, A, bid=62.10, ask=62.50); o.new(95000, A, "B", 62.30, 1); o.new(95000, A, "S", 62.40, 1)
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (WINDOW, 0)
    assert "4 ticks apart; maximum 2 ticks" in r["audit"][0]["Reason"]


def test_08_wide_spread():
    o = Orders(); o.book(95000, A, bid=62.30, ask=62.60)
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (0, 0)
    assert r["audit"][0]["Reason"].startswith("Spread of 3 ticks (62.60 - 62.30); maximum 2 ticks")


def test_09_missing_price_level():
    o = Orders(); o.book(95000, A, sides="B")
    for px, n in ((62.40, 3), (62.50, 5), (62.60, 8)):
        o.new(95000, A, "S", px, n)
    assert a_(run_case(o))["book"] == 0


def test_13_spread_at_the_maximum():
    o = Orders(); o.book(95000, A, bid=62.30, ask=62.50)
    assert a_(run_case(o))["spread"] == WINDOW


def test_14_only_one_side():
    o = Orders(); o.book(95000, A, sides="B")
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (0, 0) and r["audit"][0]["Reason"].startswith("No sell orders")


def test_18_price_level_more_than_one_tick_away():
    o = Orders(); o.book(95000, A, sides="B")
    for px, n in ((62.50, 5), (62.60, 8), (62.80, 10), (62.90, 12), (63.00, 15)):
        o.new(95000, A, "S", px, n)
    r = a_(run_case(o))
    assert r["book"] == 0
    assert ("Sell level 3 should be at 62.70 (1 tick from level 2) but the next sell order is at 62.80 "
            "(2 ticks away)") in r["audit"][-1]["Reason"]


def test_19_middle_level_below_required_size():
    o = Orders(); o.book(95000, A, lots=(5, 8, 8, 12, 15), sides="B"); o.book(95000, A, sides="S")
    r = a_(run_case(o))
    assert r["book"] == 0 and "Buy level 3 (62.10) has 8 lots; 10 required" in r["audit"][-1]["Reason"]


def test_20_configured_tick_variance_of_two_ticks():
    o = Orders(); o.book(95000, A, step=0.2)
    assert a_(run_case(o, level_step=2))["book"] == WINDOW
    o = Orders(); o.book(95000, A, step=0.1)
    assert a_(run_case(o, level_step=2))["book"] == 0


def test_21_index_futures_tick_size():
    o = Orders(); o.book(95000, A, bid=1442.5, ask=1443.5, step=0.5, contract=IF)
    r = run_case(o, contracts=(IF,))[(A, IF[0])]
    assert (r["spread"], r["book"]) == (WINDOW, WINDOW)


def test_22_other_market_makers_not_counted():
    o = Orders(); o.book(95000, B)
    assert a_(run_case(o))["total"] == 0


# ---------------------------------------------------------------- orders at the same price / better price

def test_37_older_order_partly_filled_plus_new_order():
    o = Orders(); ids = o.book(95000, A); o.fill(100005, ids[("B", 1)], 3); o.new(100005, A, "B", 62.30, 3)
    assert a_(run_case(o))["book"] == WINDOW


def test_47_better_price_small_then_level1_deleted():
    o = Orders(); ids = o.book(95000, A); o.new(100005, A, "B", 62.40, 3); o.action("0776", 100010, ids[("B", 1)])
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (WINDOW, 10)


def test_48_better_price_gap_then_level1_deleted():
    o = Orders(); ids = o.book(95000, A); o.new(100005, A, "B", 62.40, 5); o.action("0776", 100010, ids[("B", 1)])
    r = a_(run_case(o))
    assert (r["spread"], r["book"]) == (WINDOW, 10)


def test_49_better_price_book_still_complete():
    o = Orders(); o.book(95000, A, sides="S")
    x = o.new(95000, A, "B", 62.30, 5)
    for px, n in ((62.30, 8), (62.20, 10), (62.10, 12), (62.00, 15), (61.90, 15)):
        o.new(95000, A, "B", px, n)
    o.new(100005, A, "B", 62.40, 5); o.action("0776", 100010, x)
    assert a_(run_case(o))["book"] == WINDOW


# ---------------------------------------------------------------- end of second

def test_15_change_and_top_up_same_second():
    o = Orders(); ids = o.book(95000, A); o.modify(100010, ids[("B", 4)], lots=8); o.new(100010, A, "B", 62.00, 4)
    assert a_(run_case(o))["book"] == WINDOW


def test_16_late_top_up():
    o = Orders(); ids = o.book(95000, A); o.modify(100010, ids[("B", 4)], lots=8); o.new(100015, A, "B", 62.00, 4)
    r = a_(run_case(o))
    assert r["book"] == WINDOW - 5
    line = r["audit"][0]
    assert (line["From"], line["To"], line["Seconds not met"]) == ("09:30:10", "09:30:14", 5)
    assert "Buy level 4 (62.00) has 8 lots; 12 required" in line["Reason"]
    assert "What changed: buy order at 62.00 changed from 12 to 8 lots (0775)" in line["Reason"]


def test_17_order_added_and_removed_same_second():
    o = Orders(); o.book(95000, A, lots=(5, 8, 10, 12, 14)); e = o.new(100005, A, "B", 61.90, 1)
    o.action("0776", 100005, e)
    assert a_(run_case(o))["book"] == 0


def test_23_24_62_orders_before_open_and_overnight_orders():
    o = Orders(); o.book(80000, A)  # entered in pre open / re-sent overnight orders arrive as 0772
    assert a_(run_case(o))["total"] == WINDOW


# ---------------------------------------------------------------- order actions

def test_10_41_42_suspended_and_resumed():
    o = Orders(); ids = o.book(95000, A); o.action("0789", 100000, ids[("B", 1)]); o.action("0790", 100010, ids[("B", 1)])
    r = a_(run_case(o))
    assert r["total"] == WINDOW - 10 and "suspended (0789)" in r["audit"][0]["Reason"]


def test_43_suspended_and_resumed_same_second():
    o = Orders(); ids = o.book(95000, A); o.action("0789", 100010, ids[("B", 1)]); o.action("0790", 100010, ids[("B", 1)])
    r = a_(run_case(o))
    assert r["total"] == WINDOW and r["audit"] == []


def test_44_resumed_with_different_price():
    o = Orders(); ids = o.book(95000, A); o.action("0789", 100005, ids[("B", 1)])
    o.action("0790", 100010, ids[("B", 1)], px=61.80, lots=15)
    assert a_(run_case(o))["book"] == 5  # 10:00:00-10:00:04 only; the resumed order is at 61.80


def test_45_suspend_on_disconnect():
    o = Orders(); ids = o.book(95000, A); o.action("0794", 100005, ids[("S", 1)]); o.action("0790", 100015, ids[("S", 1)])
    assert a_(run_case(o))["total"] == WINDOW - 10


def test_46_suspended_then_cancelled():
    o = Orders(); ids = o.book(95000, A); o.action("0789", 100005, ids[("S", 1)]); o.action("0776", 100010, ids[("S", 1)])
    assert a_(run_case(o))["total"] == 5


def test_25_cancel_on_disconnect():
    o = Orders(); ids = o.book(95000, A); o.action("0793", 100010, ids[("S", 1)])
    r = a_(run_case(o))
    assert r["total"] == 10 and "cancelled on disconnect (0793)" in r["audit"][0]["Reason"]


def test_26_kill_switch():
    o = Orders(); ids = o.book(95000, A)
    for e in ids.values():
        o.action("0795", 100010, e)
    r = a_(run_case(o))
    assert r["total"] == 10 and "all orders cancelled through the Kill Switch (0795)" in r["audit"][0]["Reason"]


def test_unlisted_order_action_disregarded_and_logged():
    o = Orders(); ids = o.book(95000, A); o.action("0791", 100010, ids[("B", 1)])
    res = run_case(o)
    assert a_(res)["total"] == WINDOW and res["df"].attrs["unknown_actions"] == {"0791": 1}


# ---------------------------------------------------------------- market orders

def test_11_52_market_order_partly_matched_rest_converted():
    o = Orders(); o.book(95000, A)
    m = o.new(100005, B, "S", 0.0, 8)                       # market sell, no price
    tk = o._ticket()
    o.fill(100005, m, 3, tk, price=62.30)
    o.fill(100005, o.new(95000, A, "B", 62.30, 3), 3, tk)   # A's extra 3 lots at the best bid
    o.action("0788", 100005, m, px=62.30)                    # rest converted to a limit order
    assert o.cur[m][4] == 5
    res = run_case(o)
    assert res[(B, SSF[0])]["lots"] == 3 and a_(res)["lots"] == 3


def test_50_market_order_matched_at_uncross():
    o = Orders(); ids = o.book(90000, A)
    m = o.new(91500, B, "S", 0.0, 5)
    tk = o._ticket()
    o.fill(100000, m, 5, tk, price=62.30); o.fill(100000, ids[("B", 1)], 5, tk)
    o.new(100004, A, "B", 62.30, 5)
    res = run_case(o)
    assert a_(res)["total"] == WINDOW - 4 and a_(res)["lots"] == 5 and res[(B, SSF[0])]["lots"] == 5


def test_51_market_order_with_nothing_on_the_other_side():
    o = Orders(); o.book(95000, A); m = o.new(100005, A, "B", 0.0, 5); o.action("0778", 100005, m)
    r = a_(run_case(o))
    assert (r["total"], r["lots"]) == (WINDOW, 0)


def test_53_market_order_matched_with_own_order():
    o = Orders(); o.book(95000, A)
    other = o.new(95500, B, "S", 62.50, 3)
    m = o.new(100005, A, "B", 0.0, 8)
    t1, t2 = o._ticket(), o._ticket()
    o.fill(100005, m, 3, t1, price=62.50); o.fill(100005, other, 3, t1)
    own = [e for e, v in o.cur.items() if v[1] == A and v[2] == "S" and abs(v[3] - 62.50) < 1e-9][0]
    o.fill(100005, m, 5, t2, price=62.50); o.fill(100005, own, 5, t2)
    r = a_(run_case(o))
    assert r["lots"] == 3                 # the 5 self-traded lots are excluded
    assert r["book"] == 5 and r["spread"] == 5  # A's best ask is gone from 10:00:05


# ---------------------------------------------------------------- traded volume and eligibility

def test_27_partial_fills_use_filled_volume():
    o = Orders(); e = o.new(160000, A, "B", 70.0, 5); f = o.new(160000, B, "S", 70.0, 5)
    t1 = o.fill(160001, e, 3); o.fill(160001, f, 3, t1)
    t2 = o.fill(160002, e, 2); o.fill(160002, f, 2, t2)
    assert a_(run_case(o))["lots"] == 5


def test_28_self_trade_excluded():
    o = Orders(); o.trade(160000, A, A, 10)
    assert a_(run_case(o))["lots"] == 0


def test_12_29_negotiated_deals_not_counted():
    o = Orders(); o.book(95000, A)
    o.raw(f"0802|TSTF6V|SADF|20260930|110000|{A}|20260930999999999999|20260930999999999999|5||2||2026093099999|62.30000000|5|62.30000000|SSF|20260930999999999999||0")
    r = a_(run_case(o))
    assert (r["lots"], r["total"]) == (0, WINDOW)  # the deal adds no lots and does not change the order book


def test_30_presence_met_volume_not_met():
    o = Orders(); o.book(95000, A); o.trade(160000, A, B, 30)
    r = a_(run_case(o))
    assert (r["total"], r["lots"], r["flag"]) == (WINDOW, 30, "NO")


def test_31_at_the_requirements():
    o = Orders(); o.book(95000, A); o.trade(160000, A, B, 40)
    r = a_(run_case(o, required_presence=WINDOW))
    assert (r["total"], r["lots"], r["flag"]) == (WINDOW, 40, "YES")


def test_57_presence_not_met():
    o = Orders(); ids = o.book(95000, A); o.action("0776", 100010, ids[("B", 5)]); o.trade(160000, A, B, 60)
    r = a_(run_case(o))
    assert (r["total"], r["flag"]) == (10, "NO")


def test_32_33_rollover_lots_added():
    roll = {"contract_code": "TSTF6U", "symbol": "TESTFUT", "instrument_type": "SSF",
            "spread_ticks": 0, "min_lots": [0, 0, 0, 0, 0]}
    o = Orders(); o.book(95000, A)
    o.trade(160000, A, B, 25, contract=("TSTF6U", "TESTFUT", "SSF")); o.trade(160000, A, B, 20)
    r = a_(run_case(o, extra=[roll]))
    assert (r["lots"], r["rollover"], r["flag"]) == (45, 25, "YES")
    o = Orders(); o.book(95000, A); o.trade(160000, A, B, 20)
    assert a_(run_case(o, extra=[roll]))["rollover"] == 0


def test_34_36_not_traded_contract_and_unconfigured_trader():
    o = Orders(); o.new(95000, "MX9999999", "B", 62.30, 5)
    res = run_case(o, contracts=(SSF, IF))
    assert res[(A, IF[0])]["total"] == 0 and res[(A, IF[0])]["flag"] == "NO"
    assert any("MX9999999" in w for w in res["warnings"])
    assert any("IDXF6V" in w for w in res["warnings"])


def test_40_order_file_not_in_time_order():
    o = Orders(); o.book(100005, A); o.new(100001, A, "B", 60.0, 1)
    export(o, cfg_json())
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        f.write(HEADER + "\n" + "\n".join(o.rows) + "\n")
    bad = out_of_order_rows(load(f.name))
    os.unlink(f.name)
    assert len(bad) == 1 and bad[0]["ACTION_TIME"] == "09:30:01"


def test_61_monthly_compliance_rate():
    days = []
    for d in range(20):
        days.append({"daily_summary": [
            {"MMID": A, "Symbol": "MT30FUT", "Type": "IF", "Eligibility Flag": "YES" if d < 18 else "NO"},
            {"MMID": B, "Symbol": "7010FUT", "Type": "SSF", "Eligibility Flag": "YES" if d < 19 else "NO"},
            {"MMID": B, "Symbol": "2222FUT", "Type": "SSF", "Eligibility Flag": "YES"}]})
    if EXPORT_DIR:  # the 20 days' results, as the daily job keeps them (input of the monthly job)
        folder = os.path.join(EXPORT_DIR, "61_monthly_compliance_rate", "results")
        os.makedirs(folder, exist_ok=True)
        for d, day in enumerate(days):
            with open(os.path.join(folder, f"202609{d + 1:02d}.json"), "w") as f:
                json.dump({"trade_date": f"202609{d + 1:02d}", **day}, f, indent=1)
    rows = {(r["Market Maker"], r["Type"]): r for r in brd_run.monthly_rows(days)}
    assert rows[(A, "IF")]["Compliance Rate"] == 90.0 and rows[(A, "IF")]["Underlying"] == "MT30FUT"
    assert rows[(B, "SSF")]["Compliance Rate"] == 95.0      # one SSF failed on 1 day -> that day is not eligible
    assert rows[(B, "SSF")]["Underlying"] == "7010FUT, 2222FUT"


def test_59_61_ssf_day_fails_when_one_ssf_fails():
    days = [{"daily_summary": [{"MMID": A, "Symbol": s, "Type": "SSF", "Eligibility Flag": f}
                               for s, f in (("7010FUT", "YES"), ("2222FUT", "YES"), ("1120FUT", "NO"))]},
            {"daily_summary": [{"MMID": A, "Symbol": s, "Type": "SSF", "Eligibility Flag": "YES"}
                               for s in ("7010FUT", "2222FUT", "1120FUT")]}]
    r = brd_run.monthly_rows(days)
    assert len(r) == 1 and r[0]["Market Makers eligibility days"] == 1 and r[0]["Compliance Rate"] == 50.0




def test_61_month_end_reports_sent_automatically():
    o = Orders(); o.book(95000, A); o.book(95000, B); o.trade(160000, A, B, 40)
    cfg_dict = cfg_json()
    cfg_dict["market_makers"][0]["email_list"] = ["mm.a@example.com"]  # MM B has no email list
    cfg_dict["monthly_periods"] = [{"month": "2026-09", "first_trading_day": "2026-09-01", "last_trading_day": "2026-09-30"}]
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "TSORDR-20260930.txt")
        with open(path, "w") as f:
            f.write(HEADER + "\n" + "\n".join(o.rows) + "\n")
        out = os.path.join(tmp, "out")
        os.makedirs(os.path.join(out, "results"))
        with open(os.path.join(out, "results", "20260831.json"), "w") as f:  # before the period: left out
            json.dump({"trade_date": "20260831", "daily_summary": [
                {"MMID": A, "Market Maker": "MM A", "Symbol": "TESTFUT", "Type": "SSF", "Eligibility Flag": "NO"}]}, f)
        tech = {"presence_time_rule": "end_of_second", "stg_email_list": ["stg@example.com"],
                "operations_email_list": [], "email": {"mode": "outbox", "sender": "x@example.com"},
                "output_dir": out, "holidays": []}
        r = brd_run.daily(path, from_json(cfg_dict), tech, send=True)   # 30 Sep = last trading day
        assert r.monthly.endswith("Monthly Eligibility Status_2026-09.xlsx")
        import email
        import glob as g
        import email.policy
        msgs = [email.message_from_bytes(open(x, "rb").read(), policy=email.policy.default)
                for x in g.glob(os.path.join(out, "outbox", "*", "*.eml"))]
        subjects = {(m["To"], m["Subject"]) for m in msgs}
        assert ("stg@example.com", "Futures Market Makers Performance for the month September 2026") in subjects
        assert ("mm.a@example.com", "Saudi Exchange Market Making Performance - MM A") in subjects
        internal = [m for m in msgs if m["Subject"] == "Futures Market Makers Performance for the month September 2026"][0]
        assert "Attached is the Futures Market Makers Performance for the month September 2026." in internal.get_body().get_content()
        import pandas as pd
        own = g.glob(os.path.join(out, "monthly", "segregated", "*MM A.xlsx"))[0]
        mm_rows = pd.read_excel(own, header=None).astype(str)
        assert (mm_rows == A).any().any() and not (mm_rows == B).any().any()   # only its own rows
        rows = brd_run.monthly_rows([json.load(open(x)) for x in sorted(g.glob(os.path.join(out, "results", "*.json")))
                                     if "20260901" <= os.path.basename(x)[:8] <= "20260930"])
        assert all(x["Actual trading days"] == 1 for x in rows)          # 31 Aug is outside the period
        assert any("Last trading day of 2026-09" in line for line in r.log)

# ---------------------------------------------------------------- trading suspensions

def test_63_contract_suspended_for_one_hour():
    o = Orders(); ids = o.book(95000, A); o.trade(160000, A, B, 40)
    for e in ids.values():                       # orders pulled when the halt starts ...
        o.action("0776", 110000, e)
    o.book(120005, A)                            # ... and re-entered 5 seconds after it ends
    susp = [{"contract_code": SSF[0], "date": "2026-09-30", "from": "11:00", "to": "12:00"}]
    r = a_(run_case(o, suspensions=susp))
    assert r["total"] == WINDOW - 3600 - 5       # 18,000 s not suspended, 5 s not met
    lines = [(x["Obligation"], x["From"], x["To"], x["Seconds not met"]) for x in r["audit"]]
    assert ("Suspended", "11:00:00", "11:59:59", 3600) in lines
    assert ("Order book", "12:00:00", "12:00:04", 5) in lines and ("Spread", "12:00:00", "12:00:04", 5) in lines
    assert not any(x["Obligation"] != "Suspended" and "11:00:00" <= x["From"] < "12:00:00" for x in r["audit"])
    assert r["flag"] == "YES"                    # 17,995 >= 14,400 (80% of 18,000) and 40 lots


def test_63_required_presence_is_80_percent_of_the_rest():
    o = Orders(); ids = o.book(95000, A); o.trade(160000, A, B, 40)
    for e in ids.values():
        o.action("0776", 143000, e)              # gone from 14:30: met 09:30-11:00 + 12:00-14:30 = 14,400 s
    susp = [{"contract_code": SSF[0], "date": "2026-09-30", "from": "11:00", "to": "12:00"}]
    res = run_case(o, suspensions=susp)
    r = a_(res)
    assert r["total"] == 14400 and r["flag"] == "YES"   # 80% of the 18,000 s not suspended, to the second


def test_64_contract_suspended_for_the_whole_day():
    o = Orders(); o.book(95000, A); o.book(95000, A, bid=1442.5, ask=1443.5, step=0.5, contract=IF)
    o.trade(160000, A, B, 120, px=1500.0, contract=IF)
    susp = [{"contract_code": SSF[0], "date": "2026-09-30"}]
    res = run_case(o, contracts=(SSF, IF), suspensions=susp)
    s_, i_ = res[(A, SSF[0])], res[(A, IF[0])]
    assert (s_["total"], s_["flag"]) == (0, "SUSPENDED")
    assert [x["Obligation"] for x in s_["audit"]] == ["Suspended"]
    assert i_["flag"] == "YES"                   # the other contract is not affected


def test_64_monthly_skips_suspended_days():
    days = [{"daily_summary": [{"MMID": A, "Symbol": "MT30FUT", "Type": "IF", "Eligibility Flag": f},
                               {"MMID": A, "Symbol": "7010FUT", "Type": "SSF", "Eligibility Flag": s1},
                               {"MMID": A, "Symbol": "2222FUT", "Type": "SSF", "Eligibility Flag": s2}]}
            for f, s1, s2 in (("YES", "YES", "YES"), ("SUSPENDED", "SUSPENDED", "YES"), ("NO", "YES", "NO"), ("YES", "SUSPENDED", "SUSPENDED"))]
    rows = {r["Type"]: r for r in brd_run.monthly_rows(days)}
    assert (rows["IF"]["Actual trading days"], rows["IF"]["Market Makers eligibility days"]) == (3, 2)
    assert (rows["SSF"]["Actual trading days"], rows["SSF"]["Market Makers eligibility days"]) == (3, 2)
    for k, day in enumerate(days, 1):
        day["trade_date"] = f"2026090{k}"
    rows = {r["Type"]: r for r in brd_run.monthly_rows(days)}
    assert rows["IF"]["Suspensions"] == "MT30FUT (2 Sep 2026)"
    assert rows["SSF"]["Suspensions"] == "7010FUT (2 Sep 2026); 7010FUT (4 Sep 2026); 2222FUT (4 Sep 2026)"

# ---------------------------------------------------------------- more eligibility cases

def test_35_market_maker_with_no_orders():
    o = Orders(); o.book(95000, A); o.trade(160000, A, "MX9999999", 40)
    r = run_case(o)[(B, SSF[0])]
    assert (r["total"], r["lots"], r["flag"]) == (0, 0, "NO")


def test_54_eligible_on_index_futures():
    o = Orders(); o.book(95000, A, bid=1442.5, ask=1443.5, step=0.5, contract=IF); o.trade(160000, A, B, 120, px=1500.0, contract=IF)
    r = run_case(o, contracts=(IF,))[(A, IF[0])]
    assert (r["total"], r["lots"], r["flag"]) == (WINDOW, 120, "YES")


def test_55_rollover_on_index_futures_and_ssf():
    roll_if = {"contract_code": "IDXF6U", "symbol": "MT30FUT", "instrument_type": "INF", "spread_ticks": 0, "min_lots": [0] * 5}
    roll_ssf = {"contract_code": "TSTF6U", "symbol": "TESTFUT", "instrument_type": "SSF", "spread_ticks": 0, "min_lots": [0] * 5}
    o = Orders(); o.book(95000, A); o.book(95000, A, bid=1442.5, ask=1443.5, step=0.5, contract=IF)
    o.trade(160000, A, B, 60, px=1500.0, contract=("IDXF6U", "MT30FUT", "INF")); o.trade(160000, A, B, 50, px=1500.0, contract=IF)
    o.trade(160000, A, B, 25, contract=("TSTF6U", "TESTFUT", "SSF")); o.trade(160000, A, B, 20)
    o.trade(160000, A, B, 50, contract=("TSTF6Z", "TESTFUT", "SSF"))  # December contract, not configured: ignored
    res = run_case(o, contracts=(SSF, IF), extra=[roll_if, roll_ssf])
    i, s = res[(A, IF[0])], res[(A, SSF[0])]
    assert (i["lots"], i["rollover"], i["flag"]) == (110, 60, "YES")
    assert (s["lots"], s["rollover"], s["flag"]) == (45, 25, "YES")
    assert any("TSTF6Z" in w and "not in the configuration" in w for w in res["warnings"])


def test_56_eligible_on_ssf_not_on_index_futures():
    o = Orders(); o.book(95000, A); o.book(95000, A, bid=1442.5, ask=1443.5, step=0.5, contract=IF)
    o.trade(160000, A, B, 50); o.trade(160000, A, B, 80, px=1500.0, contract=IF)
    res = run_case(o, contracts=(SSF, IF))
    assert res[(A, SSF[0])]["flag"] == "YES" and res[(A, IF[0])]["flag"] == "NO" and res[(A, IF[0])]["lots"] == 80


def test_58_spread_and_traded_volume_not_met():
    o = Orders(); o.book(95000, A, bid=62.30, ask=62.60); o.trade(160000, A, B, 20)
    r = a_(run_case(o))
    assert (r["spread"], r["total"], r["lots"], r["flag"]) == (0, 0, 20, "NO")


def test_59_not_all_five_ssfs_covered():
    five = tuple((f"S{k}TF6V", f"S{k}FUT", "SSF") for k in range(1, 6))
    o = Orders()
    for c in five[:3]:
        o.book(95000, A, contract=c); o.trade(160000, A, B, 40, contract=c)
    res = run_case(o, contracts=five)
    assert [res[(A, c[0])]["flag"] for c in five] == ["YES", "YES", "YES", "NO", "NO"]
    assert res[(A, five[3][0])]["total"] == 0 and res[(A, five[4][0])]["total"] == 0


def test_60_obligations_changed_between_two_days():
    o = Orders(); o.book(95000, A); o.trade(160000, A, B, 45)
    assert a_(run_case(o, required_lots=40))["flag"] == "YES"   # day 1: 40 lots required
    assert a_(run_case(o, required_lots=50))["flag"] == "NO"    # day 2: 50 lots required


def test_38_39_report_distribution_and_regeneration():
    o = Orders(); o.book(95000, A); o.book(95000, B); o.trade(160000, A, B, 40)
    cfg_dict = cfg_json()
    cfg_dict["market_makers"][0]["email_list"] = ["mm.a@example.com"]  # MM B has no email list
    export(o, cfg_dict)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "TSORDR-20260930.txt")
        with open(path, "w") as f:
            f.write(HEADER + "\n" + "\n".join(o.rows) + "\n")
        tech = {"presence_time_rule": "end_of_second", "stg_email_list": ["stg@example.com"],
                "operations_email_list": [], "email": {"mode": "outbox", "sender": "x@example.com"},
                "output_dir": os.path.join(tmp, "out"), "holidays": []}
        r = brd_run.daily(path, from_json(cfg_dict), tech, send=True)
        assert len(r.emails) == 2  # STG (consolidated) and MM A (its own report)
        assert any("stg@example.com" in e and "Futures Market Makers Performance for the day 30th of Sep, 2026" in e
                   for e in r.emails)
        assert any("mm.a@example.com" in e and "Saudi Exchange Market Making Performance - MM A" in e for e in r.emails)
        assert any("No email list configured for market maker MM B" in line for line in r.log)
        import pandas as pd
        seg = pd.read_excel(r.segregated[A], sheet_name=None)
        assert all(set(df.iloc[:, 1]) <= {A} for df in seg.values())          # only MM A's rows
        cfg_dict["contracts"][0]["required_lots"] = 50                         # obligations updated
        r2 = brd_run.daily(path, from_json(cfg_dict), tech, send=False)
        assert any("regenerated" in line for line in r2.log)
        daily = pd.read_excel(r2.consolidated, sheet_name="Daily Summary")
        assert list(daily[daily.MMID == A]["Eligibility Flag"]) == ["NO"]    # 40 < 50 after the update


if __name__ == "__main__":
    if "--export" in sys.argv:
        EXPORT_DIR = sys.argv[sys.argv.index("--export") + 1]
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_")]
    failed = 0
    for name, f in tests:
        try:
            f()
            print(f"PASS  {name}")
        except Exception as e:
            failed += 1
            print(f"FAIL  {name}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
