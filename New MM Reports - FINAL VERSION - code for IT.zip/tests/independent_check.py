"""Independent check of the tool on real order files.

Rebuilds every market maker's order book from the raw TSORDR file using only the BRD rules
(this file does not use the tool's order book, engine or volume code), and compares every
second of the presence window, the traded volume and the Eligibility Flag with the tool.
It also records real examples of the BRD business scenarios.

Usage: .venv/bin/python tests/independent_check.py <TSORDR files or folders...>
"""
import collections, glob, json, os, sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mmpm import brd, config as cm                      # noqa: E402  (tool output to compare with)
from mmpm.engine import contract_segments, run, summary  # noqa: E402
from mmpm.parser import load                            # noqa: E402
from mmpm.trades import traded_volume                   # noqa: E402

ENTRY, FILL, EXIT, SUSPEND = {"0772", "0775", "0788", "0790"}, {"0779"}, {"0776", "0778", "0793", "0795"}, {"0789", "0794"}
LOTS = (5, 8, 10, 12, 15)


def sec(v):
    v = int(v)
    return v // 10000 * 3600 + v // 100 % 100 * 60 + v % 100


def raw(path):
    df = pd.read_csv(path, sep="|", dtype=str, keep_default_na=False)
    df = df.apply(lambda s: s.str.strip())
    df["row"] = range(len(df))
    df["t"] = df.ACTION_TIME.map(sec)
    return df.sort_values(["t", "row"], kind="stable")


def ladder(levels, side, step, lots):
    """First price (from the best) from which 5 levels, `step` ticks apart, meet the lots."""
    d = -step if side == "B" else step
    for p in sorted(levels, reverse=(side == "B")):
        if all(levels.get(p + k * d, 0) >= lots[k] for k in range(5)):
            return p
    return None


def evaluate(orders, step, spread_ticks, lots):
    lv = {"B": collections.Counter(), "S": collections.Counter()}
    for side, px, vol in orders.values():
        lv[side][px] += vol
    b, a = (max(lv["B"]) if lv["B"] else None), (min(lv["S"]) if lv["S"] else None)
    spread = b is not None and a is not None and a - b <= spread_ticks
    lb, la = ladder(lv["B"], "B", step, lots), ladder(lv["S"], "S", step, lots)
    book = lb is not None and la is not None and la - lb <= spread_ticks
    return spread, book, lv, b, a, lb, la


def replay(rows, tick, step, spread_ticks, lots, start, end, ex, key):
    """Independent end-of-second states. Returns {second: (spread, book)} at each event second."""
    orders, states, last = {}, {}, None
    by_t = collections.OrderedDict()
    for r in rows:
        by_t.setdefault(r["t"], []).append(r)
    prev = evaluate(orders, step, spread_ticks, lots)
    for t, batch in by_t.items():
        before = dict(orders); prev_lv = prev[2]
        mid_states = []
        for r in batch:
            a, ch = r["ORDER_ACTION"], r["ENTRY_ORDER_NUMBER"]
            px = float(r["DISCLOSED_PRICE"] or 0); vol = int(r["VOLUME_REMAINING"] or 0)
            side = "S" if r["ORDER_TRANSACTION"] == "1" else "B"
            old = orders.get(ch)
            if a in ENTRY | FILL:
                if vol > 0 and px > 0:
                    orders[ch] = (side, round(px / tick), vol)
                else:
                    orders.pop(ch, None)
            elif a in EXIT | SUSPEND:
                orders.pop(ch, None)
            mid_states.append(evaluate(orders, step, spread_ticks, lots)[:2])
            # ---- scenario evidence (event level)
            same = [c for c, (s, p, v) in before.items() if c != ch and s == side and p == round(px / tick)]
            if a == "0776" and old and any(c < ch for c, (s, p, v) in orders.items() if s == side and p == old[1]):
                ex["3 two orders at the same price, newer deleted"].append(key + (r["ACTION_TIME"],))
            if a == "0772" and vol > 0 and px > 0 and same:
                ex["4 top-up at the same price"].append(key + (r["ACTION_TIME"],))
            if a == "0779" and vol > 0 and px > 0:
                ex["5 partial fill"].append(key + (r["ACTION_TIME"],))
            if a == "0788":
                ex["10 market order converted to a limit order (0788)"].append(key + (r["ACTION_TIME"],))
            if a == "0772" and vol > 0 and px > 0 and any(c in partly for c in same):
                ex["37 older order partly filled + new order at the same price"].append(key + (r["ACTION_TIME"],))
            if a == "0779" and vol > 0:
                partly.add(ch)
        now = evaluate(orders, step, spread_ticks, lots)
        if start <= t < end:
            states[t] = now[:2]
            sp, bk, lv, b, a_, lb, la = now
            if sp and bk:
                ex["1 full order book (both met)"].append(key + (t,))
                if (b is not None and lb != b) or (a_ is not None and la != a_):
                    ex["2 additional order in front, order book met"].append(key + (t,))
                if a_ - b == spread_ticks:
                    ex["11 spread at the maximum"].append(key + (t,))
            if b is not None and a_ is not None and a_ - b > spread_ticks:
                ex["8 wide spread"].append(key + (t,))
            if (b is None) != (a_ is None):
                ex["12 only one side quoted"].append(key + (t,))
            if sp and lb is not None and la is not None and la - lb > spread_ticks:
                ex["7 small orders at a tight spread, books too far apart"].append(key + (t,))
            for side, best, st in (("B", b, lb), ("S", a_, la)):
                if best is None or st is not None:
                    continue
                d = -step if side == "B" else step
                levels = [lv[side].get(best + k * d, 0) for k in range(5)]
                if 0 < levels[0] < LOTS[0]:
                    ex["6 best price below the required size, no complete book behind"].append(key + (t,))
                if levels[0] >= LOTS[0] and any(levels[k] == 0 for k in range(1, 5)) and any(p for p in lv[side] if (p - best) * d > 4 * step):
                    ex["9/15 missing price level / level more than 1 tick away"].append(key + (t,))
                if all(levels[k] > 0 for k in range(5)) and any(0 < levels[k] < LOTS[k] for k in range(1, 5)):
                    ex["16 level in the middle below the required size"].append(key + (t,))
            # change and top-up in the same second: a moment inside the second fails, the end of the second is met
            if now[1] and any(not s[1] for s in mid_states[:-1]):
                acts = {r["ORDER_ACTION"] for r in batch}
                if "0775" in acts and "0772" in acts:
                    ex["13 change and top-up in the same second (end of second met)"].append(key + (t,))
            # order added and removed inside the same second
            chains = collections.Counter(r["ENTRY_ORDER_NUMBER"] for r in batch)
            for c in chains:
                acts = [r["ORDER_ACTION"] for r in batch if r["ENTRY_ORDER_NUMBER"] == c]
                if acts[0] == "0772" and acts[-1] in EXIT:
                    ex["14 order added and removed in the same second"].append(key + (t,))
            # better price entered earlier, then the old Level 1 order deleted
            for r in batch:
                if r["ORDER_ACTION"] == "0776" and r["ENTRY_ORDER_NUMBER"] in before:
                    s_, p_, _ = before[r["ENTRY_ORDER_NUMBER"]]
                    lvb = prev_lv[s_]
                    if not lvb:
                        continue
                    best_before = max(lvb) if s_ == "B" else min(lvb)
                    inside = [q for q in lvb if (q > p_ if s_ == "B" else q < p_)]
                    lad_before = ladder(lvb, s_, step, LOTS)
                    if inside and lad_before == p_ and p_ not in lv[s_]:
                        st = lb if s_ == "B" else la
                        if st is not None:
                            ex["34 better price entered, Level 1 deleted, book still complete"].append(key + (t,))
                        elif lv[s_]:
                            q = max(lv[s_]) if s_ == "B" else min(lv[s_])
                            name = ("32 better price entered, Level 1 deleted (small order)" if lv[s_][q] < LOTS[0]
                                    else "33 better price entered, Level 1 deleted (gap)")
                            ex[name].append(key + (t,))
        prev = now
    return states


partly = set()


def tool_states(df, mm, c, cfg, date):
    segs = contract_segments(df, mm, c, cfg, "new", date=date)
    return segs


def main(paths):
    files = []
    for p in paths:
        files += sorted(glob.glob(os.path.join(p, "TSORDR-*.txt"))) if os.path.isdir(p) else [p]
    files = sorted(set(files), key=os.path.basename)
    ex = collections.defaultdict(list)
    seconds = mism = vol_mism = flag_mism = pairs = 0
    for f in files:
        day = os.path.basename(f)[7:15]
        cfg = None
        for r in reversed(sorted(glob.glob(f"reports/archive/{day}/*/run.json"))):
            j = json.load(open(r))
            if "config" in j:
                cfg = cm.from_json(j["config"]); break
        cfg = cfg or cm.load()
        d = raw(f)
        df = load(f)
        res = run(df, "new", cfg)
        summ = summary(df, res, cfg)
        vol = traded_volume(df, cfg)
        rows = {(r["MMID"], r["Contract"]): r for r in brd.summary_rows(summ, vol, cfg, day)}
        mms = {u for _, u in cfg.market_makers}
        # independent traded volume: FILLED_VOLUME of 0779 rows, whole day, self-trades excluded
        fills = d[d.ORDER_ACTION == "0779"].copy()
        fills["lots"] = pd.to_numeric(fills.FILLED_VOLUME, errors="coerce").fillna(0).astype(int)
        selfs = fills.groupby("TICKET_NUMBER").THIS_REAL_TRADER_ID.transform(lambda s: s.nunique() == 1 and len(s) >= 2)
        own = fills[~selfs].groupby(["THIS_REAL_TRADER_ID", "SYMBOL_CODE", "INSTRUMENT_TYPE"]).lots.sum()
        if selfs.any():
            for x in fills[selfs].itertuples():
                ex["28 self-trade excluded"].append((day, x.THIS_REAL_TRADER_ID, x.SYMBOL_CODE, x.ACTION_TIME))
        multi = fills[~selfs].groupby("ENTRY_ORDER_NUMBER").size()
        for c in multi[multi >= 2].index[:3]:
            ex["22 traded volume from partial fills (sum of FILLED_VOLUME)"].append((day, c))
        for name, mm in cfg.market_makers:
            for c in cfg.presence_contracts:
                pairs += 1
                sub = d[(d.THIS_REAL_TRADER_ID == mm) & (d.SYMBOL_CODE == c.symbol) & (d.INSTRUMENT_TYPE == c.itype)]
                global partly
                partly = set()
                key = (day, mm, c.symbol)
                ind = replay(sub.to_dict("records"), c.tick, c.level_step, c.spread_ticks, c.min_lots,
                             cfg.start, cfg.end, ex, key)
                # expand both to every second of the window and compare
                segs = tool_states(df, mm, c, cfg, day)
                cur = evaluate({}, c.level_step, c.spread_ticks, c.min_lots)[:2]
                pre = sub[sub.t < cfg.start]
                if len(pre):  # book carried into the window: independent state at the open
                    o2 = {}
                    for r in pre.to_dict("records"):
                        a, ch = r["ORDER_ACTION"], r["ENTRY_ORDER_NUMBER"]
                        px = float(r["DISCLOSED_PRICE"] or 0); vv = int(r["VOLUME_REMAINING"] or 0)
                        sd = "S" if r["ORDER_TRANSACTION"] == "1" else "B"
                        if a in ENTRY | FILL:
                            if vv > 0 and px > 0: o2[ch] = (sd, round(px / c.tick), vv)
                            else: o2.pop(ch, None)
                        elif a in EXIT | SUSPEND:
                            o2.pop(ch, None)
                    cur = evaluate(o2, c.level_step, c.spread_ticks, c.min_lots)[:2]
                    if cur[0] and cur[1]:
                        ex["19 orders entered before the open, counted from 09:30"].append(key)
                i_sp = i_bk = i_tot = 0
                k = 0
                seg_i = 0
                for t in range(cfg.start, cfg.end):
                    if t in ind:
                        cur = ind[t]
                    while seg_i + 1 < len(segs) and segs[seg_i + 1].start <= t:
                        seg_i += 1
                    g = segs[seg_i]
                    tsp, tbk = g.ev.spread and not g.suspended, g.ev.depth and not g.suspended
                    seconds += 1
                    if (tsp, tbk) != cur:
                        mism += 1
                    i_sp += cur[0]; i_bk += cur[1]; i_tot += cur[0] and cur[1]
                row = rows[(mm, c.symbol)]
                added = sum(int(own.get((mm, a.symbol, a.itype), 0)) for a in cfg.added_contracts(c))
                i_lots = int(own.get((mm, c.symbol, c.itype), 0)) + added
                if added:
                    ex["26 rollover lots added (configured rollover contract)"].append((day, mm, c.symbol, added))
                if i_lots != row["Total Volume Traded"]:
                    vol_mism += 1
                req = cfg.required_for(c.symbol, day)
                i_flag = "YES" if i_tot >= req and i_lots >= c.required_lots else "NO"
                if i_flag != row["Eligibility Flag"] or i_tot != row["Total presence time in Seconds"] \
                        or i_sp != row["Total Spread presence time in Seconds"] or i_bk != row["Total OrderBook presence time in Seconds"]:
                    flag_mism += 1
                if c.itype == "INF" and i_flag == "YES":
                    ex["17/37 Index Futures tick size; eligible on Index Futures"].append(key)
                if i_tot >= req and i_lots < c.required_lots:
                    ex["23 presence met but volume not met"].append(key + (i_tot, i_lots))
                if i_sp >= req and i_tot < req:
                    ex["39 presence not met because of the order book"].append(key + (i_sp, i_tot))
                if i_sp < req and i_lots < c.required_lots:
                    ex["40 spread and traded volume not met"].append(key + (i_sp, i_lots))
                if len(sub) == 0:
                    ex["27 configured contract not traded (0 seconds, NO)"].append(key)
        # other market makers at the same prices; traders not configured
        live = d[d.ORDER_ACTION.isin(ENTRY)]
        g = live.groupby(["SYMBOL_CODE", "ORDER_TRANSACTION", "DISCLOSED_PRICE"]).THIS_REAL_TRADER_ID.nunique()
        if (g > 1).any():
            ex["18 other market makers at the same prices"].append((day,))
        for u in sorted(set(d.THIS_REAL_TRADER_ID) - mms)[:1]:
            ex["29 trader not configured (logged)"].append((day, u))
        mo = d[(d.ORDER_ACTION == "0772") & (pd.to_numeric(d.DISCLOSED_PRICE, errors="coerce") == 0)]
        for c in mo.ENTRY_ORDER_NUMBER:
            chain = d[d.ENTRY_ORDER_NUMBER == c]
            if (chain.ORDER_ACTION == "0788").any() and (chain.ORDER_ACTION == "0779").any():
                ex["35 market order partly matched, rest converted (0788)"].append((day, c))
            tk = set(chain[chain.ORDER_ACTION == "0779"].TICKET_NUMBER)
            both = fills[fills.TICKET_NUMBER.isin(tk)]
            if (both.groupby("TICKET_NUMBER").THIS_REAL_TRADER_ID.nunique() == 1).any():
                ex["36 market order matched with the market maker's own order"].append((day, c))
        print(f"{day}: checked", flush=True)
    print(f"\nSeconds compared: {seconds:,}; per-second differences (tool vs independent): {mism}")
    print(f"MM/contract/day rows: {pairs}; traded volume differences: {vol_mism}; presence/flag differences: {flag_mism}")
    print("\nReal examples found per scenario:")
    for k in sorted(ex, key=lambda s: int(s.split()[0].split("/")[0])):
        print(f"  {k}: {len(ex[k])}  e.g. {ex[k][0]}")
    json.dump({k: [list(map(str, x)) for x in v[:20]] for k, v in ex.items()},
              open("tests/independent_check_examples.json", "w"), indent=1)


if __name__ == "__main__":
    main(sys.argv[1:] or [os.path.expanduser("~/Downloads"), os.path.expanduser("~/Desktop/Anas MM test")])
