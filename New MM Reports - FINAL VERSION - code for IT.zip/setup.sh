#!/usr/bin/env bash
# New MM Reports - one-command setup (Linux / macOS): installs, then checks every BRD scenario.
set -euo pipefail
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
"$PY" -c 'import sys; assert sys.version_info >= (3, 9), "Python 3.9 or newer is needed"'
"$PY" -m venv .venv
.venv/bin/pip install --quiet --upgrade pip
.venv/bin/pip install --quiet -r requirements.txt
echo "Installed. Checking all BRD business scenarios..."
if .venv/bin/python tests/test_brd_scenarios.py > setup_check.log 2>&1; then
  tail -1 setup_check.log
  echo "Ready. Next: fill in the settings (DEPLOYMENT.md section 2) and run the smoke test (section 7)."
else
  tail -20 setup_check.log
  echo "NOT ready: some checks failed (full output in setup_check.log)." >&2
  exit 1
fi
