"""User configuration: contracts, market makers, time window, requirements.

Stored in mmpm/config.json (the MM config file), maintained by the Saudi Exchange
Operations team. Defaults reproduce the rules the tool was built and verified with.

A. contracts: one row per contract:
   Contract Code = the order file's SYMBOL_CODE (e.g. STCF6V),
   Symbol        = the label shown in the report's Symbol column (e.g. 7010FUT).
   Rows are processed independently, even when several share a Contract Code;
   each is matched to the order file by SYMBOL_CODE + INSTRUMENT_TYPE.
B. market_makers: MM Name <-> Trading User ID (THIS_REAL_TRADER_ID), plus the email
   list that receives the market maker's own (segregated) daily report.
   Volume-only (rollover) row: spread 0 and L1-L5 all 0. No presence is calculated
   for it; its traded lots are added to the contract row(s) with the same Symbol,
   and it does not get its own report row.
C. time_window: applies ONLY to spread / depth / fully-eligible presence.
   Traded lots always use the whole day.
D. suspensions: trading suspensions of a contract (contract code, date, from / to time; no times =
   the whole session). Suspended seconds are not counted; the required presence time for that
   contract and day is the same share (80%) of the remaining time. Suspended for the whole session:
   Eligibility Flag SUSPENDED, and the day is not counted for that contract in the monthly report.
E. monthly_periods: the first and last trading day of each month (set by Operations). The monthly
   report covers the days in between; when the last trading day is processed, the monthly report
   is produced automatically (internal + one per market maker).
"""
import json
import os
import re
from dataclasses import dataclass, field
from typing import List, Tuple

from .parser import TICK, hhmmss_to_sec, sec_to_hhmmss

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
DEFAULT_MIN_LOTS = (5, 8, 10, 12, 15)
DEFAULT_SPREAD_TICKS = 2
DEFAULT_REQUIRED_LOTS = {"SSF": 40, "INF": 100}
DEFAULT_REQUIRED_PRESENCE = 17280
DEFAULT_WINDOW = ("09:30", "15:30")
TYPE_LABELS = {"SSF": "SSF", "INF": "IF"}  # Type column of the Daily Summary


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class Contract:
    id: str            # stable key for this row ("C1", "C2", ...)
    name: str          # "Symbol" label in the report, e.g. 7010FUT
    symbol: str        # "Contract Code" = SYMBOL_CODE in the order file, e.g. STCF6V
    itype: str         # SSF or INF
    spread_ticks: int
    min_lots: Tuple[int, int, int, int, int]
    required_lots: int
    tick_size: float = 0.0   # 0 = the instrument type's default (SSF 0.1, INF 0.5)
    level_step: int = 1      # ticks between consecutive order book levels (L1 -> L2 -> ... -> L5)

    @property
    def tick(self) -> float:
        return self.tick_size or TICK[self.itype]

    @property
    def default_tick(self) -> float:
        return TICK[self.itype]

    @property
    def volume_only(self) -> bool:
        """Rollover contract: only its traded lots are used (added to the same Symbol)."""
        return self.spread_ticks == 0 and not any(self.min_lots)

    @property
    def type_label(self) -> str:
        return TYPE_LABELS.get(self.itype, self.itype)


@dataclass
class Config:
    contracts: List[Contract]
    market_makers: List[Tuple[str, str]]  # (name, user id)
    start: int  # seconds since midnight
    end: int    # exclusive
    required_presence: int = DEFAULT_REQUIRED_PRESENCE
    source: str = field(default="", compare=False)
    emails: dict = field(default_factory=dict)  # user id -> [email addresses]
    suspensions: list = field(default_factory=list)  # (contract code, YYYYMMDD, start s, end s)
    monthly_periods: dict = field(default_factory=dict)  # YYYYMM -> (first YYYYMMDD, last YYYYMMDD)

    @property
    def presence_contracts(self) -> List[Contract]:
        """Contracts with a spread/depth/size config: these get report rows."""
        return [c for c in self.contracts if not c.volume_only]

    def added_contracts(self, main: Contract) -> List[Contract]:
        """Volume-only contracts whose traded lots are added to `main`."""
        return [c for c in self.contracts if c.volume_only and c.name == main.name]

    def suspended(self, symbol: str, date: str) -> List[Tuple[int, int]]:
        """Suspended periods of a contract on a trading date, inside the time window, merged."""
        spans = sorted((max(a, self.start), min(b, self.end)) for c, d, a, b in self.suspensions
                       if c == symbol and d == date and min(b, self.end) > max(a, self.start))
        out: List[Tuple[int, int]] = []
        for a, b in spans:
            if out and a <= out[-1][1]:
                out[-1] = (out[-1][0], max(out[-1][1], b))
            else:
                out.append((a, b))
        return out

    def available(self, symbol: str, date: str) -> int:
        """Seconds of the time window in which the contract was not suspended."""
        return self.window - sum(b - a for a, b in self.suspended(symbol, date))

    def required_for(self, symbol: str, date: str) -> int:
        """Required presence for a contract and day: the same share of the time not suspended."""
        return round(self.required_presence * self.available(symbol, date) / self.window)

    @property
    def window(self) -> int:
        return self.end - self.start

    @property
    def mm_names(self) -> dict:
        return {uid: name for name, uid in self.market_makers}

    def describe(self) -> dict:
        return to_json(self)


def _time(s: str, what: str) -> int:
    s = str(s).strip()
    m = re.fullmatch(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", s)
    if not m:
        raise ConfigError(f"{what} must look like HH:MM (got '{s}')")
    h, mi, se = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if h > 23 or mi > 59 or se > 59:
        raise ConfigError(f"{what} is not a valid time ('{s}')")
    return hhmmss_to_sec(h * 10000 + mi * 100 + se)


def _tick(v, what: str) -> float:
    try:
        x = float(str(v).strip())
    except ValueError:
        raise ConfigError(f"{what} must be a number such as 0.1 (got '{v}')")
    if x <= 0:
        raise ConfigError(f"{what} must be greater than 0 (got {v})")
    return x


def _emails(v, what: str) -> list:
    """One or more addresses, as a list or a text separated by commas, semicolons or spaces."""
    items = v if isinstance(v, list) else re.split(r"[;,\s]+", str(v or ""))
    out = [x.strip() for x in items if str(x).strip()]
    for x in out:
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", x):
            raise ConfigError(f"{what}: '{x}' is not a valid email address")
    return out


def _int(v, what: str, minimum: int = 0) -> int:
    try:
        n = int(str(v).strip())
    except ValueError:
        raise ConfigError(f"{what} must be a whole number (got '{v}')")
    if n < minimum:
        raise ConfigError(f"{what} must be at least {minimum} (got {n})")
    return n


def from_json(d: dict) -> Config:
    contracts = []
    for i, c in enumerate(d.get("contracts", []), 1):
        where = f"Contract row {i}"
        symbol = str(c.get("contract_code", c.get("symbol_code", ""))).strip()
        itype = str(c.get("instrument_type", "")).strip().upper()
        if not symbol:
            raise ConfigError(f"{where}: Contract Code is required")
        if itype not in TICK:
            raise ConfigError(f"{where}: Instrument Type must be SSF or INF (got '{itype}')")
        lots = c.get("min_lots", DEFAULT_MIN_LOTS)
        if len(lots) != 5:
            raise ConfigError(f"{where}: depth min lots need 5 values (L1-L5)")
        contracts.append(Contract(
            id=f"C{i}",
            name=str(c.get("symbol", c.get("name", ""))).strip() or symbol,
            symbol=symbol, itype=itype,
            spread_ticks=_int(c.get("spread_ticks", DEFAULT_SPREAD_TICKS), f"{where}: spread ticks"),
            min_lots=tuple(_int(x, f"{where}: L{k + 1} min lot", 0) for k, x in enumerate(lots)),
            required_lots=_int(c.get("required_lots", DEFAULT_REQUIRED_LOTS[itype]),
                               f"{where}: required traded lots"),
            tick_size=_tick(c.get("tick_size", TICK[itype]), f"{where}: tick size"),
            level_step=_int(c.get("level_step", 1), f"{where}: level gap in ticks", 1),
        ))
    mms, seen, emails = [], set(), {}
    for i, m in enumerate(d.get("market_makers", []), 1):
        uid = str(m.get("user_id", "")).strip()
        if not uid:
            raise ConfigError(f"Market maker row {i}: Trading User ID is required")
        if uid in seen:
            raise ConfigError(f"Market maker row {i}: Trading User ID {uid} is listed twice")
        seen.add(uid)
        mms.append((str(m.get("name", "")).strip() or uid, uid))
        emails[uid] = _emails(m.get("email_list", []), f"Market maker row {i}: email list")
    tw = d.get("time_window", {})
    start = _time(tw.get("start", DEFAULT_WINDOW[0]), "Start Time")
    end = _time(tw.get("end", DEFAULT_WINDOW[1]), "End Time")
    if end <= start:
        raise ConfigError("End Time must be after Start Time")
    for i, c in enumerate(contracts, 1):
        zeros = [k + 1 for k, v in enumerate(c.min_lots) if v == 0]
        if zeros and not c.volume_only:
            raise ConfigError(
                f"Contract row {i} ({c.symbol}): L{', L'.join(map(str, zeros))} min lot is 0. For a "
                f"volume-only (rollover) contract set Spread and all of L1-L5 to 0; otherwise use 1 or more")
        if c.volume_only and not any(m.name == c.name for m in contracts if not m.volume_only):
            raise ConfigError(
                f"Contract row {i} ({c.symbol}) is volume-only, but no contract with a spread/depth "
                f"config has the same Symbol '{c.name}' to add its traded lots to")
    if not [c for c in contracts if not c.volume_only]:
        raise ConfigError("Add at least one contract with a spread/depth config")
    if not mms:
        raise ConfigError("Add at least one market maker")
    suspensions = []
    codes = {c.symbol for c in contracts}
    for i, x in enumerate(d.get("suspensions", []), 1):
        where = f"Suspension row {i}"
        code = str(x.get("contract_code", "")).strip()
        if code not in codes:
            raise ConfigError(f"{where}: contract code '{code}' is not in the contracts list")
        day = str(x.get("date", "")).strip().replace("-", "")
        if not re.fullmatch(r"\d{8}", day):
            raise ConfigError(f"{where}: date must look like YYYY-MM-DD (got '{x.get('date', '')}')")
        a = _time(x["from"], f"{where}: from time") if str(x.get("from", "")).strip() else start
        b = _time(x["to"], f"{where}: to time") if str(x.get("to", "")).strip() else end
        if b <= a:
            raise ConfigError(f"{where}: the to time must be after the from time")
        suspensions.append((code, day, a, b))
    periods = {}
    for i, x in enumerate(d.get("monthly_periods", []), 1):
        where = f"Monthly period row {i}"
        month = str(x.get("month", "")).strip().replace("-", "")
        first = str(x.get("first_trading_day", "")).strip().replace("-", "")
        last = str(x.get("last_trading_day", "")).strip().replace("-", "")
        if not (re.fullmatch(r"\d{6}", month) and re.fullmatch(r"\d{8}", first) and re.fullmatch(r"\d{8}", last)):
            raise ConfigError(f"{where}: month must look like YYYY-MM and the days like YYYY-MM-DD")
        if last < first:
            raise ConfigError(f"{where}: the last trading day is before the first trading day")
        if month in periods:
            raise ConfigError(f"{where}: month {x.get('month')} is listed twice")
        periods[month] = (first, last)
    return Config(contracts, mms, start, end,
                  _int(d.get("required_presence_seconds", DEFAULT_REQUIRED_PRESENCE),
                       "Required Total Presence Time"), emails=emails, suspensions=suspensions,
                  monthly_periods=periods)


def to_json(cfg: Config) -> dict:
    return {
        "contracts": [{"contract_code": c.symbol, "symbol": c.name, "instrument_type": c.itype,
                       "tick_size": c.tick, "spread_ticks": c.spread_ticks,
                       "level_step": c.level_step, "min_lots": list(c.min_lots),
                       "required_lots": c.required_lots} for c in cfg.contracts],
        "market_makers": [{"name": n, "user_id": u, "email_list": cfg.emails.get(u, [])}
                          for n, u in cfg.market_makers],
        "time_window": {"start": sec_to_hhmmss(cfg.start)[:5] if cfg.start % 60 == 0 else sec_to_hhmmss(cfg.start),
                        "end": sec_to_hhmmss(cfg.end)[:5] if cfg.end % 60 == 0 else sec_to_hhmmss(cfg.end)},
        "required_presence_seconds": cfg.required_presence,
        "suspensions": [{"contract_code": c, "date": f"{d[:4]}-{d[4:6]}-{d[6:]}",
                         "from": sec_to_hhmmss(a), "to": sec_to_hhmmss(b)} for c, d, a, b in cfg.suspensions],
        "monthly_periods": [{"month": f"{m[:4]}-{m[4:]}", "first_trading_day": f"{a[:4]}-{a[4:6]}-{a[6:]}",
                             "last_trading_day": f"{b[:4]}-{b[4:6]}-{b[6:]}"} for m, (a, b) in sorted(cfg.monthly_periods.items())],
    }


def load(path: str = CONFIG_PATH) -> Config:
    if not os.path.exists(path):
        raise ConfigError(f"No configuration file at {path}")
    with open(path) as f:
        cfg = from_json(json.load(f))
    cfg.source = path
    return cfg


def save(cfg: Config, path: str = CONFIG_PATH) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(to_json(cfg), f, indent=2)
    os.replace(tmp, path)
