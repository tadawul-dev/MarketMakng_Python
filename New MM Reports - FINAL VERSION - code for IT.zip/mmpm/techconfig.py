"""Technical configuration file (BRD): presence time rule, email lists and delivery.

The market open and close times and the required presence time are in the MM config
file (mmpm/config.json, "time_window" and "required_presence_seconds"), which the
Saudi Exchange Operations team maintains.
"""
import json
import os

from .config import ConfigError, _emails

TECH_PATH = os.path.join(os.path.dirname(__file__), "technical_config.json")
RULES = {"end_of_second": "end"}  # BRD: the configured rule shall be "End of second"
WEEKEND = {4, 5}  # Friday, Saturday (datetime.weekday)


def load(path: str = TECH_PATH) -> dict:
    if not os.path.exists(path):
        raise ConfigError(f"No technical configuration file at {path}")
    with open(path) as f:
        t = json.load(f)
    rule = t.get("presence_time_rule", "end_of_second")
    if rule not in RULES:
        raise ConfigError(f"presence_time_rule must be one of {sorted(RULES)} (got '{rule}')")
    t["presence_time_rule"] = rule
    t["stg_email_list"] = _emails(t.get("stg_email_list", []), "stg_email_list")
    t["operations_email_list"] = _emails(t.get("operations_email_list", []), "operations_email_list")
    e = t.setdefault("email", {})
    e.setdefault("mode", "outbox")
    if e["mode"] not in ("outbox", "smtp"):
        raise ConfigError("email.mode must be 'outbox' or 'smtp'")
    if e["mode"] == "smtp" and not e.get("smtp_host"):
        raise ConfigError("email.smtp_host is required when email.mode is 'smtp'")
    t.setdefault("output_dir", "new_mm_reports")
    t["holidays"] = [str(d).replace("-", "") for d in t.get("holidays", [])]
    return t


def save_internal_emails(emails, path: str = TECH_PATH) -> None:
    """Update the internal (STG) email list in the technical configuration file."""
    with open(path) as f:
        t = json.load(f)
    t["stg_email_list"] = _emails(emails, "Internal email list")
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(t, f, indent=2)
    os.replace(tmp, path)
