"""Step 2: per-MM order book state machine with L1-L5 consecutive-tick checks.

Book state is end-of-second: all events within a second are applied (in
file-row order) before the state for that second is read.

Prices are held as integer tick counts (price / tick_size), so "consecutive
tick" is simply +/-1 and no float comparison is needed.
"""
from dataclasses import dataclass
from typing import Dict, Iterator, List, Optional, Tuple

import pandas as pd

MIN_LOT = (5, 8, 10, 12, 15)  # L1..L5 default lots, independent per level
BUY, SELL = "BUY", "SELL"
OK, MISSING, UNDERSIZED = "OK", "MISSING", "UNDERSIZED"

# How a level's size is measured when the MM has >1 chain at the same price:
#   "max": the largest single chain must clear the lot ("its VOLUME_REMAINING")
#   "sum": total volume across the MM's chains at that price
LEVEL_VOLUME = "sum"


@dataclass
class Level:
    level: int           # 1..5
    price_ticks: int
    volume: int          # 0 if no chain at this price
    min_lot: int
    status: str          # OK / MISSING / UNDERSIZED


class Book:
    """Live resting orders for one MM in one symbol."""

    def __init__(self, level_volume: str = LEVEL_VOLUME, min_lots: Tuple[int, ...] = MIN_LOT,
                 level_step: int = 1):
        self.chains: Dict[str, Tuple[str, int, int]] = {}  # chain -> (side, px, vol)
        self.level_volume = level_volume
        self.min_lots = tuple(min_lots)
        self.level_step = level_step  # ticks between L1, L2, ... L5

    def apply(self, r) -> None:
        if r.live:
            self.chains[r.chain] = (r.side, r.price_ticks, r.vol)
        else:
            self.chains.pop(r.chain, None)

    def prices(self, side: str) -> Dict[int, int]:
        """price_ticks -> level volume, for one side."""
        out: Dict[int, int] = {}
        for s, px, vol in self.chains.values():
            if s != side or vol < 1:
                continue
            if self.level_volume == "sum":
                out[px] = out.get(px, 0) + vol
            else:
                out[px] = max(out.get(px, 0), vol)
        return out

    def best(self, side: str) -> Optional[Tuple[int, int]]:
        p = self.prices(side)
        if not p:
            return None
        px = max(p) if side == BUY else min(p)
        return px, p[px]

    def depth(self, side: str, start: Optional[int] = None) -> List[Level]:
        """L1..L5 at consecutive ticks from L1 (away from the spread).
        `start` = price to use as L1 (default: the best price)."""
        p = self.prices(side)
        if not p:
            return [Level(i + 1, None, 0, self.min_lots[i], MISSING) for i in range(5)]
        step = (-1 if side == BUY else 1) * self.level_step
        l1 = start if start is not None else (max(p) if side == BUY else min(p))
        levels = []
        for i in range(5):
            px = l1 + i * step
            vol = p.get(px, 0)
            status = MISSING if vol == 0 else OK if vol >= self.min_lots[i] else UNDERSIZED
            levels.append(Level(i + 1, px, vol, self.min_lots[i], status))
        return levels

    def ladder_start(self, side: str) -> Optional[int]:
        """Best price (closest to the spread) from which a full compliant ladder
        runs: 5 consecutive ticks, each meeting its min lot. None if there is none.
        Orders in front of it (smaller inside orders) are extra liquidity."""
        p = self.prices(side)
        step = (-1 if side == BUY else 1) * self.level_step
        for px in sorted(p, reverse=(side == BUY)):
            if all(p.get(px + i * step, 0) >= self.min_lots[i] for i in range(5)):
                return px
        return None


MODELS = {"new": Book}


def snapshots(df: pd.DataFrame, mm: str, symbol: str,
              level_volume: str = LEVEL_VOLUME,
              model: str = "new") -> Iterator[Tuple[int, Book, list]]:
    """Yield (second, book, rows_in_that_second) at the end of every second
    in which this MM/symbol had at least one event. The book is unchanged
    between yielded seconds. The same Book object is mutated and re-yielded."""
    sub = df[(df.THIS_REAL_TRADER_ID == mm) & (df.SYMBOL_CODE == symbol)]
    book = MODELS[model](level_volume)
    batch, cur = [], None
    for r in sub.itertuples(index=False):
        if cur is not None and r.t != cur:
            yield cur, book, batch
            batch = []
        book.apply(r)
        batch.append(r)
        cur = r.t
    if batch:
        yield cur, book, batch
