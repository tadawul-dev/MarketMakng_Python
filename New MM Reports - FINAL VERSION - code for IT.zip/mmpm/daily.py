"""Daily Summary rows: one per market maker and contract, in MM config file order."""
import datetime as dt

import pandas as pd

from .config import Config


def as_date(trade_date: str) -> dt.date:
    return dt.date(int(trade_date[:4]), int(trade_date[4:6]), int(trade_date[6:]))


DAILY_COLS = ["Date", "MMID", "Market Maker", "Contract", "Symbol", "Type",
              "Total Spread presence time in Seconds", "Total OrderBook presence time in Seconds",
              "Total presence time in Seconds", "Required Total Presence Time (s)",
              "Total presence time in Percentage",
              "Total Volume Traded", "Required Traded Lots",
              "Eligibility Flag"]
DAILY_WIDTHS = [11, 10, 14, 10, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13]
BANNER = "This is the updated monitoring tool"  # internal tool only


def daily_rows(summ: pd.DataFrame, vol: pd.DataFrame, cfg: Config, trade_date: str) -> list:
    """Rows (dicts keyed by DAILY_COLS) in the BRD Daily Summary layout, in configuration
    order: market makers as listed, and within each, contracts as listed.

    Eligibility Flag: YES only if fully-eligible presence >= Required Total Presence Time
                      AND traded lots >= Required Traded Lots; SUSPENDED when the contract was
                      suspended for the whole session.
    A suspension (MM config file) removes its seconds: the percentage is of the time not suspended,
    and the required presence time is the same share of that time.
    """
    by_id = {c.id: c for c in cfg.contracts}
    names = cfg.mm_names
    v = vol.set_index(["MM", "Contract"])
    date = as_date(trade_date)
    rows = []
    for p in summ.to_dict("records"):
        c = by_id[p["Contract"]]
        available = cfg.available(c.symbol, trade_date)
        required = cfg.required_for(c.symbol, trade_date)
        pct = p["combined_time"] / available * 100 if available else 0.0
        lots = int(v.loc[(p["MM"], c.id), "Total traded lots"])  # own + added rollover lots
        flag = ("SUSPENDED" if available == 0 else
                "YES" if p["combined_time"] >= required and lots >= c.required_lots else "NO")
        rows.append({
            "Date": date, "MMID": p["MM"], "Market Maker": names.get(p["MM"], ""),
            "Contract": c.symbol, "Symbol": c.name, "Type": c.type_label,
            "Total Spread presence time in Seconds": p["spread_time"],
            "Total OrderBook presence time in Seconds": p["depth_time"],
            "Total presence time in Seconds": p["combined_time"],
            "Required Total Presence Time (s)": required,
            "Total presence time in Percentage": pct,
            "Total Volume Traded": lots,
            "Required Traded Lots": c.required_lots,
            "Eligibility Flag": flag,
            "_contract": c.id,
        })
    order = {c.id: i for i, c in enumerate(cfg.contracts)}
    mm_order = {u: i for i, (_, u) in enumerate(cfg.market_makers)}
    return sorted(rows, key=lambda r: (mm_order[r["MMID"]], order[r["_contract"]]))
