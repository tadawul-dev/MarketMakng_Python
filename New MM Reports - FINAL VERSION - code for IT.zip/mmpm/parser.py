"""Step 1: parse a TSORDR daily file and reconstruct order chains.

Chain identity
--------------
ENTRY_ORDER_NUMBER is the constant key across an order's full lifecycle
(0772 -> 0775* -> 0776/0778/0779). INITIATING_ORDER_NUMBER is NOT constant:
on each 0775 it holds the ORDER_NUMBER being replaced (a back-pointer to the
previous link). validate_chains() verifies that back-pointer linkage so a
mis-keyed chain fails loudly instead of silently producing phantom orders.
"""
from dataclasses import dataclass

import pandas as pd

NEW, MODIFY, DELETE, EXPIRE, TRADE = "0772", "0775", "0776", "0778", "0779"

# Every ORDER_ACTION code listed in the BRD (any other code is disregarded and logged):
#   entry   : the order is (again) resting with this row's price and VOLUME_REMAINING
#   exit    : the order leaves the book for good
#   pause   : the order leaves the book but may come back (Resumed, 0790)
#   fill    : traded; stays resting with VOLUME_REMAINING, leaves when that is 0/blank
#   noaction: negotiated-deal actions; ignored (not orders on the book, not traded lots)
ACTIONS = {
    "0772": ("Queued", "entry"), "0775": ("Changed", "entry"),
    "0788": ("Price Adjusted", "entry"), "0790": ("Resumed", "entry"),
    "0779": ("Filled", "fill"),
    "0776": ("Cancelled", "exit"), "0778": ("Expired", "exit"),
    "0793": ("Cancel on Disconnect", "exit"), "0795": ("Forced Cancel (Kill Switch)", "exit"),
    "0789": ("Suspended", "pause"), "0794": ("Suspend On Disconnect", "pause"),
    "0802": ("Manual Fill (Negotiated Deal)", "noaction"),
    "0805": ("Manual Changed (Negotiated Deal)", "noaction"),
    "0806": ("Manual Reject (Negotiated Deal)", "noaction"),
    "0807": ("Manual Confirmed (Negotiated Deal)", "noaction"),
    "0809": ("QueuedReport (Negotiated Deal)", "noaction"),
}
SIDE = {"1": "SELL", "2": "BUY"}
TICK = {"SSF": 0.1, "INF": 0.5}

COLS = [
    "ORDER_ACTION", "SYMBOL_CODE", "INSTRUMENT_TYPE", "ACTION_DATE", "ACTION_TIME",
    "THIS_REAL_TRADER_ID", "ORDER_NUMBER", "INITIATING_ORDER_NUMBER",
    "ENTRY_ORDER_NUMBER", "ORIGINAL_VOLUME", "VOLUME_REMAINING",
    "ORDER_TRANSACTION", "DISCLOSED_PRICE", "TRADE_PRICE", "VOLUME_TRADED",
    "DELETE_REASON", "ACTION_TIME_US", "FILLED_VOLUME", "TICKET_NUMBER",
]


def load(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, sep="|", dtype=str, keep_default_na=False, usecols=COLS)
    df = df.apply(lambda s: s.str.strip())
    df.insert(0, "row", range(len(df)))  # original file order = tie-breaker
    df["ORDER_ACTION"] = df["ORDER_ACTION"].str.zfill(4)
    kind = df["ORDER_ACTION"].map(lambda a: ACTIONS.get(a, ("", "unknown"))[1])
    # Negotiated deals and unknown codes are not orders on the book: drop them, but keep a count.
    df.attrs["ignored_actions"] = {a: int(n) for a, n in df.loc[kind == "noaction", "ORDER_ACTION"].value_counts().items()}
    df.attrs["unknown_actions"] = {a: int(n) for a, n in df.loc[kind == "unknown", "ORDER_ACTION"].value_counts().items()}
    df.attrs["action_dates"] = sorted(df["ACTION_DATE"].unique())  # every row, including disregarded ones
    df = df[kind.isin(["entry", "exit", "pause", "fill"])].copy()
    df["kind"] = kind[df.index]
    df["t"] = df["ACTION_TIME"].astype(int).map(hhmmss_to_sec)
    df["side"] = df["ORDER_TRANSACTION"].map(SIDE)
    df["chain"] = df["ENTRY_ORDER_NUMBER"]
    # Integer ticks avoid float equality issues in consecutive-tick checks.
    df["tick"] = df["INSTRUMENT_TYPE"].map(TICK)
    df["price"] = pd.to_numeric(df["DISCLOSED_PRICE"], errors="coerce").fillna(0.0)
    df["price_ticks"] = (df["price"] / df["tick"]).round().astype(int)
    # Blank VOLUME_REMAINING only occurs on 0779 full fills ("expiredInMatch").
    df["vol"] = pd.to_numeric(df["VOLUME_REMAINING"], errors="coerce").fillna(0).astype(int)
    # Resting = entry or fill with lots left and a real price (a market order carries price 0
    # until 0788 Price Adjusted gives it one, so it is not resting before that).
    df["live"] = df["kind"].isin(["entry", "fill"]) & (df["vol"] > 0) & (df["price"] > 0)
    # Final exit (the order cannot come back): exits and full fills. Pauses and price-0
    # market orders are off the book but not final.
    df["final"] = (df["kind"] == "exit") | ((df["kind"] == "fill") & (df["vol"] == 0))
    # Stable sort: ACTION_TIME (second) then file row order. ACTION_TIME_US ignored.
    out = df.sort_values(["t", "row"], kind="stable").reset_index(drop=True)
    out.attrs = df.attrs
    return out


def hhmmss_to_sec(v: int) -> int:
    return v // 10000 * 3600 + v // 100 % 100 * 60 + v % 100


def sec_to_hhmmss(s: int) -> str:
    return f"{s // 3600:02d}:{s // 60 % 60:02d}:{s % 60:02d}"


def check_file_order(df: pd.DataFrame) -> dict:
    """Row-order sanity on the file as delivered (by original row number).
    ACTION_TIME_US is only used here as a cross-check, never for sequencing."""
    d = df.sort_values("row")
    t = d["t"]
    us = pd.to_numeric(d["ACTION_TIME_US"], errors="coerce")
    same = t.eq(t.shift())
    return {
        "time_goes_backwards": int((t.diff() < 0).sum()),
        "microseconds_go_backwards_within_second": int((same & (us < us.shift())).sum()),
    }


def out_of_order_rows(df: pd.DataFrame) -> list:
    """Rows whose ACTION_TIME is earlier than the row before them in the file (BRD: the TSORDR
    must be in sequential order; each such row is logged and Operations are alerted)."""
    d = df.sort_values("row")
    prev = d["t"].shift()
    bad = d[d["t"] < prev]
    return [{"row": int(r.row) + 2, "ACTION_TIME": sec_to_hhmmss(r.t), "previous ACTION_TIME": sec_to_hhmmss(int(p)),
             "ORDER_ACTION": r.ORDER_ACTION, "ENTRY_ORDER_NUMBER": r.ENTRY_ORDER_NUMBER}
            for r, p in zip(bad.itertuples(index=False), prev[bad.index])]


@dataclass
class ChainReport:
    chains: int
    modifies: int
    bad_links: int
    bad_numbers: int
    not_starting_with_new: int
    mixed_attrs: int
    events_after_terminal: int
    live_at_eod: int


def validate_chains(df: pd.DataFrame) -> ChainReport:
    current = {}  # chain -> live ORDER_NUMBER
    terminated = set()
    bad_links = bad_numbers = after_term = modifies = 0
    for r in df.itertuples(index=False):
        c = r.chain
        if c in terminated:
            after_term += 1
        if r.ORDER_ACTION == NEW:
            current[c] = r.ORDER_NUMBER
        elif r.ORDER_ACTION == MODIFY:
            modifies += 1
            bad_links += r.INITIATING_ORDER_NUMBER != current.get(c)
            current[c] = r.ORDER_NUMBER
        elif r.ORDER_ACTION in (DELETE, EXPIRE, TRADE):
            bad_numbers += r.ORDER_NUMBER != current.get(c)
        else:  # 0788/0790/suspend/disconnect codes: follow whatever ORDER_NUMBER they carry
            current[c] = r.ORDER_NUMBER
        if r.final:
            terminated.add(c)
    g = df.groupby("chain", sort=False)
    mixed = (g[["THIS_REAL_TRADER_ID", "SYMBOL_CODE", "side"]].nunique() > 1).any(axis=1).sum()
    return ChainReport(
        chains=g.ngroups,
        modifies=modifies,
        bad_links=bad_links,
        bad_numbers=bad_numbers,
        not_starting_with_new=int((g["ORDER_ACTION"].first() != NEW).sum()),
        mixed_attrs=int(mixed),
        events_after_terminal=after_term,
        live_at_eod=int(g["live"].last().sum()),
    )


def lifecycle(df: pd.DataFrame, chain: str) -> pd.DataFrame:
    out = df[df["chain"] == chain].copy()
    out["time"] = out["t"].map(sec_to_hhmmss)
    out["state"] = out["live"].map({True: "LIVE", False: "REMOVED"})
    return out[[
        "row", "time", "ORDER_ACTION", "THIS_REAL_TRADER_ID", "SYMBOL_CODE", "side",
        "ORDER_NUMBER", "INITIATING_ORDER_NUMBER", "ORIGINAL_VOLUME", "vol", "price",
        "TRADE_PRICE", "VOLUME_TRADED", "DELETE_REASON", "state",
    ]]
