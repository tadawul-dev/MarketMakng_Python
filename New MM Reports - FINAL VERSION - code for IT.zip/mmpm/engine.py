"""Step 3: eligibility engine and three independent streaks per MM/symbol.

Only seconds in [WINDOW_START, WINDOW_END) are scored. Events before the
window still build the book, so orders resting at 09:30:00 count from then.

The book only changes at seconds with events, so eligibility is evaluated at
those change points and held constant until the next one. Every second in the
window is covered; there is no requirement for activity in a second.

Second rule (SECOND_RULE, per model):
  "any": a second passes a metric if it passed at ANY moment in that second,
         i.e. the book at the start of the second or after any of its events.
         Fully eligible needs spread AND depth at the same moment.
  "end": only the book after the last event of the second counts (BRD: "End of
         second").
"""
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .book import BUY, SELL, OK, MISSING, MIN_LOT, MODELS, Book
from .config import Config, Contract
from .parser import ACTIONS, DELETE, EXPIRE, TRADE, MODIFY, NEW, TICK, hhmmss_to_sec, sec_to_hhmmss

WINDOW_START = hhmmss_to_sec(93000)
WINDOW_END = hhmmss_to_sec(153000)  # exclusive
SPREAD_MAX_TICKS = 2
METRICS = ("spread", "depth", "combined")
SECOND_RULE = {"new": "end"}  # BRD presence time rule: end of second
# Per model: lots override, qualifying order book (ladder), fixed type tick size and 1-tick gap.
MODEL_OPTIONS = {"new": {"min_lots": None, "ladder": True, "fixed_ticks": False}}


@dataclass
class Eval:
    spread: bool
    depth: bool
    spread_detail: str
    depth_detail: str
    depth_fail_sides: str = ""
    missing_levels: str = ""
    undersized_levels: str = ""
    combined_flag: Optional[bool] = None  # set when spread/depth are best-of-second

    @property
    def combined(self) -> bool:
        return self.spread and self.depth if self.combined_flag is None else self.combined_flag

    def ok(self, metric: str) -> bool:
        return getattr(self, metric)


def evaluate(book: Book, tick: float, spread_ticks: int = SPREAD_MAX_TICKS, ladder: bool = False) -> Eval:
    """ladder=False: L1-L5 counted from the best price.
    ladder=True (BRD): depth uses each side's compliant ladder, i.e. the best price
    from which 5 consecutive ticks meet the min lots; smaller orders in front of it
    are extra liquidity. Both ladders must exist and be within `spread_ticks` of
    each other."""
    b, s = book.best(BUY), book.best(SELL)
    if b is None or s is None:
        missing = " and ".join(x for x, v in ((BUY, b), (SELL, s)) if v is None)
        spread, sd = False, f"no {missing} L1"
    else:
        gap = s[0] - b[0]
        spread = gap <= spread_ticks
        sd = (f"SELL L1 {s[0] * tick:.2f} - BUY L1 {b[0] * tick:.2f} = {gap} ticks"
              f" ({'<=' if spread else '>'} {spread_ticks})")

    parts, fail_sides, missing, undersized = [], [], [], []
    starts = {side: book.ladder_start(side) for side in (BUY, SELL)} if ladder else {}
    if ladder and starts[BUY] is not None and starts[SELL] is not None:
        lb, ls = starts[BUY], starts[SELL]
        gap = ls - lb
        extras = [f"{side} {px * tick:.2f} x{v}" for side, lad in ((BUY, lb), (SELL, ls))
                  for px, v in sorted(book.prices(side).items())
                  if (px > lad if side == BUY else px < lad)]
        extra = f"; inside order(s) treated as extra: {', '.join(extras)}" if extras else ""
        ok = gap <= spread_ticks
        return Eval(
            spread=spread, depth=ok, spread_detail=sd,
            depth_detail=(f"ladders BUY from {lb * tick:.2f}, SELL from {ls * tick:.2f} ({gap} ticks apart"
                          f"{' <= ' if ok else ' > '}{spread_ticks}){extra}"),
            depth_fail_sides="" if ok else "ladder gap",
        )
    for side in (BUY, SELL):
        if ladder and starts[side] is not None:
            continue  # this side has a compliant ladder
        bad = [l for l in book.depth(side) if l.status != OK]
        if not bad:
            continue
        fail_sides.append(side)
        for l in bad:
            tag = f"{side} L{l.level}"
            if l.status == MISSING:
                missing.append(tag)
                px = "no L1" if l.price_ticks is None else f"{l.price_ticks * tick:.2f}"
                parts.append(f"{tag} MISSING ({px})")
            else:
                undersized.append(tag)
                parts.append(f"{tag} UNDERSIZED ({l.price_ticks * tick:.2f} vol {l.volume} < {l.min_lot})")
    return Eval(
        spread=spread,
        depth=not fail_sides,
        spread_detail=sd,
        depth_detail=("; ".join(parts) + ("; no full compliant ladder on that side" if ladder else "")
                      if parts else "all L1-L5 OK both sides"),
        depth_fail_sides="+".join(fail_sides),
        missing_levels=", ".join(missing),
        undersized_levels=", ".join(undersized),
    )


def removal_context(rows) -> str:
    """Why orders left the book in this second: DELETE_REASON of withdrawals, expiries and
    full fills; the action name for suspensions, disconnects and the kill switch."""
    c = Counter()
    for r in rows:
        if r.kind in ("exit", "pause") or (r.kind == "fill" and not r.live):
            c[f"{r.side} {r.DELETE_REASON or ACTIONS[r.ORDER_ACTION][0]}"] += 1
    return "; ".join(f"{k} x{n}" for k, n in c.items())


def event_summary(rows) -> str:
    names = {NEW: "new", MODIFY: "modify", DELETE: "delete", EXPIRE: "expire", TRADE: "fill"}
    c = Counter(names.get(r.ORDER_ACTION, ACTIONS.get(r.ORDER_ACTION, (r.ORDER_ACTION,))[0].lower())
                for r in rows)
    return ", ".join(f"{n} {k}" for k, n in c.items())


@dataclass
class Segment:
    start: int
    end: int  # exclusive
    ev: Eval
    rows: list  # events in the second the segment starts
    hidden: list = field(default_factory=list)  # live orders the model does not count (if any)
    note: str = ""  # shown when the segment starts without events of its own
    ctx_rows: list = field(default_factory=list)  # events that produced this state
    suspended: bool = False  # trading in the contract was suspended: these seconds are not counted


def best_of_second(states: List[Eval]) -> Eval:
    """Pass a metric if any moment in the second passed it. Details come from
    the end-of-second state (for a failing metric every moment failed)."""
    end = states[-1]
    return Eval(
        spread=any(e.spread for e in states),
        depth=any(e.depth for e in states),
        spread_detail=end.spread_detail, depth_detail=end.depth_detail,
        depth_fail_sides=end.depth_fail_sides, missing_levels=end.missing_levels,
        undersized_levels=end.undersized_levels,
        combined_flag=any(e.spread and e.depth for e in states),
    )


def segments(df: pd.DataFrame, mm: str, symbol: str, tick: float,
             model: str = "new", rule: Optional[str] = None,
             spread_ticks: int = SPREAD_MAX_TICKS, min_lots: tuple = MIN_LOT,
             window: Tuple[int, int] = (WINDOW_START, WINDOW_END),
             itype: Optional[str] = None, ladder: Optional[bool] = None,
             level_step: int = 1) -> List[Segment]:
    """Piecewise-constant eligibility over [window start, window end)."""
    WINDOW_START, WINDOW_END = window
    rule = rule or SECOND_RULE[model]
    mask = (df.THIS_REAL_TRADER_ID == mm) & (df.SYMBOL_CODE == symbol)
    if itype is not None:
        mask &= df.INSTRUMENT_TYPE == itype
    sub = df[mask]
    if len(sub) and abs(sub.tick.iloc[0] - tick) > 1e-12:
        # configured tick size differs from the type default: re-express prices in that tick
        sub = sub.assign(price_ticks=(sub.price / tick).round().astype(int))
    opts = MODEL_OPTIONS[model]
    ladder = opts["ladder"] if ladder is None else ladder
    lots = opts["min_lots"] or min_lots
    book = MODELS[model](min_lots=lots, level_step=level_step)
    hidden = lambda: book.hidden() if hasattr(book, "hidden") else []
    cur = evaluate(book, tick, spread_ticks, ladder)
    hidden_prev: list = []
    pts: List[Segment] = []
    rows_iter = list(sub.itertuples(index=False))
    i = 0
    while i < len(rows_iter):
        t = rows_iter[i].t
        batch, states = [], [cur]
        while i < len(rows_iter) and rows_iter[i].t == t:
            book.apply(rows_iter[i])
            batch.append(rows_iter[i])
            if rule == "any":
                states.append(evaluate(book, tick, spread_ticks, ladder))
            i += 1
        end = states[-1] if rule == "any" else evaluate(book, tick, spread_ticks, ladder)
        if t >= WINDOW_END:
            break
        if t >= WINDOW_START:
            if not pts and t > WINDOW_START:
                pts.append(Segment(WINDOW_START, 0, cur, [], hidden_prev, "(carried into window)"))
            sec = best_of_second(states) if rule == "any" else end
            pts.append(Segment(t, 0, sec, batch, hidden()))
            if rule == "any" and t + 1 < WINDOW_END:
                pts.append(Segment(t + 1, 0, end, [], hidden(),
                                   f"(no events; book as left at end of {sec_to_hhmmss(t)})", batch))
        cur, hidden_prev = end, hidden()
    if not pts:
        pts.append(Segment(WINDOW_START, 0, cur, [], hidden(),
                           "(carried into window)"))
    # drop carry points overwritten by the next event second, then set ends
    out = []
    for seg in pts:
        if out and out[-1].start == seg.start:
            out[-1] = seg if seg.rows else out[-1]
            continue
        out.append(seg)
    for k, seg in enumerate(out):
        seg.end = out[k + 1].start if k + 1 < len(out) else WINDOW_END
    return out


@dataclass
class Result:
    streaks: List[dict] = field(default_factory=list)
    audit: List[dict] = field(default_factory=list)


def default_config(df: pd.DataFrame) -> Config:
    """Every trader x every SYMBOL_CODE in the file, with the built-in rules."""
    itype = df.groupby("SYMBOL_CODE").INSTRUMENT_TYPE.first()
    contracts = [Contract(f"C{i}", sym, sym, itype[sym], SPREAD_MAX_TICKS, MIN_LOT,
                          {"SSF": 40, "INF": 100}.get(itype[sym], 0))
                 for i, sym in enumerate(sorted(itype.index), 1)]
    mms = [(u, u) for u in sorted(df.THIS_REAL_TRADER_ID.unique())]
    return Config(contracts, mms, WINDOW_START, WINDOW_END)


def _labels(mm: str, c: Contract) -> dict:
    return {"MM": mm, "Symbol": c.symbol, "Contract": c.id, "Contract Name": c.name}


def split_suspended(segs: List[Segment], spans: List[Tuple[int, int]]) -> List[Segment]:
    """Cut the segments at the suspension boundaries and mark the suspended parts."""
    if not spans:
        return segs
    cuts = sorted({x for a, b in spans for x in (a, b)})
    out = []
    for g in segs:
        points = [g.start] + [x for x in cuts if g.start < x < g.end] + [g.end]
        for k, (a, b) in enumerate(zip(points, points[1:])):
            part = g if k == 0 else Segment(a, b, g.ev, [], g.hidden, "(continues)", g.rows or g.ctx_rows)
            part.start, part.end = a, b
            part.suspended = any(x <= a and b <= y for x, y in spans)
            out.append(part)
    return out


def contract_segments(df: pd.DataFrame, mm: str, c: Contract, cfg: Config, model: str,
                      rule: Optional[str] = None, min_lots: Optional[tuple] = None,
                      ladder: Optional[bool] = None, fixed_ticks: bool = False,
                      date: Optional[str] = None) -> List[Segment]:
    """Uses the contract's configured tick size and tick variance, unless the model (or
    `fixed_ticks`) keeps the type tick size and a 1-tick gap."""
    fixed = MODEL_OPTIONS[model]["fixed_ticks"] or fixed_ticks
    tick = c.default_tick if fixed else c.tick
    step = 1 if fixed else c.level_step
    segs = segments(df, mm, c.symbol, tick, model, rule, c.spread_ticks, min_lots or c.min_lots,
                    (cfg.start, cfg.end), c.itype, ladder, step)
    return split_suspended(segs, cfg.suspended(c.symbol, date)) if date else segs


def run_pair(df: pd.DataFrame, mm: str, symbol: str, tick: float, res: Result,
             segs: Optional[List[Segment]] = None, window: Tuple[int, int] = (WINDOW_START, WINDOW_END),
             labels: Optional[dict] = None) -> None:
    segs = segs if segs is not None else segments(df, mm, symbol, tick, window=window)
    labels = labels or {"MM": mm, "Symbol": symbol}
    window_end = window[1]
    for metric in METRICS:
        start: Optional[int] = None
        for seg in segs:
            ok = seg.ev.ok(metric) and not seg.suspended
            if ok and start is None:
                start = seg.start
                res.audit.append(_audit(labels, metric, "START", seg, None))
            elif not ok and start is not None:
                res.streaks.append(_streak(labels, metric, start, seg.start))
                res.audit.append(_audit(labels, metric, "BREAK", seg, seg.start - start))
                start = None
        if start is not None:
            res.streaks.append(_streak(labels, metric, start, window_end))
            res.audit.append({
                **labels, "Metric": metric, "Event": "WINDOW_CLOSE",
                "Time": sec_to_hhmmss(window_end), "Streak ended (s)": window_end - start,
            })


def _streak(labels, metric, start, end) -> dict:
    return {**labels, "Metric": metric, "Start": start, "End": end, "Duration": end - start}


def _audit(labels, metric, kind, seg: Segment, ended: Optional[int]) -> dict:
    ev = seg.ev
    row = {
        **labels, "Metric": metric, "Event": kind,
        "Time": sec_to_hhmmss(seg.start),
        "Streak ended (s)": ended,
        "Spread OK": ev.spread, "Depth OK": ev.depth,
        "Spread detail": ev.spread_detail,
    }
    if kind == "BREAK" and metric in ("depth", "combined") and not ev.depth:
        row.update({
            "Depth failing side(s)": ev.depth_fail_sides,
            "Missing price (gap)": ev.missing_levels,
            "Undersized volume": ev.undersized_levels,
            "Depth detail": ev.depth_detail,
        })
    if kind == "BREAK" and metric == "combined":
        row["Failed component"] = " + ".join(
            m for m, ok in (("spread", ev.spread), ("depth", ev.depth)) if not ok)
    row["Events this second"] = event_summary(seg.rows) if seg.rows else seg.note
    row["Order removals (DELETE_REASON)"] = removal_context(seg.rows or seg.ctx_rows)
    return row


def run(df: pd.DataFrame, model: str = "new", cfg: Optional[Config] = None) -> Result:
    cfg = cfg or default_config(df)
    res = Result()
    dates = df.attrs.get("action_dates") or (sorted(df.ACTION_DATE.unique()) if len(df) else [])
    date = dates[0] if dates else None
    for _, mm in cfg.market_makers:
        for c in cfg.presence_contracts:
            run_pair(df, mm, c.symbol, c.tick, res, contract_segments(df, mm, c, cfg, model, date=date),
                     (cfg.start, cfg.end), _labels(mm, c))
    return res


def summary(df: pd.DataFrame, res: Result, cfg: Optional[Config] = None) -> pd.DataFrame:
    """One row per (MM, contract config row)."""
    cfg = cfg or default_config(df)
    st = pd.DataFrame(res.streaks, columns=["MM", "Symbol", "Contract", "Contract Name",
                                            "Metric", "Start", "End", "Duration"])
    rows = []
    for _, mm in cfg.market_makers:
        for c in cfg.presence_contracts:
            r = {"MM": mm, "Symbol": c.symbol, "Contract": c.id, "Contract Name": c.name,
                 "Instrument type": c.itype}
            for m in METRICS:
                d = st[(st.MM == mm) & (st.Contract == c.id) & (st.Metric == m)].Duration
                r[f"{m}_time"] = int(d.sum())
                r[f"{m}_count"] = len(d)
                r[f"{m}_longest"] = int(d.max()) if len(d) else 0
            rows.append(r)
    return pd.DataFrame(rows)
