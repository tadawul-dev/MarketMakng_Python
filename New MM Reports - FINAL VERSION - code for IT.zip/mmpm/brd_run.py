"""End-of-day and end-of-month jobs as defined in the BRD.

daily():   order file (TSORDR) -> Derivatives Daily Summary Report (consolidated and one
           segregated report per market maker) -> emails -> log. The day's results are kept
           for the monthly report. Running it again for the same day regenerates that day
           (e.g. after the MM config file was updated).
monthly(): Derivatives Market Maker Monthly Eligibility Status from the kept daily results.

Output folder (technical configuration "output_dir"):
  daily/<YYYYMMDD>/          consolidated report + segregated/<one file per market maker>
  results/<YYYYMMDD>.json    the day's Daily Summary rows and the MM config file used
  monthly/                   monthly reports
  logs/<YYYYMMDD>.log        what happened on each run (kept, one file per day)
  outbox/<run>/              emails, when the email mode is "outbox"
"""
import datetime as dt
import glob
import json
import os
from dataclasses import dataclass, field
from typing import List, Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from . import brd, mailer
from . import config as config_mod
from . import techconfig
from .config import Config
from .engine import run, summary
from .parser import ACTIONS, load, out_of_order_rows, validate_chains
from .checks import code_version, config_warnings
from .trades import traded_volume


class RunError(Exception):
    """The order file cannot be processed; nothing was generated."""


@dataclass
class DailyResult:
    trade_date: str
    consolidated: str
    segregated: dict = field(default_factory=dict)  # MM id -> path
    log: List[str] = field(default_factory=list)
    out_of_order: List[dict] = field(default_factory=list)
    emails: List[str] = field(default_factory=list)
    log_path: str = ""
    monthly: str = ""


class Log:
    def __init__(self):
        self.lines: List[str] = []

    def __call__(self, text: str):
        self.lines.append(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S}  {text}")

    def write(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a") as f:
            f.write("\n".join(self.lines) + "\n\n")


def _json_rows(rows: List[dict]) -> List[dict]:
    return [{k: (v.isoformat() if isinstance(v, dt.date) else v) for k, v in r.items() if not k.startswith("_")}
            for r in rows]


def daily(path: str, cfg: Optional[Config] = None, tech: Optional[dict] = None,
          send: bool = True) -> DailyResult:
    cfg = cfg or config_mod.load()
    tech = tech or techconfig.load()
    out = tech["output_dir"]
    log = Log()
    log(f"{brd.TOOL} run started: {os.path.basename(path)} (code version {code_version() or 'n/a'})")
    df = load(path)
    dates = df.attrs.get("action_dates") or list(df.ACTION_DATE.unique())
    if len(dates) != 1:
        raise RunError(f"Expected one ACTION_DATE per order file, found {list(dates)}")
    date = dates[0]
    log_path = os.path.join(out, "logs", f"{date}.log")
    messages = []
    sender = tech["email"].get("sender", "")
    try:
        chk = validate_chains(df)
        if chk.bad_links or chk.bad_numbers or chk.not_starting_with_new or chk.mixed_attrs \
                or chk.events_after_terminal:
            raise RunError(f"Order file structure is not as expected ({chk}). Every order must start with "
                           f"Queued (0772) in the day's file; no report was generated.")
        for a, n in df.attrs.get("unknown_actions", {}).items():
            log(f"Order action {a} is not listed in the BRD: {n} rows disregarded")
        for a, n in df.attrs.get("ignored_actions", {}).items():
            log(f"Negotiated deal action {a} {ACTIONS[a][0]}: {n} rows disregarded "
                f"(no presence time, no traded volume)")
        bad_order = out_of_order_rows(df)
        for r in bad_order:
            log(f"Order file not in sequential order: file line {r['row']} ACTION_TIME {r['ACTION_TIME']} "
                f"is earlier than the line before it ({r['previous ACTION_TIME']}); "
                f"order {r['ENTRY_ORDER_NUMBER']}, action {r['ORDER_ACTION']}")
        if bad_order:
            log(f"{len(bad_order)} out-of-order rows; orders were arranged by ACTION_TIME. "
                f"Operations alerted; check before the reports are used")
            if not tech["operations_email_list"]:
                log("No Operations email list configured: the out-of-order alert could not be sent")
            messages.append(mailer.message(
                sender, tech["operations_email_list"],
                mailer.ALERT_SUBJECT.format(what="order file not in sequential order", date=date),
                f"The order file {os.path.basename(path)} has {len(bad_order)} rows with an earlier ACTION_TIME "
                f"than the row before them. The orders were arranged by ACTION_TIME. Please check the order "
                f"file before the reports are used. Details are in the log for {date}.\n"))
        for w in config_warnings(df, cfg):
            log(w)

        res = run(df, "new", cfg)
        summ = summary(df, res, cfg)
        vol = traded_volume(df, cfg)
        daily_rows = brd.summary_rows(summ, vol, cfg, date)
        streaks = brd.streak_rows(res, cfg, date)
        audit = brd.audit_rows(df, cfg, date)

        folder = os.path.join(out, "daily", date)
        os.makedirs(os.path.join(folder, "segregated"), exist_ok=True)
        if os.path.exists(os.path.join(folder, brd.file_name(date))):
            log("Reports for this day already existed and were regenerated")
        result = DailyResult(date, os.path.join(folder, brd.file_name(date)), log_path=log_path)
        brd.write(result.consolidated, daily_rows, streaks, audit)
        log(f"Consolidated report: {result.consolidated}")
        names = cfg.mm_names
        for _, mm in cfg.market_makers:
            p = os.path.join(folder, "segregated", brd.file_name(date, names[mm]))
            brd.write(p, brd.only(daily_rows, "MMID", mm), brd.only(streaks, "MM", mm), brd.only(audit, "MM", mm))
            result.segregated[mm] = p
        log(f"Segregated reports: {len(result.segregated)}")

        os.makedirs(os.path.join(out, "results"), exist_ok=True)
        with open(os.path.join(out, "results", f"{date}.json"), "w") as f:
            json.dump({"trade_date": date, "source_file": os.path.basename(path),
                       "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
                       "code_version": code_version(), "mm_config": config_mod.to_json(cfg),
                       "daily_summary": _json_rows(daily_rows)}, f, indent=1)

        when = brd.trading_date_text(date)
        if tech["stg_email_list"]:
            messages.append(mailer.message(sender, tech["stg_email_list"], mailer.STG_SUBJECT.format(date=when),
                                           mailer.STG_BODY.format(date=when), [result.consolidated]))
        else:
            log("No STG email list configured: the consolidated report was not sent")
        for name, mm in cfg.market_makers:
            to = cfg.emails.get(mm, [])
            if not to:
                log(f"No email list configured for market maker {name} ({mm}): segregated report not sent")
                continue
            messages.append(mailer.message(sender, to, mailer.MM_SUBJECT.format(name=name),
                                           mailer.MM_BODY.format(name=name, date=when), [result.segregated[mm]]))
        result.out_of_order = bad_order
        for month, (first, last) in cfg.monthly_periods.items():
            if last == date:  # last trading day of the month: the monthly report is produced now
                result.monthly = monthly(month, tech, send, cfg)
                log(f"Last trading day of {month[:4]}-{month[4:]}: monthly report produced ({result.monthly})")
    except RunError as e:
        log(f"FAILED: {e}")
        messages.append(mailer.message(sender, tech["operations_email_list"],
                                       mailer.ALERT_SUBJECT.format(what="order file not processed", date=date),
                                       f"{e}\n"))
        if send and tech["operations_email_list"]:
            _send(messages[-1:], tech, out, log)
        log.write(log_path)
        raise
    if send:
        result.emails = _send([m for m in messages if m["To"]], tech, out, log)
    log("Run finished")
    result.log = log.lines
    log.write(log_path)
    return result


def _send(messages, tech, out, log) -> List[str]:
    box = os.path.join(out, "outbox", dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
    try:
        done = mailer.deliver(messages, tech["email"], box)
    except Exception as e:  # the reports stay generated; the failure is logged
        log(f"Email delivery FAILED: {type(e).__name__}: {e}")
        return []
    for d in done:
        log(d)
    return done


# ---------------------------------------------------------------- monthly report

MONTHLY_TITLE = "Derivatives Market Maker Monthly Eligibility Status"
TYPE_MONTHLY = {"IF": "IF", "SSF": "SSF"}  # BRD: IF (Index Futures) or SSF


def monthly_rows(results: List[dict]) -> List[dict]:
    """Actual trading days (order files received), eligible days and
    compliance rate = eligible days / trading days x 100.

    Index Futures: one row per market maker and underlying; a day is eligible when its
                   Eligibility Flag is YES.
    Single Stock Futures: one row per market maker; a day is eligible only when the Eligibility
                   Flag is YES on every SSF contract configured for it that day (one NO = the
                   market maker is not eligible for SSF that day).
    A contract suspended for the whole session (Eligibility Flag SUSPENDED) does not count that day:
    the day is left out of its trading days, and for SSF only the other SSFs are checked."""
    days = len(results)
    rows, seen = {}, []

    def row(key, mm, underlying, typ):
        if key not in rows:
            rows[key] = {"Market Maker": mm, "Underlying": underlying, "Type": typ,
                         "Actual trading days": days, "Market Makers eligibility days": 0, "_symbols": [],
                         "_suspended": []}
            seen.append(key)
        return rows[key]

    for day in results:
        d = day.get("trade_date", "")
        when = dt.date(int(d[:4]), int(d[4:6]), int(d[6:])).strftime("%-d %b %Y") if len(d) == 8 else ""
        ssf = {}  # MM -> [flags of its SSF contracts that day]
        for r in day["daily_summary"]:
            if r["Type"] == "SSF":
                flags = ssf.setdefault(r["MMID"], [])
                x = row((r["MMID"], "SSF"), r["MMID"], "", "SSF")
                if r["Eligibility Flag"] != "SUSPENDED":
                    flags.append(r["Eligibility Flag"] == "YES")
                else:
                    x["_suspended"].append(f'{r["Symbol"]} ({when})' if when else r["Symbol"])
                if r["Symbol"] not in x["_symbols"]:
                    x["_symbols"].append(r["Symbol"])
            else:
                x = row((r["MMID"], r["Symbol"], r["Type"]), r["MMID"], r["Symbol"], TYPE_MONTHLY.get(r["Type"], r["Type"]))
                if r["Eligibility Flag"] == "SUSPENDED":
                    x["Actual trading days"] -= 1
                    x["_suspended"].append(f'{r["Symbol"]} ({when})' if when else r["Symbol"])
                else:
                    x["Market Makers eligibility days"] += r["Eligibility Flag"] == "YES"
        for mm, flags in ssf.items():
            if flags:
                rows[(mm, "SSF")]["Market Makers eligibility days"] += all(flags)
            else:  # every SSF of the market maker was suspended that day
                rows[(mm, "SSF")]["Actual trading days"] -= 1
    out = [rows[k] for k in seen]
    for r in out:
        if r["Type"] == "SSF":
            r["Underlying"] = ", ".join(r["_symbols"])
        del r["_symbols"]
        r["Suspensions"] = "; ".join(r.pop("_suspended")) or "None"
        n = r["Actual trading days"]
        r["Compliance Rate"] = round(r["Market Makers eligibility days"] / n * 100, 2) if n else 0.0
    return out


def month_period(month: str, cfg: Config) -> tuple:
    """(first, last) trading day of a month (YYYYMM): as set by Operations in the MM config file,
    otherwise the calendar month."""
    return cfg.monthly_periods.get(month, (f"{month}01", f"{month}31"))


def _monthly_workbook(path: str, rows: List[dict], month_name: str) -> None:
    rate_col = f"Compliance Rate for the Month of {month_name}"
    cols = ["Market Maker", "Underlying", "Type", "Actual trading days", "Market Makers eligibility days", rate_col,
            "Suspensions"]
    wb = Workbook()
    ws = wb.active
    ws.title = "Monthly Eligibility Status"
    r = 1
    for title, typ in (("Index Futures", "IF"), ("Single Stock Futures", "SSF")):
        ws.cell(row=r, column=1, value=title).font = Font(name="Calibri", bold=True, size=12)
        r += 1
        for i, c in enumerate(cols, 1):
            cell = ws.cell(row=r, column=i, value=c)
            cell.font = Font(name="Calibri", bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F3864")
            ws.column_dimensions[get_column_letter(i)].width = 22
        r += 1
        for row in [x for x in rows if x["Type"] == typ]:
            vals = [*[row[c] for c in cols[:-2]], row["Compliance Rate"], row["Suspensions"]]
            for i, v in enumerate(vals, 1):
                ws.cell(row=r, column=i, value=v).font = Font(name="Calibri")
            ws.cell(row=r, column=len(cols) - 1).number_format = '0.00"%"'
            r += 1
        r += 1
    wb.save(path)


def monthly(month: str, tech: Optional[dict] = None, send: bool = True, cfg: Optional[Config] = None) -> str:
    """month = YYYYMM. Uses the kept daily results from the first to the last trading day of the month
    (set by Operations in the MM config file). Writes the internal report and one report per market
    maker (only its own rows); emails the internal list and each market maker's email list."""
    tech = tech or techconfig.load()
    cfg = cfg or config_mod.load()
    out = tech["output_dir"]
    first, last = month_period(month, cfg)
    files = sorted(f for f in glob.glob(os.path.join(out, "results", "????????.json"))
                   if first <= os.path.basename(f)[:8] <= last)
    if not files:
        raise RunError(f"No daily results from {first} to {last} in {os.path.join(out, 'results')}")
    results = [json.load(open(f)) for f in files]
    rows = monthly_rows(results)
    name = dt.date(int(month[:4]), int(month[4:]), 1).strftime("%B %Y")
    folder = os.path.join(out, "monthly")
    os.makedirs(os.path.join(folder, "segregated"), exist_ok=True)
    base = f"{brd.TOOL} - Monthly Eligibility Status_{month[:4]}-{month[4:]}"
    path = os.path.join(folder, base + ".xlsx")
    _monthly_workbook(path, rows, name)
    names = {r["MMID"]: r["Market Maker"] for day in results for r in day["daily_summary"]}
    segregated = {}
    for mm in dict.fromkeys(r["Market Maker"] for r in rows):
        p = os.path.join(folder, "segregated", f"{base}_{brd.safe_name(names.get(mm, mm))}.xlsx")
        _monthly_workbook(p, [r for r in rows if r["Market Maker"] == mm], name)
        segregated[mm] = p
    log = Log()
    log(f"Monthly report {month} ({first} to {last}): {len(files)} trading days -> {path}; "
        f"{len(segregated)} market maker reports")
    if send:
        sender, messages = tech["email"].get("sender", ""), []
        if tech["stg_email_list"]:
            messages.append(mailer.message(sender, tech["stg_email_list"], mailer.MONTHLY_SUBJECT.format(month=name),
                                           mailer.MONTHLY_BODY.format(month=name), [path]))
        else:
            log("No internal email list configured: the monthly report was not sent")
        for mm_name, mm in cfg.market_makers:
            if mm not in segregated:
                continue
            to = cfg.emails.get(mm, [])
            if not to:
                log(f"No email list configured for market maker {mm_name} ({mm}): monthly report not sent")
                continue
            messages.append(mailer.message(sender, to, mailer.MM_SUBJECT.format(name=mm_name),
                                           mailer.MM_MONTHLY_BODY.format(name=mm_name, month=name), [segregated[mm]]))
        _send(messages, tech, out, log)
    log.write(os.path.join(out, "logs", f"monthly_{month}.log"))
    return path
