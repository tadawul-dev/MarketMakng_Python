"""Report emails (BRD: Distribution of the Derivatives Daily Summary Report).

Delivery mode comes from the technical configuration file:
  "outbox": every email is written as a .eml file to the outbox folder (nothing is sent);
            use this for testing, or when another system sends the emails.
  "smtp"  : sent through the configured SMTP server; the user name and password are read
            from the environment variables named in the configuration (never stored in files).
"""
import mimetypes
import os
import smtplib
from email.message import EmailMessage
from typing import List

MM_SUBJECT = "Saudi Exchange Market Making Performance - {name}"
MM_BODY = """Hello All,

Please find attached {name} Market Making performance report for both Single Stock Futures and Index Futures, on the {date}.

Let us know if you have any questions or require further clarification.

Regards
"""
# Internal email list (STG): the consolidated reports.
STG_SUBJECT = "Futures Market Makers Performance for the day {date}"
STG_BODY = "Attached is the Futures Market Makers Performance for the day {date}.\n"
MONTHLY_SUBJECT = "Futures Market Makers Performance for the month {month}"
MONTHLY_BODY = "Attached is the Futures Market Makers Performance for the month {month}.\n"
# Each market maker's own monthly report.
MM_MONTHLY_BODY = """Hello All,

Please find attached {name} Market Making monthly performance report for both Single Stock Futures and Index Futures, for the month of {month}.

Let us know if you have any questions or require further clarification.

Regards
"""
ALERT_SUBJECT = "New MM Reports alert - {what} - {date}"


def message(sender: str, to: List[str], subject: str, body: str, attachments: List[str] = ()) -> EmailMessage:
    m = EmailMessage()
    m["From"], m["To"], m["Subject"] = sender, ", ".join(to), subject
    m.set_content(body)
    for path in attachments:
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        main, sub = ctype.split("/", 1)
        with open(path, "rb") as f:
            m.add_attachment(f.read(), maintype=main, subtype=sub, filename=os.path.basename(path))
    return m


def deliver(messages: List[EmailMessage], email_cfg: dict, outbox: str) -> List[str]:
    """Send (smtp) or save (outbox) every message; returns one line per message for the log."""
    done = []
    if not messages:
        return done
    if email_cfg.get("mode", "outbox") == "smtp":
        host, port = email_cfg["smtp_host"], int(email_cfg.get("smtp_port", 587))
        with smtplib.SMTP(host, port, timeout=60) as s:
            if email_cfg.get("use_tls", True):
                s.starttls()
            user = os.environ.get(email_cfg.get("username_env", ""), "")
            if user:
                s.login(user, os.environ.get(email_cfg.get("password_env", ""), ""))
            for m in messages:
                s.send_message(m)
                done.append(f"sent: {m['Subject']} -> {m['To']}")
        return done
    os.makedirs(outbox, exist_ok=True)
    i = len([f for f in os.listdir(outbox) if f.endswith(".eml")])  # never overwrite an email already there
    for m in messages:
        i += 1
        path = os.path.join(outbox, f"{i:03d}.eml")
        with open(path, "wb") as f:
            f.write(bytes(m))
        done.append(f"saved to outbox ({path}): {m['Subject']} -> {m['To']}")
    return done
