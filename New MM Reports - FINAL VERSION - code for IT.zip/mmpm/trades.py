"""Traded lots per MM and contract config row, from 0779 fill rows.

Each trade has one TICKET_NUMBER shared by its buy row and sell row.
FILLED_VOLUME is the lots in that fill: on every 0779 row it equals the drop in
VOLUME_REMAINING, while VOLUME_TRADED is a running total per order (so it is not
summed). A self-trade (same THIS_REAL_TRADER_ID on both sides of a ticket) is
excluded from the MM's traded lots.

Traded lots use the WHOLE day: the configured time window applies only to the
presence calculations. Lots outside the window are shown for information.
"""
from typing import Optional

import pandas as pd

from .config import Config
from .parser import TRADE, sec_to_hhmmss

SELF = "Self-trade (same MM on both sides)"


def fills(df: pd.DataFrame, cfg: Optional[Config] = None) -> pd.DataFrame:
    f = df[df.ORDER_ACTION == TRADE].copy()
    f["lots"] = pd.to_numeric(f.FILLED_VOLUME, errors="coerce").fillna(0).astype(int)
    per_ticket = f.groupby("TICKET_NUMBER").THIS_REAL_TRADER_ID
    f["self_trade"] = (per_ticket.transform("nunique") == 1) & (per_ticket.transform("size") >= 2)
    f["one_sided"] = per_ticket.transform("size") < 2
    if cfg is not None:
        f["in_window"] = (f.t >= cfg.start) & (f.t < cfg.end)
    else:
        f["in_window"] = True
    f["excluded"] = ""
    f.loc[f.self_trade, "excluded"] = SELF
    return f


def traded_volume(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """One row per MM x contract config row.

    Traded lots          : this contract's own lots.
    Added lots (rollover): lots of volume-only contracts with the same Symbol.
    Total traded lots    : own + added; this is what the report and flag use.
    Volume-only rows keep their own lots for the breakdown; their total is blank.
    """
    f = fills(df, cfg)
    own = {}
    rows = []
    for _, mm in cfg.market_makers:
        for c in cfg.contracts:
            x = f[(f.THIS_REAL_TRADER_ID == mm) & (f.SYMBOL_CODE == c.symbol) & (f.INSTRUMENT_TYPE == c.itype)]
            ok, st = x[x.excluded == ""], x[x.excluded == SELF]
            outside = ok[~ok.in_window]
            own[(mm, c.id)] = int(ok.lots.sum())
            rows.append({
                "MM": mm, "Symbol": c.symbol, "Contract": c.id, "Contract Name": c.name,
                "Role": f"Volume only (added to {c.name})" if c.volume_only else "Main",
                "Traded lots": own[(mm, c.id)],
                "Added lots (rollover)": None, "Total traded lots": None,
                "Required Traded Lots": None if c.volume_only else c.required_lots,
                "Trades": int(ok.TICKET_NUMBER.nunique()),
                "Self-trade lots excluded": int(st.lots.sum()),
                "Self-trades excluded": int(st.TICKET_NUMBER.nunique()),
                "Lots outside time window (included)": int(outside.lots.sum()),
            })
    for r in rows:
        c = next(k for k in cfg.contracts if k.id == r["Contract"])
        if not c.volume_only:
            added = sum(own[(r["MM"], a.id)] for a in cfg.added_contracts(c))
            r["Added lots (rollover)"] = added
            r["Total traded lots"] = r["Traded lots"] + added
    return pd.DataFrame(rows)


def excluded_trades(df: pd.DataFrame, cfg: Optional[Config] = None) -> list:
    f = fills(df, cfg)
    ex = f[f.excluded != ""].sort_values(["t", "row"])
    return [{
        "Reason": r.excluded, "Ticket": r.TICKET_NUMBER, "Time": sec_to_hhmmss(r.t), "MM": r.THIS_REAL_TRADER_ID,
        "Symbol": r.SYMBOL_CODE, "Side": r.side, "Lots": r.lots, "Price": r.price,
        "Order": r.chain,
    } for r in ex.itertuples(index=False)]


def one_sided(df: pd.DataFrame) -> int:
    """Fills whose ticket has no matching opposite row (counterparty not in file)."""
    return int(fills(df).one_sided.sum())
