"""Run information and configuration checks recorded in the log."""
import os
import subprocess

import pandas as pd

from .config import Config


def code_version() -> str:
    try:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return subprocess.run(["git", "-C", here, "rev-parse", "--short", "HEAD"],
                              capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def config_warnings(df: pd.DataFrame, cfg: Config) -> list:
    notes = []
    in_file = set(zip(df.SYMBOL_CODE, df.INSTRUMENT_TYPE))
    configured = {(c.symbol, c.itype) for c in cfg.contracts}
    for sym, it in sorted(in_file - configured):
        notes.append(f"Contract {sym} ({it}) is in the order file but not in the configuration, so it is not reported.")
    for c in cfg.contracts:
        if (c.symbol, c.itype) not in in_file:
            if c.volume_only:
                notes.append(f"Rollover contract {c.symbol} / {c.name} ({c.itype}) is not in this order file; it adds 0 lots.")
            else:
                notes.append(f"Configured contract {c.symbol} / {c.name} ({c.itype}) has no rows in this order file; it shows zero.")
    for c in cfg.presence_contracts:
        if abs(c.tick - c.default_tick) > 1e-12:
            px = df[(df.SYMBOL_CODE == c.symbol) & (df.INSTRUMENT_TYPE == c.itype)].price
            off = px[((px / c.tick) - (px / c.tick).round()).abs() > 1e-6]
            if len(off):
                notes.append(f"Contract {c.symbol}: {len(off):,} order prices are not whole multiples of the "
                             f"configured tick size {c.tick:g} (e.g. {off.iloc[0]:g}); they are rounded to the nearest tick.")
    traders = set(df.THIS_REAL_TRADER_ID)
    mapped = {u for _, u in cfg.market_makers}
    for u in sorted(traders - mapped):
        notes.append(f"Trading user {u} is in the order file but not in the market maker list, so it is not reported.")
    for name, u in cfg.market_makers:
        if u not in traders:
            notes.append(f"Market maker {name} ({u}) has no rows in this order file; it shows zero.")
    return notes
