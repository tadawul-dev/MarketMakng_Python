/** 
 * #---------------------------------------------------------------------------------------------
 * #   This source is part of the Tadawul Web Listener, Saudi Stock Exchange
 * #   Copyright (c) 2009 Saudi Stock Exchange
 * #
 * #
 * #   All rights reserved.  No part of this source or any copyrights subsisting or arising out of these materials may be reproduced, distributed, amended, modified, adapted, stored in a
 * #   retrieval system, adopted or transmitted in any form or by any means,
 * #   electronic, mechanical, photographic, graphic, optic recording or otherwise,
 * #   translated in any language or computer language, without the prior written
 * #   permission of Saudi Stock Exchange
 * #
 * # ---------------------------------------------------------------------------------------------
 * ---------------------------------------------------------------------------------------------
 * FileName : LowVolmMessageType.java
 *
 *
 * Created Date : 19 April 2018
 *
 * Version             Date                     Author                  Change Description
 *----------------------------------------------------------------------------------------------
 * 1.0                 19 April 2018           Mohanram                  Initial Version
 *----------------------------------------------------------------------------------------------
*/

package sa.com.tadawul.website.tip.messages;

import sa.com.tadawul.website.tip.shared.TipConstants;

/**
 * This Enum is used in the switch statement to identify message type.
 * It is used to identify low volume message type. It will take string 
 * argument and return corresponding number.  
 */

public enum LowVolmMessageType {

	BASICDATABOND (1 , "BDBo"),
	BASICDATAINDEX (2 , "BDIn"),
	BASICDATALIST (3, "BDLi"),
	BASICDATARIGHT (4 , "BDRi"),
	BASICDATASHARE (5 , "BDSh"),
	INDEXSUMMARY (6, "INs"), // no update
	ORDERBOOKREFERENCEPRICE (7 , "OBRf"),
	//ORDERBOOKSUMMARY (8 , "OBs"), // no update
	TRADEHALT (9 , "TRh"), // no update
	ENDOFFILE (10, "EOs"),
	GENERALREPLY (11, "GEn"),
	HEARTBEAT (12, "HBt"),
	MARKETSTATE (13, "STa"),
	BASICDATAINDEXMEMBER(14,"BDIm");
	//SEQUENCENO(13,"n");
	
	private int value;
	private String messageTypeStr;
	
	static LowVolmMessageType messageType [];
	static int messageOrdinal;
	private LowVolmMessageType(int value, String messageTypeStr){
		this.value = value;
		this.messageTypeStr = messageTypeStr;
	}
	
	public static int getMessageValue(String message){
		
		messageType = LowVolmMessageType.values();
		
		for(LowVolmMessageType msg : messageType){
			if(msg.messageTypeStr.equals(message)) {
				messageOrdinal = msg.value;
				return messageOrdinal;
			}
		}
		return TipConstants.NODATAFOUND;
	}
	
}
