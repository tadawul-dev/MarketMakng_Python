package com.muqassa.marketmaking.job;

//import com.muqassa.marketmaking.database.SavingDataToDB;

//import com.muqassa.marketmaking.database.SavingDataToDB;
import com.muqassa.marketmaking.dto.*;
import com.muqassa.marketmaking.helper.OverallEligiblityCheck;
import com.muqassa.marketmaking.process.ProcessingThread;
import com.muqassa.marketmaking.service.EmailService;
import com.muqassa.marketmaking.service.MarketMakerService;
//import com.marketmakers.springboot_marketmaker_app.service.OrderProcessService;
import com.muqassa.marketmaking.service.OrderDispatcherService;
import com.muqassa.marketmaking.shared.SharedState;
import com.muqassa.marketmaking.thread.MMUniqueThread;
import com.muqassa.marketmaking.util.ExcelReportGenerator;
import lombok.Getter;
import org.apache.commons.io.function.IOBinaryOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Getter
@Component
public class MarketMakerJob {

    @Autowired
    private MarketMakerService marketMakerService;

    @Autowired
    private OrderDispatcherService orderDispatcherService;

    @Autowired
    private MMUniqueThread mmUniqueThread;


    @Autowired
    private SharedState sharedState;


    private static final Logger log = LoggerFactory.getLogger(ProcessingThread.class);


    private final EmailService emailService;


    @Autowired
    public MarketMakerJob(MMUniqueThread mmUniqueThread, EmailService emailService) {
        this.mmUniqueThread = mmUniqueThread;
        this.emailService = emailService;
        // this.emailService = emailService;
        this.mmUniqueThread.setMarketMakerJob(this);
    }

    @Autowired
    private ExcelReportGenerator excelReportGenerator;

    //@Autowired
   // private SavingDataToDB savingDataToDB;

    @Value("${app.mail.to}")
    private String[] emailTo;

    @Value("${app.mail.from}")
    private String emailFrom;

    @Value("${app.mail.to.technical}")
    private String[] emailToTechnical;

    @Value("${marketmaker.config.file}")
    private String mmConfigFileInput;

    @Value("${marketmaker.timeconfig.file}")
    private String mmTimeConfigFile;

    @Value("${marketmaker.order.file}")
    private String orderFileInput;

    @Value("${marketmaker.environment}")
    private String environment;

    @Value("${report.filepath}")
    private String reportFilePath;

    @Value("${report.dailyperformance.file}")
    private String dailyPerformanceReport;

    @Value("${report.dailyeligibilitystatus.file}")
    private String dailyEligibilityReport;

    @Value("${report.dailyeligibilitystatusmmlevel.file}")
    private String dailyEligibilityStatusMMLevelReport;

    @Value("${report.secondreport.file}")
    private String secondReport;

    @Value("${report.thirdReport.file}")
    private String ThirdReport;

    @Value("${report.monthly.file}")
    private String monthlyReport;

    @Value("${report.streaks.file:Derivatives Daily Streaks}")
    private String streaksReport;

    @Value("${report.audit.file:Derivatives Daily Audit Trail}")
    private String auditReport;

    @Value("${marketmaker.date.format}")
    private String dateFormatString;

    private boolean errorOccurred = false;

    private String datePart;

    public String getOrderFilePath(String userProvidedDate) {


        if (userProvidedDate != null && !userProvidedDate.isEmpty() && isValidDate(userProvidedDate, dateFormatString)) {


            datePart = userProvidedDate;
        } else {
            datePart = LocalDate.now().format(DateTimeFormatter.ofPattern(dateFormatString));
        }
        log.info("Application running for the date : {}", datePart);
        return datePart;
    }

    public boolean isValidDate(String userProvidedDate, String dateFormatString) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormatString);
            LocalDate.parse(userProvidedDate, formatter);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }


    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
    String dateFormat = LocalDate.now().format(formatter);


    public void readExcelOnSchedule(String userProvidedDate) {

        log.info("readExcelOnSchedule userProvidedDate {}", userProvidedDate);

        try {

            //*** Reading Market Config file
            List<MarketMakerDto> result_MMconfig = marketMakerService.processExcel(mmConfigFileInput);

            //*** Reading Time config file
            List<MMTimeConfigDto> result_Time_Config = marketMakerService.processExcelTime(mmTimeConfigFile);

           // Starting Threads as per unique MM_ID and symbol
            mmUniqueThread.setMarketMakerJob(this);
            mmUniqueThread.startWorkers(result_MMconfig, result_Time_Config);
            //*** Reading Order file
            try {
                String fileName = getOrderFilePath(userProvidedDate);
                String filePath = orderFileInput + "TSORDR-" + fileName + ".txt";

                log.info("Reading file:{} ", filePath);

                Path path = Paths.get(filePath);
                if (Files.exists(path)) {
                    LocalDate OrderDate = LocalDate.parse(fileName, formatter);
              //      savingDataToDB.saveOrderDate(OrderDate);
                    List<OrderFileDto> result_Order = marketMakerService.readCsvToDtoList(filePath, result_Time_Config);

                    sharedState.setFinalOrderLineCounter(result_Order.size());
                    log.info("Result {}", result_Order.size());

                } else {
                    log.info("File not found :{}", filePath);
                    // System.exit(0);
                    errorOccurred = true;
                    Exception e = new Exception("File Not Found" + filePath);
               //     sendErrorEmail(e);
                    log.debug("FILE NOT FOUND. SO APP GOING TO STOP");
                    System.exit(1);
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                errorOccurred = true;
              //  sendErrorEmail(e);
                log.debug("ORDER FILE COULD NOT READ. SO APP GOING TO STOP");
                System.exit(1);
            }


        } catch (Exception e) {
            log.error(e.getMessage());
            errorOccurred = true;
          //  sendErrorEmail(e);
            log.debug(" ANY FILE COULD NOT READ. SO APP GOING TO STOP");
            System.exit(1);
            //  return ResponseEntity.internalServerError().build();

        }
    }

    public  boolean onAllThredaComplted() {
        LocalDate tradeDate = LocalDate.parse(datePart, formatter);
        log.info("All thread completed. Data going to update in DB");
        boolean status = false;

        log.info("Makesure to validate all orders are processed : sharedState.getTotalOrderProcessedCount :{}, sharedState.getTotalUnMatchedCount :{}, sharedState.getOutOfMarketTimeOrderOrderCount :{}, sharedState.getFinalOrderLineCounter :{}", sharedState.getTotalOrderProcessedCount(),sharedState.getTotalUnMatchedCount(), sharedState.getOutOfMarketTimeOrderOrderCount(),sharedState.getFinalOrderLineCounter());

       if( (sharedState.getTotalOrderProcessedCount() + sharedState.getTotalUnMatchedCount() +  sharedState.getOutOfMarketTimeOrderOrderCount()) == sharedState.getFinalOrderLineCounter()) {
           // 3. Enumerate and loop through only this group's active threads
           Thread[] marketMakingThreads = new Thread[MMUniqueThread.marketMakingThreadGroup.activeCount()];
           int actualThreadCount = MMUniqueThread.marketMakingThreadGroup.enumerate(marketMakingThreads);
           log.info("Total Thread Count :"+actualThreadCount);
           for (int i = 0; i < actualThreadCount; i++) {
            log.info("Thread Status : Thread Name :{}, Thread Status :{}",marketMakingThreads[i].getName(),marketMakingThreads[i].getState());

           }


           List<ReportforMMIDSymbolDto> reports = mmUniqueThread.getReports();

           List<ReportforStarttimeEndTimeDto> intervalReports = mmUniqueThread.getIntervalReports();

           List<ReportForMMIDDto> mmidReports = OverallEligiblityCheck.calculateOverallEligibility(reports);

           List<ReportforMMIDSymbolSecondReportDto> Secondreport = mmUniqueThread.getReportsForSecondReport();

           List<ReportforMMIDSymbolThirdReportDto> Thirdreportdata = mmUniqueThread.getThirdReport(Secondreport);

           status = true;

         //  savingDataToDB.saveReports(reports, tradeDate);
         //  savingDataToDB.saveSecondReports(Secondreport, tradeDate);
         //  savingDataToDB.saveThirdReport(Thirdreportdata, tradeDate);

           String monthYear = tradeDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
         //  savingDataToDB.aggregateAndSaveMonthlyReport(monthYear);

           //*****Report for Unique MMId and symbol and Eligible flag

           ExcelReportGenerator.generateReportForMMIDSymbol(reports, reportFilePath + dailyEligibilityReport + "_" + tradeDate + ".xlsx");


           ExcelReportGenerator.generateIntervalReport(
                   intervalReports,
                   reportFilePath + dailyPerformanceReport + "_" + tradeDate + ".xlsx"
           );


           ExcelReportGenerator.generateOverallEligibilityReport(mmidReports, reportFilePath + dailyEligibilityStatusMMLevelReport + "_" + tradeDate + ".xlsx");


           ExcelReportGenerator.generateReportForMMIDSymbolSecondReport(Secondreport, reportFilePath + secondReport + "_" + tradeDate + ".xlsx", tradeDate);

           ExcelReportGenerator.generateEligibilitySummaryReport(Thirdreportdata, reportFilePath + ThirdReport + "_" + tradeDate + ".xlsx", tradeDate);

           ExcelReportGenerator.generateStreakReport(mmUniqueThread.getStreaks(), reportFilePath + streaksReport + "_" + tradeDate + ".xlsx", tradeDate);

           ExcelReportGenerator.generateAuditReport(mmUniqueThread.getAudits(), reportFilePath + auditReport + "_" + tradeDate + ".xlsx", tradeDate);


           try {

               List<MMTimeConfigDto> timeConfigs = marketMakerService.processExcelTime(mmTimeConfigFile);
               if (timeConfigs == null || timeConfigs.isEmpty()) {
                   log.warn("No TimeConfig data found — skipping monthly report check.");
                   return true;
               }

               MMTimeConfigDto config = timeConfigs.get(0); // assuming single time config
               List<String> holidays = (config.getHolidays() != null)
                       ? Arrays.asList(config.getHolidays())
                       : List.of();

               //  LocalDate today = LocalDate.now();
               LocalDate lastBusinessDay = getLastBusinessDayOfMonth(holidays, tradeDate);

               log.info("Today: {} | Last business day: {}", tradeDate, lastBusinessDay);

               if (tradeDate.equals(lastBusinessDay)) {
                   String monthArg = tradeDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
                   log.info("Today is last business day of month — generating monthly report for {}", monthArg);
                   // generateMonthlyReport(monthArg);

                   excelReportGenerator.generateExcelReport(reportFilePath + monthlyReport + "_" + dateFormat + ".xlsx", monthYear);


                   // File paths for reports
                   String report2 = reportFilePath + dailyEligibilityReport + "_" + tradeDate + ".xlsx";
                   String report4 = reportFilePath + secondReport + "_" + tradeDate + ".xlsx";
                   String report5 = reportFilePath + ThirdReport + "_" + tradeDate + ".xlsx";
                   String report6 = reportFilePath + monthlyReport + "_" + monthArg + ".xlsx";
                   try {
                       //Send in one email
                       if (!"LOCAL".equalsIgnoreCase(environment))
                           emailService.sendReports(
                                   emailFrom,
                                   config.getBusinessEmail(),
                                   "Derivative Market makers Reports" + "_" + datePart + "_" + environment,
                                   "Dear Team,\n\nPlease find attached the generated reports.\n\nRegards,\nMarketMaker System",
                                   report2, report4, report5, report6
                           );
                   } catch (Exception e) {
                       throw new RuntimeException(e);

                   }


               } else {
                   // File paths for reports

                   String report2 = reportFilePath + dailyEligibilityReport + "_" + tradeDate + ".xlsx";
                   String report4 = reportFilePath + secondReport + "_" + tradeDate + ".xlsx";
                   String report5 = reportFilePath + ThirdReport + "_" + tradeDate + ".xlsx";

                   try {
                       //Send in one email
                       if (!"LOCAL".equalsIgnoreCase(environment))
                           emailService.sendReports(
                                   emailFrom,
                                   config.getBusinessEmail(),
                                   "Derivative Market makers Reports" + "_" + datePart + "_" + environment,
                                   "Dear Team,\n\nPlease find attached the generated reports.\n\nRegards,\nMarketMaker System",
                                   report2, report4, report5
                           );
                   } catch (Exception e) {
                       throw new RuntimeException(e);
                   }
                   log.info("Today is not the last business day — skipping monthly report generation.");
               }


           } catch (Exception e) {
               log.error("Error checking last business day: {}", e.getMessage(), e);
               log.info("Error checking last business day. SO APP GOING TO STOP");
               System.exit(1);
               if (!"LOCAL".equalsIgnoreCase(environment))
                   sendErrorEmail(e);
           }
       }
       return status;
    }


    private void sendErrorEmail(Exception e) {
        if(!"LOCAL".equalsIgnoreCase(environment))
            emailService.sendEmail(
                    emailFrom,
                    emailToTechnical,
                    "Derivative Market makers monitoring system" + "_" + datePart + "_" + environment,
                    "Dear Team,\n\nAn error occurred in application.Kindly Check it. Error:\n\n " + e.getMessage() + "\n\nRegards,\nMarketMaker System"

            );
    }


    public void generateMonthlyReport(String monthArg) {

        String formattedYear = monthArg.substring(0, 4) + "-" + monthArg.substring(4, 6);

        try {
            log.info("Starting Monthly Report Generation for month: {}", monthArg);
            List<MMTimeConfigDto> timeConfigs = marketMakerService.processExcelTime(mmTimeConfigFile);
            if (timeConfigs == null || timeConfigs.isEmpty()) {
                log.warn("No TimeConfig data found in MM time config file — skipping monthly report check.");
                return;
            }

            MMTimeConfigDto config = timeConfigs.get(0);
            // Call the method that aggregates and saves the monthly report
        //    savingDataToDB.aggregateAndSaveMonthlyReport(formattedYear);

            // Create Excel report for the monthly data
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
            String dateFormat = LocalDate.now().format(formatter);

            excelReportGenerator.generateExcelReport(reportFilePath + monthlyReport + "_" + monthArg + ".xlsx", formattedYear);

            // Send email with monthly report
            String reportPath = reportFilePath + monthlyReport + "_" + monthArg + ".xlsx";

            if(!"LOCAL".equalsIgnoreCase(environment))
                emailService.sendReports(
                        emailFrom,
                        config.getBusinessEmail(),
                        "Monthly Derivative Market Maker Report - " + monthArg + "_" + environment,
                        "Dear Team,\n\nPlease find attached the Monthly Market Maker report for " + monthArg + ".\n\nRegards,\nMarketMaker System",
                        reportPath
                );

            log.info("Monthly report generated and email sent successfully for {}", monthArg);
        } catch (Exception e) {
            log.error("Error during monthly report generation: {}", e.getMessage(), e);
           // sendErrorEmail(e);
            log.error("Error during monthly report generation, SO APP GOING TO STOP");
            System.exit(1);
        }
    }


    private LocalDate getLastBusinessDayOfMonth(List<String> holidays, LocalDate tradeDate) {
        LocalDate lastDay = tradeDate.withDayOfMonth(tradeDate.lengthOfMonth());

        while (isHolidayOrWeekend(lastDay, holidays)) {
            lastDay = lastDay.minusDays(1);
        }
        return lastDay;
    }

    private boolean isHolidayOrWeekend(LocalDate date, List<String> holidays) {
        DayOfWeek day = date.getDayOfWeek();
        // Saudi weekends: Friday & Saturday
        if (day == DayOfWeek.FRIDAY || day == DayOfWeek.SATURDAY) {
            return true;
        }


        // Holidays from Excel come as: DD/MM/YYYY
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");

        for (String h : holidays) {
            LocalDate holidayDate = LocalDate.parse(h, formatter);
            if (holidayDate.equals(date)) {
                return true;
            }
        }

        // Compare with holiday list (format: yyyy-MM-dd)
        // return holidays.contains(date.toString());
        return false;
    }


}