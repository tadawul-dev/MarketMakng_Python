package com.muqassa.marketmaking.util;

import com.muqassa.marketmaking.dto.*;
import com.muqassa.marketmaking.entity.MonthlyReportEntity;
import com.muqassa.marketmaking.enums.MarketType;
import com.muqassa.marketmaking.process.ProcessingThread;
import com.muqassa.marketmaking.repository.MonthlyReportRepository;
import com.muqassa.marketmaking.thread.MMUniqueThread;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
@Component
@RequiredArgsConstructor
public class ExcelReportGenerator {
    //private final MonthlyReportRepository monthlyReportRepository;
    @Autowired
    private MonthlyReportRepository monthlyReportRepository;
    private static final Logger log = LoggerFactory.getLogger(ExcelReportGenerator.class);

    public static void generateIntervalReport(List<ReportforStarttimeEndTimeDto> reports, String filePath) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Intervals Report");

            // Header
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("MMID");
            header.createCell(1).setCellValue("Symbol");

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm:ss");

            int rowNum = 1;
            int maxColumns = 2;
            for (ReportforStarttimeEndTimeDto dto : reports) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(dto.getMmid());
                row.createCell(1).setCellValue(dto.getSymbol());

                int intervalCols = dto.getIntervals().size() * 2; // each interval has start and end
                maxColumns = Math.max(maxColumns, 2 + intervalCols);
                int col = 2;

                for (ReportforStarttimeEndTimeDto.Interval interval : dto.getIntervals()) {
                    row.createCell(col++).setCellValue("starttime:" + interval.getStart().format(fmt));
                    row.createCell(col++).setCellValue("endtime:" + interval.getEnd().format(fmt));
                }
            }



            for (int i = 0; i < maxColumns; i++) {
                int maxWidth = 0;
                for (int j = 0; j < maxColumns; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 2) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }



            // Autosize first N columns (adjust if you expect many intervals)
           // for (int i = 0; i < 100; i++) {
                //sheet.autoSizeColumn(i);
            //   sheet.setColumnWidth(i, 20 * 256);
          //  }

            try (FileOutputStream out = new FileOutputStream(filePath)) {
                workbook.write(out);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void generateStreakReport(List<ProcessingThread.StreakRow> rows, String filePath, LocalDate tradeDate) {
        List<ProcessingThread.StreakRow> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparing(ProcessingThread.StreakRow::mmid)
                .thenComparing(ProcessingThread.StreakRow::contractCode)
                .thenComparingInt(row -> streakOrder(row.metric()))
                .thenComparing(ProcessingThread.StreakRow::start));
        DateTimeFormatter clock = DateTimeFormatter.ofPattern("HH:mm:ss");
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Streaks");
            Row header = sheet.createRow(0);
            String[] titles = {"Date", "MM", "Contract", "Symbol", "Metric", "Start", "End", "Duration (seconds)"};
            for (int i = 0; i < titles.length; i++) {
                header.createCell(i).setCellValue(titles[i]);
            }
            int rowNum = 1;
            for (ProcessingThread.StreakRow row : sorted) {
                Row excel = sheet.createRow(rowNum++);
                excel.createCell(0).setCellValue(tradeDate.toString());
                excel.createCell(1).setCellValue(row.mmid());
                excel.createCell(2).setCellValue(row.contractCode());
                excel.createCell(3).setCellValue(row.symbolName());
                excel.createCell(4).setCellValue(row.metric());
                excel.createCell(5).setCellValue(row.start().format(clock));
                excel.createCell(6).setCellValue(row.end().format(clock));
                excel.createCell(7).setCellValue(row.duration());
            }
            try (FileOutputStream out = new FileOutputStream(filePath)) {
                workbook.write(out);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void generateAuditReport(List<ProcessingThread.AuditRow> rows, String filePath, LocalDate tradeDate) {
        List<ProcessingThread.AuditRow> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparing(ProcessingThread.AuditRow::mmid)
                .thenComparing(ProcessingThread.AuditRow::contractCode)
                .thenComparing(ProcessingThread.AuditRow::from)
                .thenComparingInt(row -> "Spread".equals(row.obligation()) ? 0 : 1));
        DateTimeFormatter clock = DateTimeFormatter.ofPattern("HH:mm:ss");
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Audit Trail");
            Row header = sheet.createRow(0);
            String[] titles = {"Date", "MM", "Contract", "Obligation", "From", "To", "Seconds not met", "Reason"};
            for (int i = 0; i < titles.length; i++) {
                header.createCell(i).setCellValue(titles[i]);
            }
            int rowNum = 1;
            for (ProcessingThread.AuditRow row : sorted) {
                Row excel = sheet.createRow(rowNum++);
                excel.createCell(0).setCellValue(tradeDate.toString());
                excel.createCell(1).setCellValue(row.mmid());
                excel.createCell(2).setCellValue(row.contractCode());
                excel.createCell(3).setCellValue(row.obligation());
                excel.createCell(4).setCellValue(row.from().format(clock));
                excel.createCell(5).setCellValue(row.to().format(clock));
                excel.createCell(6).setCellValue(row.seconds());
                excel.createCell(7).setCellValue(row.reason());
            }
            try (FileOutputStream out = new FileOutputStream(filePath)) {
                workbook.write(out);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int streakOrder(String metric) {
        return switch (metric) {
            case "Spread" -> 0;
            case "Depth" -> 1;
            default -> 2;
        };
    }

    public static void generateReportForMMIDSymbol(List<ReportforMMIDSymbolDto> reports, String filePath) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Final Report");
            int rowNum = 0;

            // Group reports by MarketType
            Map<MarketType, List<ReportforMMIDSymbolDto>> grouped =
                    reports.stream().collect(Collectors.groupingBy(ReportforMMIDSymbolDto::getMarketType));






           // for (MarketType type : MarketType.values()) {
            //    List<ReportforMMIDSymbolDto> list = grouped.get(type);
             //   if (list == null || list.isEmpty()) continue;

                // Section title
             //   Row sectionRow = sheet.createRow(rowNum++);
             //   sectionRow.createCell(0).setCellValue(getSectionTitle(type));

                // Header
                Row header = sheet.createRow(rowNum++);
                header.createCell(0).setCellValue("MMID");
                header.createCell(1).setCellValue("Market Maker");
                header.createCell(2).setCellValue("Contract");
                header.createCell(3).setCellValue("Symbol");
                header.createCell(4).setCellValue("Type");
                header.createCell(5).setCellValue("Total Spread presence time in Seconds");
                header.createCell(6).setCellValue("Total OrderBook presence time in Seconds");
                header.createCell(7).setCellValue("Total presence time in Seconds");
                header.createCell(8).setCellValue("Total presence time in Percentage");
                header.createCell(9).setCellValue("Total Volume Traded");
               // header.createCell(10).setCellValue("EligibleFlag");



                for (MarketType type : MarketType.values()) {
                    List<ReportforMMIDSymbolDto> list = grouped.get(type);
                    if (list == null || list.isEmpty()) continue;
                    // Data
                for (ReportforMMIDSymbolDto dto : list) {
                    Row row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(dto.getMmid());
                    row.createCell(1).setCellValue(dto.getMarketMakerName());
                    row.createCell(2).setCellValue(dto.getSymbol());
                    row.createCell(3).setCellValue(dto.getContract());
                    row.createCell(4).setCellValue(dto.getMarketType().toString());
                    row.createCell(5).setCellValue(dto.getActiveSpreadVarianceTime());
                    row.createCell(6).setCellValue(dto.getActiveQuantityVarianceTime());
                    row.createCell(7).setCellValue(dto.getActiveSpreadQuantityVarianceTime());
                    row.createCell(8).setCellValue(dto.getPercentOfTotalActiveSpreadQuantityVarianceTime());
                    row.createCell(9).setCellValue(dto.getTotalVolumeTraded());
                 //   row.createCell(10).setCellValue(dto.isEligibleFlag() ? "YES" : "NO");
                }

            //    rowNum++; // blank line after section
            }



            for (int i = 0; i < 3; i++) {
                int maxWidth = 0;
                for (int j = 0; j < 3; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 2) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }


            // Autosize
          //  for (int i = 0; i < 3; i++) {
               // sheet.autoSizeColumn(i);
              //  sheet.setColumnWidth(i, 20 * 256);
          //  }

            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getSectionTitle(MarketType type) {
        switch (type) {
            case SSF: return "Single Stock Futures";
            case SSO: return "Single Stock Options";
            case IF:  return "Index Futures";
            default: return type.name();
        }
    }



    public static void generateOverallEligibilityReport(List<ReportForMMIDDto> reports, String filePath) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Overall Eligibility");

            int rowNum = 0;

            // Group by MarketType
            Map<MarketType, List<ReportForMMIDDto>> grouped =
                    reports.stream().collect(Collectors.groupingBy(ReportForMMIDDto::getMarketType));

            for (MarketType type : MarketType.values()) {
                List<ReportForMMIDDto> list = grouped.get(type);
                if (list == null || list.isEmpty()) continue;

                // Section Title
                Row sectionRow = sheet.createRow(rowNum++);
                sectionRow.createCell(0).setCellValue(getSectionTitle(type));

                // Header
                Row header = sheet.createRow(rowNum++);
                header.createCell(0).setCellValue("MMID");
                header.createCell(1).setCellValue("Market Maker");
                header.createCell(2).setCellValue("Eligibility");

                // Data
                for (ReportForMMIDDto dto : list) {
                    Row row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(dto.getMmid());
                    row.createCell(1).setCellValue(dto.isOverallEligible() ? "YES" : "NO");
                }

                rowNum++; // blank line
            }


            for (int i = 0; i < 2; i++) {
                int maxWidth = 0;
                for (int j = 0; j < 2; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 2) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }


          //  for (int i = 0; i < 2; i++) {
                //sheet.autoSizeColumn(i);
            //   sheet.setColumnWidth(i, 20 * 256);
          //  }

            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void generateReportForMMIDSymbolSecondReport(List<ReportforMMIDSymbolSecondReportDto> reports, String filePath, LocalDate tradeDate) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Daily Summary Report-"+tradeDate);
            int rowNum = 0;

            // Add Report title
           // Row titleRow = sheet.createRow(rowNum++);
           // Cell titleCell = titleRow.createCell(0);
          //  titleCell.setCellValue("Derivatives Daily Summary Report - "+tradeDate);

            //Merge cells for the title
          //  sheet.addMergedRegion(new CellRangeAddress(0,0,0,8));


            // Group reports by MarketType
            Map<MarketType, List<ReportforMMIDSymbolSecondReportDto>> grouped =
                    reports.stream().collect(Collectors.groupingBy(ReportforMMIDSymbolSecondReportDto::getMarketType));





            // Header
            Row header = sheet.createRow(rowNum++);
            header.createCell(0).setCellValue("MMID");
            header.createCell(1).setCellValue("Market Maker");
            header.createCell(2).setCellValue("Contract");
            header.createCell(3).setCellValue("Symbol");
            header.createCell(4).setCellValue("Type");
            header.createCell(5).setCellValue("Total Spread presence time in Seconds");
            header.createCell(6).setCellValue("Total OrderBook presence time in Seconds");
            header.createCell(7).setCellValue("Total presence time in Seconds");
            header.createCell(8).setCellValue("Total presence time in Percentage");
            header.createCell(9).setCellValue("Total Volume Traded");
            header.createCell(10).setCellValue("EligibleFlag");



            for (MarketType type : MarketType.values()) {
               List<ReportforMMIDSymbolSecondReportDto> list = grouped.get(type);
              if (list == null || list.isEmpty()) continue;
                System.out.println(list);
                System.out.println(grouped);
            // Section title
            //  Row sectionRow = sheet.createRow(rowNum++);
             //  sectionRow.createCell(0).setCellValue("Table"+(type.ordinal())+": "+type.name().replace("_"," "));





               //Group By MMID

       Map<String,List<ReportforMMIDSymbolSecondReportDto>> groupedByMMID=
                                   list.stream().collect(Collectors.groupingBy(ReportforMMIDSymbolSecondReportDto::getMmid));
                for(Map.Entry<String,List<ReportforMMIDSymbolSecondReportDto>> mmidEntry : groupedByMMID.entrySet()) {
                    String mmid = mmidEntry.getKey();
                    List<ReportforMMIDSymbolSecondReportDto> mmidList = mmidEntry.getValue();


                    for (ReportforMMIDSymbolSecondReportDto dto : mmidList) {
                        Row row = sheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(dto.getMmid());
                        row.createCell(1).setCellValue(dto.getMarketMakerName());
                        row.createCell(2).setCellValue(dto.getSymbol());
                        row.createCell(3).setCellValue(dto.getContract());
                        row.createCell(4).setCellValue(dto.getMarketType().toString());
                        row.createCell(5).setCellValue(dto.getActiveSpreadVarianceTime());
                        row.createCell(6).setCellValue(dto.getActiveQuantityVarianceTime());
                        row.createCell(7).setCellValue(dto.getActiveSpreadQuantityVarianceTime());
                        row.createCell(8).setCellValue(dto.getPercentOfTotalActiveSpreadQuantityVarianceTime());
                        row.createCell(9).setCellValue(dto.getTotalVolumeTraded());
                        row.createCell(10).setCellValue(dto.isEligibleFlag() ? "YES" : "NO");
                    }

                   // rowNum++; // blank line after section

                }
               // rowNum++;
            }

            for (int i = 0; i < 3; i++) {
                int maxWidth = 0;
                for (int j = 0; j < 3; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 2) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }

            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void generateEligibilitySummaryReport(
            List<ReportforMMIDSymbolThirdReportDto> reports,
            String filePath,
            LocalDate tradeDate) {

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("DailyEligibleReport-" + tradeDate);
            int rowNum = 0;

            // === Report Title ===
          //  Row titleRow = sheet.createRow(rowNum++);
         //   Cell titleCell = titleRow.createCell(0);
          //  titleCell.setCellValue("Derivatives Daily Summary Report - " + tradeDate);
          //  sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 2)); // merge for 3 columns

            // Blank line
          //  rowNum++;

            // === SSF Section ===
           // Row ssfTitle = sheet.createRow(rowNum++);
           // ssfTitle.createCell(0).setCellValue("Table 1: SSF Summary");

            // Header
            Row ssfHeader = sheet.createRow(rowNum++);
            ssfHeader.createCell(0).setCellValue("MMID");
            ssfHeader.createCell(1).setCellValue("Market Maker");
            ssfHeader.createCell(2).setCellValue("Type");
            ssfHeader.createCell(3).setCellValue("EligibilityStatus");

            // Filter SSF records
            List<ReportforMMIDSymbolThirdReportDto> ssfReports = reports.stream()
                    .filter(r -> "SSF".equalsIgnoreCase(r.getMarketType().toString()))
                    .toList();

            for (ReportforMMIDSymbolThirdReportDto dto : ssfReports) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(dto.getMmid());
                row.createCell(1).setCellValue(dto.getMarketMakerName());
                row.createCell(2).setCellValue(dto.getMarketType().toString());
                row.createCell(3).setCellValue(dto.isEligibleFlag() ? "YES" : "NO");
            }

            // Blank line
           // rowNum++;

            // === IF Section ===
          //  Row ifTitle = sheet.createRow(rowNum++);
           // ifTitle.createCell(0).setCellValue("Table 2: IF Summary");

            // Header
          //  Row ifHeader = sheet.createRow(rowNum++);
           // ifHeader.createCell(0).setCellValue("MMID");
          //  ifHeader.createCell(1).setCellValue("Type");
         //   ifHeader.createCell(2).setCellValue("EligibilityStatus");

            // Filter IF records
            List<ReportforMMIDSymbolThirdReportDto> ifReports = reports.stream()
                    .filter(r -> "IF".equalsIgnoreCase(String.valueOf(r.getMarketType())))
                    .toList();

            for (ReportforMMIDSymbolThirdReportDto dto : ifReports) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(dto.getMmid());
                row.createCell(1).setCellValue(dto.getMarketMakerName());
                row.createCell(2).setCellValue(dto.getMarketType().toString());
                row.createCell(3).setCellValue(dto.isEligibleFlag() ? "YES" : "NO");
            }



            for (int i = 0; i < 3; i++) {
                int maxWidth = 0;
                for (int j = 0; j < 3; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 5) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }



            // === Auto-size columns ===
          //  for (int i = 0; i < 3; i++) {
             //   sheet.autoSizeColumn(i);
         //   }

            // === Save workbook ===
            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }

            System.out.println("Eligibility Summary Report generated at: " + filePath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void generateExcelReport(String filePath,String monthYear) throws IOException {
        //List<MonthlyReportEntity> reports = monthlyReportRepository.findAll();
         List<MonthlyReportEntity> reports = monthlyReportRepository.findByMonthYear(monthYear);
         System.out.println(reports);
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("MM Eligibility Report");
            int rowNum = 0;

            // === Title ===
            Row titleRow = sheet.createRow(rowNum++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Derivatives Market Maker Monthly Eligibility Status Report for" + monthYear);

            CellStyle titleStyle = workbook.createCellStyle();
            Font titleFont = workbook.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 14);
            titleStyle.setFont(titleFont);
            titleCell.setCellStyle(titleStyle);

            // Merge title across columns
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 7));

            // === Headers ===
            Row headerRow = sheet.createRow(rowNum++);
            String[] headers = {
                     "Month-Year", "MMID", "Market Maker",
                    "Market Type", "Actual Trading Days", "Eligible Days", "Compliance Rate (%)"
            };

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderTop(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // === Data ===
            CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderBottom(BorderStyle.THIN);
            dataStyle.setBorderTop(BorderStyle.THIN);
            dataStyle.setBorderLeft(BorderStyle.THIN);
            dataStyle.setBorderRight(BorderStyle.THIN);

            for (MonthlyReportEntity report : reports) {
                Row row = sheet.createRow(rowNum++);
              //  row.createCell(0).setCellValue(report.getTradeDate().toString());
                row.createCell(0).setCellValue(report.getMonthYear());
                row.createCell(1).setCellValue(report.getMmid());
                row.createCell(2).setCellValue(report.getMarketMakerName());
               // row.createCell(3).setCellValue(report.getContract());
                row.createCell(3).setCellValue(report.getMarketType());
                row.createCell(4).setCellValue(report.getActualTradingDays());
                row.createCell(5).setCellValue(report.getEligibleDays());
                row.createCell(6).setCellValue(report.getComplianceRate());
            }



            for (int i = 0; i < headers.length; i++) {
                int maxWidth = 0;
                for (int j = 0; j < headers.length; j++) {
                    Row row = sheet.getRow(j);
                    if (row != null) {
                        Cell cell = row.getCell(i);
                        if (cell != null) {
                            int length = cell.toString().length();
                            maxWidth = Math.max(maxWidth, length);
                        }
                    }
                }
                int width = (maxWidth + 2) * 256; // Adding buffer for padding
                sheet.setColumnWidth(i, width);
            }


          //  for (int i = 0; i < headers.length; i++) {
             //   sheet.autoSizeColumn(i);
          //  }

            try (FileOutputStream out = new FileOutputStream(filePath)) {
                workbook.write(out);
            }

           log.info("Excel report generated at: " + filePath);
        }
    }
}









