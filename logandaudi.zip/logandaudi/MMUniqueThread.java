package com.muqassa.marketmaking.thread;

import com.muqassa.marketmaking.dto.*;
import com.muqassa.marketmaking.enums.MarketType;

import com.muqassa.marketmaking.job.MarketMakerJob;
import com.muqassa.marketmaking.process.ProcessingThread;
import com.muqassa.marketmaking.shared.SharedState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
public class MMUniqueThread implements ThreadCompleteListener {

    @Autowired
    private SharedState sharedState;

    @Value("${marketmaker.is.overnight.session.included}")
    private boolean isOvernightSessionIncluded;
    private static final Logger log = LoggerFactory.getLogger(MMUniqueThread.class);

    private Set<String> unmatchedOrder = new HashSet<>();
    private int unmatchedOrderCount = 0;
    private Set<String> matchedOrder = new HashSet<>();
    private final int unmatchedConfigData = 0;
    private final Map<String, ProcessingThread> workerMap = new ConcurrentHashMap<>();
    private final Map<String, Thread> workerMap_threa = new ConcurrentHashMap<>();
    private final List<String> workersTh = new ArrayList<>();
    private final Set<String> completeThreads = ConcurrentHashMap.newKeySet();
    private MarketMakerJob job;
    public static ThreadGroup marketMakingThreadGroup = new ThreadGroup("MarketMakingThreadGroup");


    public void setMarketMakerJob(MarketMakerJob job) {
        this.job = job;
    }

    @Override
    public synchronized void onThreadComplete(String key) {
        completeThreads.add(key);
        log.info("Thread " + key + " has been completed");
        log.info("Thread " + completeThreads.size() + " has been completed" + workerMap.size());

        int waitingThread = 0;
        int terminatedThread = 0;
        for (String key1 : workersTh) {
            Thread thread = workerMap_threa.get(key1);
            if (thread.getState() == Thread.State.TERMINATED) {
                terminatedThread += 1;
            } else if (thread.getState() == Thread.State.WAITING) {
                waitingThread += 1;
            }
            log.info("Thread state {}-{}", thread.getState(), thread.getName());

        }
        log.info("Thread waiting {}, thread completed {}", waitingThread, completeThreads.size());

        int totalProcessedThread = 0;
       // totalProcessedThread = sharedState.getQueueTakeCount() + unmatchedOrderCount;
        totalProcessedThread = sharedState.getQueueTakeCount() ;

        log.info("Total processed order{} , orderfilecount {}, unmatchedOrderCount {} OutOfMarketTimeOrder {} ",totalProcessedThread,sharedState.getOrderFileLineCount(), unmatchedOrderCount, sharedState.getOutOfMarketTimeOrderOrderCount());


        int totalThread = waitingThread + completeThreads.size();
        log.info("completeThreads.size() {}",completeThreads.size());
        log.info("totalThread {} ",totalThread);
        log.info("workerMap.size() {}",workerMap.size());
        log.info("sharedState.getFileCompleted() ==1 {}",sharedState.getFileCompleted());
        log.info("totalProcessedThread {}",totalProcessedThread);
        log.info("totalUnMatchedOrer {}",unmatchedOrderCount);
        log.info("totalOutOFMarketTimeOrders {}",sharedState.getOutOfMarketTimeOrderOrderCount());
        log.info("orderFileCount {}",sharedState.getFinalOrderLineCounter());


        if (  ((completeThreads.size() == workerMap.size() && sharedState.getFileCompleted() ==1 ) || (totalThread == workerMap.size() && sharedState.getFileCompleted() ==1) )  &&  ((totalProcessedThread + unmatchedOrderCount + sharedState.getOutOfMarketTimeOrderOrderCount() ) == sharedState.getFinalOrderLineCounter())  ) {

            if (job != null) {
               boolean status = job.onAllThredaComplted();
               if(status) {
                   log.info("Thread processed application going to stop");
                   System.exit(1);
               }else {
                   log.info("Still some order processing is pending. Hence the program will wait");
               }
            }
        }
    }


    //*** Create and Start Thread as per unique MM_ID and symbol
    public void startWorkers(List<MarketMakerDto> MarketMakerList, List<MMTimeConfigDto> MMTimeConfigList) {

        int threadStart = 0;
        for (MarketMakerDto marketMaker : MarketMakerList) {
            String mmId = marketMaker.getMarketMakerId();
            String marketMakerCompanyName = marketMaker.getMarketMakerName();

            String symbol = marketMaker.getSymbol();
            String contract = marketMaker.getContract();
            Boolean isRolloutConfig = marketMaker.getIsRolloutConfig();
            MarketType marketType = marketMaker.getMarketType();
            Integer spreadInTicks = marketMaker.getSpreadInTicks();
            Double tickSize = marketMaker.getTickSize();
            String QtyAtEachPriceLevel = marketMaker.getQtyAtEachPriceLevel();
            String key = mmId + "-" + symbol;
            Map<String, Integer> buyLevels = marketMaker.getBellLevels();
            Map<String, Integer> sellLevels = marketMaker.getSellLevels();
            Integer qtyTickSize = marketMaker.getQtyTickSize();
            Long configuredVolumePerDay = marketMaker.getVolumePerDay();
            Double configuredPresenceTimeSeconds = marketMaker.getPresenceTime();

            //sending the unique MMid and symbol to the correct thread
            ProcessingThread worker = new ProcessingThread(mmId, marketMakerCompanyName, symbol, contract, isRolloutConfig, marketType, spreadInTicks, tickSize, QtyAtEachPriceLevel, buyLevels, sellLevels, qtyTickSize, configuredVolumePerDay, configuredPresenceTimeSeconds, MMTimeConfigList,sharedState, isOvernightSessionIncluded, this);
            workerMap.put(key, worker);

            Thread thread = new Thread(marketMakingThreadGroup,worker, key);

            workerMap_threa.put(key, thread);
            workersTh.add(key);

            log.info("Thread has been started -{}", key);
            thread.start();
            threadStart = threadStart+1; // Starts thread
        }

        log.info("{} Thread started ", threadStart);
    }


    //5/8 Dispatch order to correct thread
    public void dispatchOrder(OrderFileDto orderFileDto, int fileCompleted) {
        if (null == orderFileDto && fileCompleted == 1) {
            log.info("Order is null and order file reading has been completed");

            if (matchedOrder.isEmpty() ) {
                log.warn("No matching orders found for any Market Maker. Shutting down application immediately.");
                processExit();
            }

        }
        log.info("************* ORDER FILE is not NULL. continue for processing **************");
        if(null != orderFileDto) {
        //Sending to unique Thread
        String key = orderFileDto.getThisRealTraderId() + "-" + orderFileDto.getSymbolCode();
        ProcessingThread worker = workerMap.get(key);


        log.debug("matched Size: {}", matchedOrder.size());
        log.debug("WorkerMap Order Size {}", workerMap.size());
        log.debug("sharedState {}", sharedState.getFileCompleted());


        if (worker != null) {

            matchedOrder.add(key);
            worker.addOrder(orderFileDto);  //***Sending to Queue

        } else {

            unmatchedOrder.add(key);
            unmatchedOrderCount = unmatchedOrderCount+1;
            sharedState.incrementTotalUnMatchedCount();
            log.info("unmatchedOrderCount {}", orderFileDto);
        }

        if (matchedOrder.isEmpty() && fileCompleted == 1) {

            log.info("matched Size: {}", matchedOrder.size());
            log.info("WorkerMap Order Size {}", workerMap.size());
            log.info("sharedState {}", sharedState.getFileCompleted());
            processExit();
        }
    }

    }

    private void processExit() {
        log.info("Calling Process Exit");
        boolean status = job.onAllThredaComplted();
        if(status) {
            log.debug("Application going to be  stopped");
            System.exit(0);
            log.debug("Application already SHOULD STOP");
            System.exit(1);
            log.info("Application STILL RUNNING");
        }else {
            log.info("Still some order processing is pending. Hence the program will wait");
        }



    }


    public List<ReportforMMIDSymbolDto> getReports() {
        return workerMap.values().stream().map(ProcessingThread::getReport).toList();
    }


    public List<ReportforMMIDSymbolSecondReportDto> getReportsForSecondReport() {

        // Step 1: Collect all reports
        List<ReportforMMIDSymbolSecondReportDto> allReports = workerMap.values().stream().map(ProcessingThread::getReportForSecondReport).toList();

        // Step 2: Group by (MMID + Contract)
        Map<String, List<ReportforMMIDSymbolSecondReportDto>> groupedReports = allReports.stream().collect(Collectors.groupingBy(r -> r.getMmid() + "-" + r.getContract()));


        List<ReportforMMIDSymbolSecondReportDto> finalReports = new ArrayList<>();

        // Step 3: Merge logic
        for (Map.Entry<String, List<ReportforMMIDSymbolSecondReportDto>> entry : groupedReports.entrySet()) {
            List<ReportforMMIDSymbolSecondReportDto> reports = entry.getValue();

            if (reports.size() == 1) {
                finalReports.add(reports.get(0));
                continue;
            }

            // Only consider rollout-config true reports
            List<ReportforMMIDSymbolSecondReportDto> rolloutReports = reports.stream().filter(ReportforMMIDSymbolSecondReportDto::getIsRolloutConfig).toList();

            if (rolloutReports.size() == 2) {
                ReportforMMIDSymbolSecondReportDto r1 = rolloutReports.get(0);
                ReportforMMIDSymbolSecondReportDto r2 = rolloutReports.get(1);

                boolean r1Invalid = isInvalidRollout(r1);
                boolean r2Invalid = isInvalidRollout(r2);

                ReportforMMIDSymbolSecondReportDto valid, invalid;
                if (r1Invalid && !r2Invalid) {
                    valid = r2;
                    invalid = r1;
                } else if (r2Invalid && !r1Invalid) {
                    valid = r1;
                    invalid = r2;
                } else {
                    // Both valid or both invalid → skip merging logic
                    finalReports.addAll(rolloutReports);
                    continue;
                }

                // --- SUM TotalVolumeTraded ---
                long mergedTotalVolume = valid.getTotalVolumeTraded() + invalid.getTotalVolumeTraded();
                valid.setTotalVolumeTraded(mergedTotalVolume);

                // --- Apply Eligibility Logic ---
                if (!valid.isEligibleFlag()) {// need to confirm 30/10/25
                    boolean presenceTrue = valid.getPresenceTimeFlag();
                    boolean volumeFalse = !valid.getTotalFilledVolumeFlag();

                    if (presenceTrue && volumeFalse) {
                        // Compare merged total volume with configuredVolumePerDay of valid row
                        if (mergedTotalVolume >= valid.getConfiguredVolumePerDay()) {
                            valid.setTotalFilledVolumeFlag(true);
                            valid.setEligibleFlag(true);
                        }
                    }
                }

                finalReports.add(valid);
            } else {
                finalReports.addAll(reports);
            }
        }


        System.out.println(finalReports);
        return finalReports;

    }


    private boolean isInvalidRollout(ReportforMMIDSymbolSecondReportDto report) {
        try {
            return report.getTickSize() == 0.0 && report.getSpreadInTicks() == 0 && report.getConfiguredPresenceTime() == 0.0;
            // && isQtyAtEachPriceLevelZero(report);
        } catch (Exception e) {
            return false;
        }
    }

    // --- Helper to check if QtyAtEachPriceLevel is zero ---
    private boolean isQtyAtEachPriceLevelZero(ReportforMMIDSymbolSecondReportDto report) {
        String qty = report.getQtyAtEachPriceLevel();
        if (qty == null || qty.trim().isEmpty()) return true;
        return Arrays.stream(qty.split("\\|")).map(String::trim).allMatch(s -> s.equals("0"));
    }

    public List<ReportforStarttimeEndTimeDto> getIntervalReports() {
        return workerMap.values().stream().map(ProcessingThread::getIntervalReport).toList();
    }

    public List<ProcessingThread.StreakRow> getStreaks() {
        return workerMap.values().stream().flatMap(worker -> worker.getStreaks().stream()).toList();
    }

    public List<ProcessingThread.AuditRow> getAudits() {
        return workerMap.values().stream().flatMap(worker -> worker.getAudits().stream()).toList();
    }


    public List<ReportforMMIDSymbolThirdReportDto> getThirdReport(List<ReportforMMIDSymbolSecondReportDto> allReports) {


        List<ReportforMMIDSymbolThirdReportDto> finalReports = new ArrayList<>();

        // === SSF Section ===
        Map<String, List<ReportforMMIDSymbolSecondReportDto>> ssfGrouped = allReports.stream().filter(r -> r.getMarketType() == MarketType.SSF).collect(Collectors.groupingBy(ReportforMMIDSymbolSecondReportDto::getMmid));
        System.out.println("ssf grouped" + ssfGrouped);
        for (Map.Entry<String, List<ReportforMMIDSymbolSecondReportDto>> entry : ssfGrouped.entrySet()) {
            List<ReportforMMIDSymbolSecondReportDto> ssfList = entry.getValue();
            Boolean eligibilityStatus;
            if (ssfList.size() == 5 && ssfList.stream().allMatch(ReportforMMIDSymbolSecondReportDto::isEligibleFlag)) {
                eligibilityStatus = true;
            } else {
                eligibilityStatus = false;
            }

            ReportforMMIDSymbolSecondReportDto dto = ssfList.get(0);
            ReportforMMIDSymbolThirdReportDto summary = new ReportforMMIDSymbolThirdReportDto();
            summary.setMmid(dto.getMmid());
            summary.setMarketMakerName(dto.getMarketMakerName());
            summary.setContract(dto.getSymbol());
            summary.setMarketType(dto.getMarketType());
            summary.setEligibleFlag(eligibilityStatus);

            finalReports.add(summary);
        }

        // === IF Section ===
        List<ReportforMMIDSymbolSecondReportDto> ifReports = allReports.stream().filter(r -> r.getMarketType() == MarketType.IF).toList();

        for (ReportforMMIDSymbolSecondReportDto dto : ifReports) {
            ReportforMMIDSymbolThirdReportDto summary = new ReportforMMIDSymbolThirdReportDto();
            summary.setMmid(dto.getMmid());
            summary.setMarketMakerName(dto.getMarketMakerName());
            summary.setContract(dto.getSymbol());
            summary.setMarketType(dto.getMarketType());
            summary.setEligibleFlag(dto.isEligibleFlag());

            finalReports.add(summary);
        }

        System.out.println("Third Report Generated: " + finalReports);
        return finalReports;
    }

}

