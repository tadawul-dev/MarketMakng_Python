# TIP Web Listener 2.0: Java 25 migration notes

The listener has been moved from Java 8 (Eclipse project, bundled jars) to **Java 25 LTS** as a Maven project. The work focused on the threading and queueing layer, where most of the waste was. Business logic (parsing rules, VO updates, SQL, BOD/EOD flow) is **unchanged** unless a change is listed below.

## Build & run

```bash
mvn clean package                    # needs JDK 25; target/tip-web-listener-2.0.0.jar + target/lib/
mvn clean package -Djava.release=21  # if your build agents only have JDK 21 for now

bin/run-listener.sh /path/to/efp.ini # see the script for heap/GC flags
```

* `-DLISTENER_INI_FILE` works as before. `log4j2.xml` is now inside the jar, and you can override it with `-Dlog4j2.configurationFile=...`.
* JNI (`libtipclient.so`) needs `--enable-native-access=ALL-UNNAMED` on JDK 24+. The launcher passes it, and the jar manifest sets it for `java -jar`. The native method names and signatures are unchanged, so **the existing .so works as is**.
* Dependencies: log4j **2.25.1**, **ojdbc17** 23.8 (it replaces ojdbc8), JUnit 5 for tests. `jgl3.1.0.jar` and `log4j-web` are no longer needed. Check the versions in `pom.xml` against your internal repository.
* If you build a jlinked runtime, include `jdk.charsets`, because the Arabic re-encoding uses `windows-1256`.

## Performance changes

| Area | Before | After |
|---|---|---|
| Queues (16 DB buffers + 8 parser queues + reader buffer) | `com.objectspace.jgl.Queue` (1998), a monitor lock on every call, no way to wait for data | `MessageChannel`: a lock-free `ConcurrentLinkedQueue` with an O(1) size counter. The consumer parks until a producer publishes. |
| DataReader dispatcher | Busy-spin with no sleep: **one CPU core at 100% all session** | Blocks on the buffer (0% CPU when idle) |
| 7 parser threads | Drain, then `sleep(1–2 ms)`, about 500 wake-ups/s each when idle | Block on their own queue and wake when a message arrives |
| 19 DB writer/updater threads | Drain, then `sleep(100 ms)`, so an average of 50 ms extra latency before a row went to the DB batch | Block on their buffer with a 100 ms max wait, so housekeeping and periodic commits run at the same cadence as before |
| Tag/value split (every field of every message) | `split("[a-z]", 2)`: compiles a regex `Pattern` on every call | `Utility.splitTagValue`: a plain scan with an identical result, proven against the regex on 200k random inputs |
| Enum lookups (`getMessageValue`, 23 enums) | Clone `values()` + linear scan + writes to shared statics, per call | Immutable `Map` lookup |
| `Utility.appendTxWithToday` / `formatTime` | `static synchronized`, a global lock shared by all parsers | Stateless, no lock |
| `System.gc()` | Called in **19** `commitTrans` methods, so a full stop-the-world GC from every thread every 10 s | Removed |
| Logging | `%C` in the pattern (a stack walk per log line), root=DEBUG, synchronous file I/O, about 36 INFO lines **per message** (e.g. every order-book level) | `%c{1}`, root=INFO, Async appender, per-message lines moved to guarded DEBUG, and 151 concatenating `debug()` calls guarded |
| Raw feed log | `write()+flush()` syscall per message, platform charset | 64 KiB buffer flushed every 200 ms (configurable, 0 = legacy), explicit charset used for both write and replay |
| Per-message `Calendar.getInstance(TimeZone.getTimeZone("Asia/Riyadh"))` | Allocation + synchronized zone lookup | Cached `ZoneId` + `LocalTime` |
| Prepared statements | Each DB manager prepared every statement **twice** (base constructor + subclass constructor) and leaked the first set of open cursors | Prepared once |

Micro-benchmark run in the build sandbox (2 vCPU, JDK 21, 5,000 msg/s in bursts). The absolute numbers depend on the machine; what matters is the ratio:

```
legacy JGL + sleep(2ms) poll        p50  1041 us  p99  2120 us   consumer CPU 580 ms
legacy JGL + sleep(100ms) (DB thr)  p50 50413 us  p99 99196 us
new MessageChannel + awaitData      p50    74 us  p99   385 us   consumer CPU 150 ms

Idle 2 s: legacy DataReader busy-spin 1965 ms CPU | legacy parser poll 29 ms | new 1 ms
Tag split: legacy regex 828 ns/field vs splitTagValue 30 ns/field (27x)
```

## Correctness fixes made along the way

* **`shutdownFlag` is now `volatile`.** Without it, threads were not guaranteed to ever see the stop signal.
* **Dirty counters (`totShareUpdated`, ...) are now `AtomicInteger`, read and reset with `getAndSet(0)`.** The old `tmp = tot; tot = 0;` could lose an increment from a parser thread. Because a parser only increments when `isUpdated` was false, an instrument hit by that race could stay un-flushed (stale on the website) until another instrument updated.
* **Shared `CharsetEncoder`/`CharsetDecoder`** (not thread-safe) were used at the same time by the three index-intra writer threads. Each DB manager now has its own pair.
* **Shared static `SimpleDateFormat`** (not thread-safe) is now thread-confined. The lenient parsing is kept, so results are identical.
* **DataReader:** a typed message without `;` used to throw, and the frame was then **retried forever**, so the dispatcher stalled and the queue grew without bound. Such a message is now logged and dropped.
* **Reader:** an empty native message used to throw `StringIndexOutOfBounds` and end the read loop. It is now logged and skipped. A reconnect no longer leaks the previous feed-log file handle.
* **Explicit `commit()` on auto-commit connections:** the connections have always run with auto-commit **on** (nothing ever sets it off). ojdbc then throws "Could not commit with auto-commit set on", which was logged with a stack trace on every flush. `commitIfNeeded()` skips the call. Transaction semantics are unchanged.
* **Threads:** workers now run as **named** platform threads (`Parser-OrderBook`, `DBWriterShareIntra`, ...) with an uncaught-exception logger. The async EOD tasks run on virtual threads.

## Behaviour changes to be aware of

1. **Log content:** the root level is now INFO and about 36 per-message INFO lines are now DEBUG. Use `-Dtip.log.level=debug` to get everything back.
2. **Feed log charset:** the feed log is now written **and** replayed as UTF-8 (`FEED_LOG_CHARSET`). If you upgrade mid-day on a host whose old default charset was not UTF-8 and the feed contains non-ASCII text, set `FEED_LOG_CHARSET` to the old charset for that day.
3. **Feed log durability:** with the 200 ms flush, a `kill -9` can lose up to 200 ms of feed log. Recovery still works (TIP re-sends from the last sequence). Set `FEED_LOG_FLUSH_INTERVAL_MS=0` for the legacy flush-every-message behaviour.
4. **Config overrides:** any efp.ini key can now be overridden by the environment variable `TIP_<KEY>` or by `-Dtip.<KEY>`. Use this to move `DB_PASS` and `TARGIN_PASSWORD` out of efp.ini (they are currently stored in plain text).

## Found but deliberately NOT changed (please review)

These change business output, so they need your decision:

* `DataParserTrdAndTSt` (TSt for main-market shares): when `IS_NEGDEALS_EARLY_START` is false, the same `shareToQ` is pushed to `tipShareIntraQ` **twice**: once unconditionally, then again inside `if (!IS_NEGDEALS_EARLY_START)`. That probably writes duplicate intraday rows. The equivalent SME block pushes only once.
* In the same block, the `else` branch (log "received before market pre-open") runs for **every** TSt when early start is off. It is now a DEBUG line, but the condition looks unintended.
* `DBManager.isConnectionOpen()` reconnects but does not re-prepare statements, so after a DB reconnect the old statements still point at the closed connection.
* `DBQueueUpdater.quantaStart` is never reset, so after the first 5 s the "max delay" gate is always open (a sweep every 2 ms). That is harmless, but `TIP_MAX_DELAY_TIME` has no effect.
* The async EOD threads share the DB manager's JDBC connection with the owning writer thread.

## Verification status

* The code compiles cleanly with `javac --release 21 -Xlint:all` (only a pre-existing fall-through warning remains). It only uses APIs that are final in Java 21, so it is valid Java 25.
* 17 unit tests (`src/test`) pass. They show that the new splitter, time formatting, date parsing and enum lookups give **identical results** to the legacy code, and they cover the queue semantics: FIFO, multi-producer ordering, wake-up, and Buffer peek/release.
* `log4j2.xml` was loaded and checked: levels and the async appender work.
* **Not run here:** a Maven build against Maven Central or a JDK 25 runtime (neither was reachable from the build environment), and anything that needs the live TIP feed, `libtipclient.so` or Oracle. Before production, do a parallel run against UAT and compare the DB tables with the current listener for one full session (BOD, trading, EOD).
