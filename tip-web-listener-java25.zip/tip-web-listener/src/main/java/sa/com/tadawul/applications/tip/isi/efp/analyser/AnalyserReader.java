/**
 * #---------------------------------------------------------------------------------------------
 * #   This source is part of the Tadawul Web Listener, Saudi Stock Exchange
 * #   Copyright (c) 2009 Saudi Stock Exchange
 * #
 * #
 * #   All rights reserved.  No part of this source or any copyrights subsisting or arising out of these materials may be reproduced, distributed, amended, modified, adapted, stored in a
 * #   retrieval system, adopted or transmitted in any form or by any means,
 * #   electronic, mechanical, photographic, graphic, optic recording or otherwise,
 * #   translated in any language or computer language, without the prior written
 * #   permission of Saudi Stock Exchange
 * #
 * # ---------------------------------------------------------------------------------------------
 * ---------------------------------------------------------------------------------------------
 * Name          :     FileName : AnalyserReader.java
 *
 * Version             Date                     Author                  Change Description
 *----------------------------------------------------------------------------------------------
 * 1.0                 10/April/2009            Oracle                   Initial Version
 * 1.1				   14/November/2009         Mohanram,Oracle          Added functionalities to process the Equity Rights Share
 * 1.2				   02/February/2010         Mohanram,Oracle          Added functionalities to process the Exchange Traded Funds.
 * 2.0                 31/October/2026          Modernization            Java 25: buffered feed log with explicit charset,
 *                                                                        named worker threads, no regex/contains on hot path.
 *----------------------------------------------------------------------------------------------
 */
package sa.com.tadawul.applications.tip.isi.efp.analyser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import sa.com.tadawul.website.tip.DBThreads.DBQueueUpdater;
import sa.com.tadawul.website.tip.dataanalyser.DataReader;
import sa.com.tadawul.website.tip.log.Log;
import sa.com.tadawul.website.tip.log.LogFactory;
import sa.com.tadawul.website.tip.queue.FrameHolder;
import sa.com.tadawul.website.tip.queue.MessageQueue;
import sa.com.tadawul.website.tip.shared.Settings;
import sa.com.tadawul.website.tip.shared.TIPDataObjects;
import sa.com.tadawul.website.tip.shared.TipConstants;
import sa.com.tadawul.website.tip.shared.TipThreads;
import sa.com.tadawul.website.tip.shared.Utility;
import sa.com.tadawul.website.tip.vo.TIP_MsgVO;

/**
 * @description This reader class is responsible for connecting to primary/secondary TARGIN server,
 *              Logon request, sending a streaming request, reading the messages from the TARGIN
 *              feed and writing them to the queue.
 *              <p>
 *              The native method names and signatures below are bound to libtipclient.so and
 *              must not be renamed. Run with {@code --enable-native-access=ALL-UNNAMED}
 *              (JDK 24+ warns about JNI use otherwise; the executable JAR sets it in its manifest).
 */
public class AnalyserReader {
    public String userName = null;
    public String passWord = null;
    public String priHostName = null;
    public int priPortNum = 0;
    public String secHostName = null;
    public int secPortNum = 0;
    public int date = 0;
    public String hostName = null;
    public int portNum = 0;
    public long startSeq = 1;
    public long endSeq = 0;
    private FeedLogWriter feedLog;
    int iMessageCount = 0;

    // Native C call methods (JNI - do not rename)
    public native static int CNativeInitialize();
    public native static int CNativeConnect(String hostName, int portNum, int compression);
    public native static String CNativeGetNextMessage();
    public native static String CNativeGetErrorMessage();
    public native static String CNativeLogon(String userName, String password, String protocolVersion);
    public native static int CNativeStreamingRequest(int reqType, int scope, int date, long startSeq, long endSeq);
    public native static int CNativeLogoff();
    public native static int CNativeGetSignalReceived();
    public native static int CNativeDisconnect();

    static volatile boolean logoffSent = false;
    private static final Log logger = LogFactory.getLog(AnalyserReader.class);

    /** Terminator the parsers expect at the end of every message. */
    private static final String LINE_SEP = TipConstants.TIP_LINE_SEPARATOR;
    private static final boolean MULTI_CHAR_LINE_SEP = LINE_SEP.length() > 1;

    private final TIP_MsgVO msg = new TIP_MsgVO();

    static {
        if (Settings.g_oProperties == null)
            Settings.Load();
        System.load(TipConstants.XMP_LIBRARY);
        logger.info("Successfully loaded xmp shared library from " + TipConstants.XMP_LIBRARY);
    }

    public AnalyserReader() {
    }

    /**
     * Establishes the connection with TARGIN, sends Logon and Streaming Request, then reads the
     * feed and hands every message to the dispatcher.
     */
    private boolean ServiceRequest() {
        logger.debug("inside ServiceRequest function in AnalyserReader");
        String buffer;
        long readerStartTime;
        int ret;

        try {
            while (!TipConstants.shutdownFlag) {
                hostName = priHostName;
                portNum = priPortNum;
                // Connect to TIP (primary, then secondary)
                if (!connectTIP()) {
                    logger.error("Unable to connect with Primary...");
                    if (secHostName == null || secPortNum <= 0) {
                        logger.error("No secondary IP to connect...");
                        TipConstants.shutdownFlag = true;
                        continue;
                    }
                    hostName = secHostName;
                    portNum = secPortNum;
                    if (!connectTIP()) {
                        logger.error("Unable to connect with Secondary...");
                        TipConstants.shutdownFlag = true;
                        continue;
                    }
                }

                if (!LogonToTIP()) {
                    logger.error("Unable to Logon...");
                    TipConstants.shutdownFlag = true;
                    ret = CNativeDisconnect();
                    if (ret == TipConstants.FALSE)
                        logger.fatal("Call to CNativeDisconnect failed: " + CNativeGetErrorMessage());
                    continue;
                }
                if (!SendStreamingRequest()) {
                    logger.error("Unable to Send Streaming Request...");
                    HandleLogoff();
                    continue;
                }

                readerStartTime = System.currentTimeMillis();
                while ((buffer = CNativeGetNextMessage()) != null) {
                    final int len = buffer.length();
                    if (len == 0) {
                        // The legacy code threw StringIndexOutOfBounds here, which ended the read loop.
                        logger.error("Empty message received from TIP - ignored");
                        continue;
                    }
                    // Make sure the message is terminated. Same rule as before, but the full-string
                    // contains() scan is only needed for multi-character separators (Windows).
                    if (buffer.charAt(len - 1) != TipConstants.TIP_ENDOFMSG
                            || (MULTI_CHAR_LINE_SEP && !buffer.contains(LINE_SEP))) {
                        buffer = buffer.concat(LINE_SEP);
                    }
                    if (feedLog != null) {
                        try {
                            feedLog.write(buffer);
                        } catch (IOException e) {
                            logger.error("File Write Error = " + e);
                        }
                    }
                    iMessageCount++;
                    final long now = System.currentTimeMillis();
                    MessageQueue.g_oBuffer.setFrame(new FrameHolder(now + TipConstants.WEBSITE_DISPLAY_DELAY_TIME,
                            buffer, iMessageCount, readerStartTime, now));
                    readerStartTime = now;
                }
                // Check if a signal has been received
                int signal = CNativeGetSignalReceived();
                if (signal != 0 || TipConstants.shutdownFlag) {
                    logger.info("Signal received is " + signal + " shutdownFlag = " + TipConstants.shutdownFlag);
                    TipConstants.shutdownFlag = true;
                    HandleLogoff();
                }
                if (!TipConstants.shutdownFlag) {
                    logger.error("Call to CNativeGetNextMessage failed: " + CNativeGetErrorMessage());
                }
            }
        } catch (Exception e) {
            logger.error("Exception occurred = " + e, e);
        } finally {
            logger.debug("In finally Block of ServiceRequest");
            closeFeedLog();
        }
        logger.debug("Exit ServiceRequest function in AnalyserReader");
        return true;
    }

    /**
     * Reads the connection arguments from efp.ini (loaded by the static initializer) and starts
     * the pipeline: dispatcher + parsers, DB threads, then the TIP reader on the main thread.
     */
    public static void main(String[] args) {
        AnalyserReader obj = new AnalyserReader();
        obj.userName = TipConstants.TARGIN_USER_NAME;
        obj.passWord = TipConstants.TARGIN_PASSWORD;
        obj.priHostName = TipConstants.TARGIN_PRIMARY_HOST;
        obj.priPortNum = TipConstants.TARGIN_PRIMARY_PORT;
        obj.secHostName = TipConstants.TARGIN_SECONDARY_HOST;
        obj.secPortNum = TipConstants.TARGIN_SECONDARY_PORT;
        obj.date = (int) TipConstants.TARGIN_FEED_REQ_DATE;

        logger.info("Starting TIP Web Listener on Java " + Runtime.version() + " (" + System.getProperty("java.vm.name") + ")");
        int ret = 0;
        try {
            ret = CNativeInitialize();
        } catch (UnsatisfiedLinkError e) {
            logger.error("Call to CNativeInitialize() failed - native library not linked", e);
            System.exit(1);
        }
        if (ret == 0) {
            logger.fatal("Call to CNativeInitialize failed: " + CNativeGetErrorMessage());
            System.exit(1);
        }
        obj.startAnalyzerThreads();
        pause(5000); // let the dispatcher load reference data and start the parsers
        obj.startDBThreads();
        pause(5000); // let the DB threads open their connections
        obj.ServiceRequest();
        pause(5000); // give the other threads time to drain and stop
        System.exit(0);
    }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Thread is interrupted : " + e.getMessage());
        }
    }

    /** Reconnects to TARGIN until the maximum number of attempts is reached. */
    private boolean connectTIP() {
        logger.debug("inside connectTIP function in AnalyserReader");
        int ret = TipConstants.TRUE;
        for (int attempt = 0; attempt < TipConstants.TARGIN_CONNECT_MAX_RETRY_COUNT; attempt++) {
            logger.info("Connect Attempt " + attempt + " to " + hostName + ":" + portNum);
            try {
                ret = CNativeConnect(hostName, portNum, TipConstants.TIP_COMPRESSION_DISABLED);
            } catch (Exception e) {
                logger.error("Call to CNativeConnect failed: " + e.getMessage());
            }
            if (ret == TipConstants.FALSE) {
                logger.error("Call to CNativeConnect failed: " + CNativeGetErrorMessage());
            } else {
                logger.info("Connected to " + hostName + ":" + portNum);
                return true;
            }
        }
        logger.debug("Exit connectTIP function in AnalyserReader");
        return false;
    }

    /** Sends the Logon request, retrying until the maximum number of attempts is reached. */
    private boolean LogonToTIP() {
        logger.debug("inside LogonToTIP function in AnalyserReader");
        for (int attempt = 0; attempt < TipConstants.TARGIN_CONNECT_MAX_RETRY_COUNT; attempt++) {
            logger.info("Logon Attempt " + attempt);
            String logonresponse = CNativeLogon(userName, passWord, null);
            if (logonresponse == null) {
                logger.error("Call to CNativeLogon failed: " + CNativeGetErrorMessage());
                continue;
            }
            if (ProcessLogonLogoff(logonresponse, logonresponse.length())) {
                logger.info("ProcessMessage returned true");
                return true;
            }
        }
        logger.debug("Exit LogonToTIP function in AnalyserReader");
        return false;
    }

    /**
     * Replays today's feed log (file-based recovery) and sends the StreamingRequest from the
     * last processed sequence number.
     */
    private boolean SendStreamingRequest() {
        logger.debug("inside SendStreamingRequest function in AnalyserReader");
        TIPDataObjects.replayMode = false;

        final String logFileName = "tip_" + date + "_r" + TipConstants.TIP_REAL_TIME_REQUEST + "_s" + TipConstants.TIP_SCOPE_ALL + ".txt";
        final String logFilePath = Utility.logFileCreation(logFileName);
        if (TipConstants.LOG_FEED == 1 && TipConstants.FILE_BASED_RECOVERY == 1) {
            try (BufferedReader bufReader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(logFilePath), TipConstants.FEED_LOG_CHARSET), 1 << 16)) {
                TIPDataObjects.replayMode = true;
                logger.info("Replay mode started from " + logFilePath);
                long readerStartTime = System.currentTimeMillis();
                String line;
                while ((line = bufReader.readLine()) != null) {
                    iMessageCount++;
                    final long now = System.currentTimeMillis();
                    MessageQueue.g_oBuffer.setFrame(new FrameHolder(now, line.concat(LINE_SEP), iMessageCount, readerStartTime, now));
                    readerStartTime = now;
                }
            } catch (FileNotFoundException ex) {
                logger.info("No file found for replay...Sending streaming request from seq 1");
            } catch (IOException ex) {
                logger.error("IOException occured while reading log file for reloading " + ex);
                return false;
            }
            if (TIPDataObjects.replayMode) {
                startSeq = TIPDataObjects.last_Sequencer_Analyzer;
                endSeq = 0;
                TIPDataObjects.replayMode = false;
            }
            logger.info("Replay mode ended. Messages replayed so far: " + iMessageCount);
        }
        logger.info("Before calling StreamingRequest: reqType " + TipConstants.TIP_REAL_TIME_REQUEST
                + " scope " + TipConstants.TIP_SCOPE_ALL + " Date " + date + " startSeq " + startSeq + " endSeq " + endSeq);

        int ret = CNativeStreamingRequest(TipConstants.TIP_REAL_TIME_REQUEST, TipConstants.TIP_SCOPE_ALL, date, startSeq, endSeq);
        if (ret == TipConstants.FALSE) {
            logger.error("Call to CNativeStreamingRequest failed: " + CNativeGetErrorMessage());
            return false;
        }
        if (TipConstants.LOG_FEED == 1) {
            closeFeedLog(); // a reconnect used to leak the previous stream
            try {
                feedLog = new FeedLogWriter(logFilePath, TipConstants.FEED_LOG_CHARSET, TipConstants.FEED_LOG_FLUSH_INTERVAL_MS);
            } catch (IOException e) {
                logger.error("File Output Stream Error: " + e);
            }
        }
        logger.debug("Exit SendStreamingRequest function in AnalyserReader");
        return true;
    }

    private void closeFeedLog() {
        if (feedLog != null) {
            try {
                feedLog.close();
            } catch (IOException e) {
                logger.error("Log File Close Error: " + e);
            }
            feedLog = null;
        }
    }

    /** Sends the Logoff request to TARGIN and waits for its acknowledgement. */
    public boolean HandleLogoff() {
        logger.debug("inside HandleLogoff function in AnalyserReader");
        String buffer;
        int ret = CNativeLogoff();
        if (ret == TipConstants.FALSE) {
            logger.error("Call to CNativeLogoff failed: " + CNativeGetErrorMessage());
            return false;
        }

        logoffSent = true;
        while ((buffer = CNativeGetNextMessage()) != null) {
            if (ProcessLogonLogoff(buffer, buffer.length())) {
                logger.info("Logoff Acknowledged by TIP Server.. ");
                ret = CNativeDisconnect();
                if (ret == TipConstants.FALSE)
                    logger.error("Call to CNativeDisconnect failed: " + CNativeGetErrorMessage());
                return true;
            }
        }
        logger.info("Logoff Not Acknowledged by TIP Server.. ");
        ret = CNativeDisconnect();
        if (ret == TipConstants.FALSE)
            logger.error("Call to CNativeDisconnect failed: " + CNativeGetErrorMessage());
        logger.debug("Exit HandleLogoff function in AnalyserReader");
        return false;
    }

    /** Processes the General Reply to a Logon or Logoff request. */
    private boolean ProcessLogonLogoff(String buffer, int len) {
        logger.debug("inside ProcessLogonLogoff function in AnalyserReader");
        TIP_MsgVO reply = ParseMsg(buffer, len);
        if (reply == null) {
            logger.error("Message format error");
            return false;
        }

        // General reply in streaming mode is only sent as a response to Logon/Logoff. After the
        // Logoff reply the server disconnects the session.
        if (TipConstants.TIP_MSGTYPE_GENERALREPLY.equals(reply.msgType)) {
            String replycode = FindTag(reply, TipConstants.fTag_ReplyCode);
            if (replycode == null) {
                logger.error("Invalid General reply: no reply code found");
                return false;
            }
            String requestType = FindTag(reply, TipConstants.fTag_RequestType);
            int code = Integer.parseInt(replycode);
            logger.info("General reply: " + code + ":" + requestType + ":" + TipConstants.TIP_MSGTYPE_LOGON + ":"
                    + FindTag(reply, TipConstants.fTag_ReplyText));
            if (TipConstants.TIP_MSGTYPE_LOGON.equals(requestType) && code == 0) {
                return true;
            }
            if (TipConstants.TIP_MSGTYPE_LOGOFF.equals(requestType) && code == 0) {
                return true;
            }
        }
        logger.info("returning false from ProcessLogonLogoff, Msg Type received is " + reply.msgType);
        return false;
    }

    /** Parses a message into TAG/value pairs. */
    public TIP_MsgVO ParseMsg(String buffer, int len) {
        InitializeTIPMsg_VO(msg);
        msg.inputmsg = buffer;
        msg.length = len;
        // Verify that line termination is correct.
        if (buffer.isEmpty() || buffer.charAt(buffer.length() - 1) != TipConstants.TIP_ENDOFMSG) {
            logger.error("Message not correctly terminated" + msg.length + msg.inputmsg);
            return null;
        }
        String[] tagsValues = buffer.split(";");
        msg.msgType = tagsValues[0];
        msg.numtags = 0;
        for (int n = 1; n < tagsValues.length && msg.numtags < msg.tags.length; n++) {
            String tv = tagsValues[n];
            for (int i = 0; i < tv.length(); i++) {
                if (Character.isLowerCase(tv.charAt(i))) {
                    msg.tags[msg.numtags] = tv.substring(0, i + 1);
                    msg.values[msg.numtags] = tv.substring(i + 1);
                    msg.numtags++;
                    break;
                }
            }
        }
        return msg;
    }

    private void InitializeTIPMsg_VO(TIP_MsgVO tmpTipMsg) {
        tmpTipMsg.inputmsg = null;
        tmpTipMsg.length = 0;
        tmpTipMsg.msgType = null;
        tmpTipMsg.numtags = 0;
        java.util.Arrays.fill(tmpTipMsg.tags, null);
        java.util.Arrays.fill(tmpTipMsg.values, null);
    }

    /** Returns the value of the given tag, or null. */
    public String FindTag(TIP_MsgVO ptags, String ftag) {
        for (int i = 0; i < ptags.numtags; ++i) {
            if (ptags.tags[i].equals(ftag)) {
                return ptags.values[i];
            }
        }
        return null;
    }

    private void startAnalyzerThreads() {
        TipThreads.startWorker("DataReader", new DataReader());
    }

    private void startDBThreads() {
        TipThreads.startWorker("DBQueueUpdater", new DBQueueUpdater());
    }
}
